package com.example.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.app.activities.ConversationInboxActivity;
import com.example.app.activities.FamilyTrackingMapActivity;
import com.example.app.activities.LoginActivity;
import com.example.app.activities.ProfileActivity;
import com.example.app.activities.RespondentCasesActivity;
import com.example.app.auth.AccountPolicy;
import com.example.app.fragments.HomeFragment;
import com.example.app.services.FcmTokenRegistrar;
import com.example.app.services.HealthMateRealtimeService;
import com.example.app.services.LocationSharingService;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_SESSION_WARNING="sessionWarning";
    public static final String EXTRA_OFFLINE_SESSION="offlineSession";
    public static final String EXTRA_ROLE="accountRole";
    private BottomNavigationView navigation;private String accountRole;private boolean offlineSession;
    private final ActivityResultLauncher<String> notificationPermissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestPermission(),granted->{if(!granted)Toast.makeText(this,R.string.home_notification_permission_message,Toast.LENGTH_LONG).show();});

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);if(!HealthMateApplication.isFirebaseReady()){Toast.makeText(this,R.string.home_firebase_missing_message,Toast.LENGTH_LONG).show();redirectToLogin();return;}if(FirebaseAuth.getInstance().getCurrentUser()==null){redirectToLogin();return;}
        accountRole=AccountPolicy.normalizeValue(getIntent().getStringExtra(EXTRA_ROLE));if(!AccountPolicy.ROLE_USER.equals(accountRole)&&!AccountPolicy.ROLE_RESPONDER.equals(accountRole)){redirectToLoginWithMessage("The authenticated account role could not be resolved. Sign in again.");return;}
        offlineSession=getIntent().getBooleanExtra(EXTRA_OFFLINE_SESSION,false);setContentView(R.layout.activity_main);String warning=getIntent().getStringExtra(EXTRA_SESSION_WARNING);if(warning!=null&&!warning.trim().isEmpty())Toast.makeText(this,warning,Toast.LENGTH_LONG).show();
        navigation=findViewById(R.id.bottomNavigation);configureRoleNavigation();configureNavigation();FcmTokenRegistrar.registerCurrentToken(this);requestNotificationPermission();HealthMateRealtimeService.start(this);LocationSharingService.refresh(this);if(state==null)showHome();
    }
    private void configureRoleNavigation(){if(AccountPolicy.ROLE_RESPONDER.equals(accountRole)){navigation.getMenu().findItem(R.id.nav_map).setTitle(R.string.respondent_nav_cases);navigation.getMenu().findItem(R.id.nav_map).setIcon(R.drawable.ic_home_warning);}navigation.getMenu().findItem(R.id.nav_alerts).setTitle("Messages");navigation.getMenu().findItem(R.id.nav_alerts).setIcon(R.drawable.ic_home_chat);}
    private void configureNavigation(){navigation.setOnItemSelectedListener(item->{int id=item.getItemId();if(id==R.id.nav_home){showHome();return true;}if(id==R.id.nav_map){launchTopLevelActivity(AccountPolicy.ROLE_RESPONDER.equals(accountRole)?RespondentCasesActivity.class:FamilyTrackingMapActivity.class);return true;}if(id==R.id.nav_alerts){launchTopLevelActivity(ConversationInboxActivity.class);return true;}if(id==R.id.nav_profile){launchTopLevelActivity(ProfileActivity.class);return true;}return false;});}
    private void launchTopLevelActivity(Class<? extends Activity> destination){Intent intent=new Intent(this,destination);intent.putExtra(EXTRA_ROLE,accountRole);intent.putExtra(EXTRA_OFFLINE_SESSION,offlineSession);intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);startActivity(intent);}
    private void redirectToLogin(){redirectToLoginWithMessage(null);}private void redirectToLoginWithMessage(String message){Intent login=new Intent(this,LoginActivity.class);if(message!=null)login.putExtra(LoginActivity.EXTRA_AUTH_ERROR,message);login.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(login);finish();}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);}
    @Override protected void onResume(){super.onResume();if(navigation!=null)navigation.getMenu().findItem(R.id.nav_home).setChecked(true);}
    private void showHome(){HomeFragment fragment=new HomeFragment();Bundle args=new Bundle();args.putString(EXTRA_ROLE,accountRole);args.putBoolean(EXTRA_OFFLINE_SESSION,offlineSession);fragment.setArguments(args);getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer,fragment).commit();}
}
