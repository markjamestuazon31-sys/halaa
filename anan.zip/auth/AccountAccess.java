package com.example.app.auth;

import com.example.app.models.User;

public final class AccountAccess {
    private final User profile;
    private final boolean offline;

    public AccountAccess(User profile, boolean offline) {
        this.profile = profile;
        this.offline = offline;
    }

    public User getProfile() { return profile; }
    public String getUid() { return profile == null ? "" : safe(profile.getUid()); }
    public String getRole() { return profile == null ? "" : AccountPolicy.normalizeValue(profile.getRole()); }
    public boolean isRespondent() { return AccountPolicy.ROLE_RESPONDER.equals(getRole()); }
    public boolean isUser() { return AccountPolicy.ROLE_USER.equals(getRole()); }
    public boolean isOffline() { return offline; }

    private String safe(String value) { return value == null ? "" : value; }
}
