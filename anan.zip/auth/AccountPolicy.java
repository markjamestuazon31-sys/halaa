package com.example.app.auth;

import java.util.Locale;

/** Central role and account rules. Privileged roles are never inferred from an email alone. */
public final class AccountPolicy {
    public static final String RESPONDER_DOMAIN = "respondent.com";
    public static final String ROLE_USER = "user";
    public static final String ROLE_RESPONDER = "responder";
    public static final String ACCOUNT_ACTIVE = "active";

    private AccountPolicy() { }

    public static String normalizeEmail(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }

    public static String normalizeValue(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }

    public static boolean isReservedResponderEmail(String email) {
        String normalized = normalizeEmail(email);
        int separator = normalized.lastIndexOf('@');
        return separator > 0 && separator < normalized.length() - 1
                && RESPONDER_DOMAIN.equals(normalized.substring(separator + 1));
    }

    public static boolean canRegisterAsNormalUser(String email) {
        return !normalizeEmail(email).isEmpty() && !isReservedResponderEmail(email);
    }

    /** Normal users do not require Firebase email verification. Respondents still do. */
    public static boolean requiresEmailVerificationForRole(String role) {
        return ROLE_RESPONDER.equals(normalizeValue(role));
    }

    public static boolean isActiveAccountStatus(String value) {
        return ACCOUNT_ACTIVE.equals(normalizeValue(value));
    }

    public static boolean isRegisteredInvitationStatus(String value) {
        return "registered".equals(normalizeValue(value));
    }

    public static boolean isInvitedInvitationStatus(String value) {
        return "invited".equals(normalizeValue(value));
    }

    public static boolean emailMatches(String authenticatedEmail, String profileEmail) {
        String auth = normalizeEmail(authenticatedEmail);
        return !auth.isEmpty() && auth.equals(normalizeEmail(profileEmail));
    }

    public static boolean isAuthorizedUser(
            String authEmail,
            String profileRole,
            String profileEmail,
            String accountStatus
    ) {
        return ROLE_USER.equals(normalizeValue(profileRole))
                && !isReservedResponderEmail(authEmail)
                && emailMatches(authEmail, profileEmail)
                && isActiveAccountStatus(accountStatus);
    }

    public static boolean isAuthorizedRespondent(
            String authUid,
            String authEmail,
            String profileRole,
            String profileEmail,
            String profileStatus,
            String respondentUid,
            String respondentEmail,
            String respondentStatus,
            String invitationEmail,
            String invitationStatus,
            String registeredUid
    ) {
        return ROLE_RESPONDER.equals(normalizeValue(profileRole))
                && isReservedResponderEmail(authEmail)
                && emailMatches(authEmail, profileEmail)
                && isActiveAccountStatus(profileStatus)
                && authUid != null && authUid.equals(respondentUid)
                && emailMatches(authEmail, respondentEmail)
                && isActiveAccountStatus(respondentStatus)
                && emailMatches(authEmail, invitationEmail)
                && isRegisteredInvitationStatus(invitationStatus)
                && authUid.equals(registeredUid);
    }
}
