package com.example.app.auth;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.app.models.User;

/** Caches only the last server-verified role/profile for offline shell routing. FirebaseAuth remains the session source. */
public final class AccountCache {
    private static final String PREFS = "healthmate_verified_account";
    private final SharedPreferences preferences;
    public AccountCache(Context context) { preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public void save(User user) {
        if (user == null || user.getUid() == null) return;
        preferences.edit()
                .putString("uid", user.getUid())
                .putString("email", AccountPolicy.normalizeEmail(user.getEmail()))
                .putString("role", AccountPolicy.normalizeValue(user.getRole()))
                .putString("accountStatus", AccountPolicy.normalizeValue(user.getAccountStatus()))
                .putString("fullName", user.getFullName())
                .putString("phone", user.getPhone())
                .putString("assignedBarangayId", user.getAssignedBarangayId())
                .putString("respondentInvitationKey", user.getRespondentInvitationKey())
                .putLong("verifiedAt", System.currentTimeMillis())
                .apply();
    }

    public User read(String uid, String email) {
        if (uid == null || !uid.equals(preferences.getString("uid", ""))) return null;
        if (!AccountPolicy.normalizeEmail(email).equals(preferences.getString("email", ""))) return null;
        if (!AccountPolicy.isActiveAccountStatus(preferences.getString("accountStatus", ""))) return null;
        User user = new User();
        user.setUid(uid); user.setEmail(email); user.setRole(preferences.getString("role", ""));
        user.setAccountStatus(preferences.getString("accountStatus", "")); user.setStatus(user.getAccountStatus());
        user.setFullName(preferences.getString("fullName", "")); user.setPhone(preferences.getString("phone", ""));
        user.setAssignedBarangayId(preferences.getString("assignedBarangayId", ""));
        user.setRespondentInvitationKey(preferences.getString("respondentInvitationKey", ""));
        return user;
    }

    public void clear() { preferences.edit().clear().apply(); }
}
