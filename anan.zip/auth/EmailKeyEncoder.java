package com.example.app.auth;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;

/** Deterministic Firebase-safe key for exact normalized respondent emails. */
public final class EmailKeyEncoder {
    private EmailKeyEncoder() { }

    public static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }

    public static String encode(String value) {
        String normalized = normalize(value);
        if (normalized.isEmpty()) throw new IllegalArgumentException("Email is required.");
        return Base64.getUrlEncoder().withoutPadding()
                .encodeToString(normalized.getBytes(StandardCharsets.UTF_8));
    }
}
