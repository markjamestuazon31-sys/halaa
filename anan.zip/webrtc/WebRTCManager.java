package com.example.app.webrtc;

import android.content.Context;
import android.util.Log;

import com.example.app.BuildConfig;

import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DataChannel;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.MediaStreamTrack;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RendererCommon;
import org.webrtc.RtpReceiver;
import org.webrtc.RtpTransceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class WebRTCManager {

    private static final String TAG = "WebRTCManager";
    private static final String STREAM_ID = "healthmate-stream";
    private static final AtomicBoolean INITIALIZED = new AtomicBoolean(false);

    private final Context context;
    private final EglBase eglBase;
    private final PeerConnectionFactory factory;
    private final Callback callback;

    private PeerConnection peerConnection;
    private AudioSource audioSource;
    private AudioTrack localAudioTrack;
    private VideoSource videoSource;
    private VideoTrack localVideoTrack;
    private VideoTrack remoteVideoTrack;
    private VideoCapturer videoCapturer;
    private SurfaceTextureHelper surfaceTextureHelper;
    private SurfaceViewRenderer localRenderer;
    private SurfaceViewRenderer remoteRenderer;

    private boolean videoEnabled;
    private boolean closed;

    public WebRTCManager(Context context, Callback callback) {
        if (context == null) {
            throw new IllegalArgumentException("Context must not be null.");
        }
        if (callback == null) {
            throw new IllegalArgumentException("Callback must not be null.");
        }

        this.context = context.getApplicationContext();
        this.callback = callback;

        initializeWebRtc();
        eglBase = EglBase.create();
        factory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(
                        new DefaultVideoEncoderFactory(
                                eglBase.getEglBaseContext(),
                                true,
                                true
                        )
                )
                .setVideoDecoderFactory(
                        new DefaultVideoDecoderFactory(
                                eglBase.getEglBaseContext()
                        )
                )
                .createPeerConnectionFactory();
    }

    private void initializeWebRtc() {
        if (INITIALIZED.compareAndSet(false, true)) {
            PeerConnectionFactory.InitializationOptions options =
                    PeerConnectionFactory.InitializationOptions
                            .builder(context)
                            .setEnableInternalTracer(false)
                            .createInitializationOptions();
            PeerConnectionFactory.initialize(options);
        }
    }

    public void start(
            boolean enableVideo,
            SurfaceViewRenderer local,
            SurfaceViewRenderer remote
    ) {
        if (closed) {
            callback.onError("WebRTCManager has already been closed.");
            return;
        }

        videoEnabled = enableVideo;
        localRenderer = local;
        remoteRenderer = remote;

        initializeRenderers();
        createPeerConnection();
        createLocalMedia();
    }

    private void initializeRenderers() {
        if (remoteRenderer != null) {
            remoteRenderer.init(
                    eglBase.getEglBaseContext(),
                    new RendererCommon.RendererEvents() {
                        @Override
                        public void onFirstFrameRendered() {
                            Log.d(TAG, "First remote video frame rendered.");
                            callback.onRemoteVideoAvailable();
                        }

                        @Override
                        public void onFrameResolutionChanged(
                                int videoWidth,
                                int videoHeight,
                                int rotation
                        ) {
                            Log.d(
                                    TAG,
                                    "Remote frame: "
                                            + videoWidth
                                            + "x"
                                            + videoHeight
                                            + " rotation="
                                            + rotation
                            );
                        }
                    }
            );
            remoteRenderer.setMirror(false);
            remoteRenderer.setEnableHardwareScaler(true);
            remoteRenderer.setScalingType(
                    RendererCommon.ScalingType.SCALE_ASPECT_FILL
            );
            remoteRenderer.setZOrderMediaOverlay(false);
        }

        if (localRenderer != null) {
            localRenderer.init(eglBase.getEglBaseContext(), null);
            localRenderer.setMirror(true);
            localRenderer.setEnableHardwareScaler(true);
            localRenderer.setScalingType(
                    RendererCommon.ScalingType.SCALE_ASPECT_FIT
            );

            /*
             * Both renderers are SurfaceViews. The local preview must use the
             * media-overlay surface layer or it can appear as a blank white
             * rectangle above the remote video.
             */
            localRenderer.setZOrderMediaOverlay(true);
        }
    }

    private void createPeerConnection() {
        List<PeerConnection.IceServer> iceServers = new ArrayList<>();
        iceServers.add(
                PeerConnection.IceServer
                        .builder("stun:stun.l.google.com:19302")
                        .createIceServer()
        );
        iceServers.add(
                PeerConnection.IceServer
                        .builder("stun:stun1.l.google.com:19302")
                        .createIceServer()
        );
        addTurnServersIfConfigured(iceServers);

        PeerConnection.RTCConfiguration configuration =
                new PeerConnection.RTCConfiguration(iceServers);
        configuration.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
        configuration.continualGatheringPolicy =
                PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY;

        peerConnection = factory.createPeerConnection(
                configuration,
                createPeerConnectionObserver()
        );

        if (peerConnection == null) {
            callback.onError("Unable to create the WebRTC peer connection.");
        }
    }

    private void addTurnServersIfConfigured(
            List<PeerConnection.IceServer> iceServers
    ) {
        String configuredUrls = safe(BuildConfig.WEBRTC_TURN_URL);
        if (configuredUrls.isEmpty()) {
            Log.w(
                    TAG,
                    "No TURN server configured. Calls may fail between "
                            + "different carrier or restricted networks."
            );
            return;
        }

        String username = safe(BuildConfig.WEBRTC_TURN_USERNAME);
        String password = safe(BuildConfig.WEBRTC_TURN_PASSWORD);

        for (String rawUrl : configuredUrls.split(",")) {
            String url = safe(rawUrl);
            if (url.isEmpty()) {
                continue;
            }

            PeerConnection.IceServer.Builder builder =
                    PeerConnection.IceServer.builder(url);
            if (!username.isEmpty()) {
                builder.setUsername(username);
            }
            if (!password.isEmpty()) {
                builder.setPassword(password);
            }
            iceServers.add(builder.createIceServer());
        }
    }

    private PeerConnection.Observer createPeerConnectionObserver() {
        return new PeerConnection.Observer() {
            @Override
            public void onSignalingChange(PeerConnection.SignalingState state) {
                Log.d(TAG, "Signaling state: " + state);
            }

            @Override
            public void onIceConnectionChange(
                    PeerConnection.IceConnectionState state
            ) {
                Log.d(TAG, "ICE connection state: " + state);
                callback.onConnectionStateChanged(state.name());
            }

            @Override
            public void onConnectionChange(
                    PeerConnection.PeerConnectionState state
            ) {
                Log.d(TAG, "Peer connection state: " + state);
                callback.onConnectionStateChanged(state.name());
            }

            @Override
            public void onIceConnectionReceivingChange(boolean receiving) {
                Log.d(TAG, "ICE receiving changed: " + receiving);
            }

            @Override
            public void onIceGatheringChange(
                    PeerConnection.IceGatheringState state
            ) {
                Log.d(TAG, "ICE gathering state: " + state);
            }

            @Override
            public void onIceCandidate(IceCandidate candidate) {
                if (candidate != null) {
                    callback.onLocalIceCandidate(candidate);
                }
            }

            @Override
            public void onIceCandidatesRemoved(IceCandidate[] candidates) {
                // No action required for Firebase trickle ICE signaling.
            }

            @Override
            public void onAddStream(MediaStream stream) {
                // Legacy Plan-B callback. Unified Plan uses onTrack/onAddTrack.
            }

            @Override
            public void onRemoveStream(MediaStream stream) {
                // No action required.
            }

            @Override
            public void onDataChannel(DataChannel dataChannel) {
                // Data channels are not currently used.
            }

            @Override
            public void onRenegotiationNeeded() {
                Log.d(TAG, "WebRTC renegotiation requested.");
            }

            @Override
            public void onAddTrack(
                    RtpReceiver receiver,
                    MediaStream[] mediaStreams
            ) {
                if (receiver != null) {
                    attachRemoteTrack(receiver.track());
                }
            }

            @Override
            public void onTrack(RtpTransceiver transceiver) {
                if (transceiver != null
                        && transceiver.getReceiver() != null) {
                    attachRemoteTrack(
                            transceiver.getReceiver().track()
                    );
                }
            }
        };
    }

    private synchronized void attachRemoteTrack(MediaStreamTrack track) {
        if (!(track instanceof VideoTrack) || remoteRenderer == null) {
            return;
        }

        VideoTrack videoTrack = (VideoTrack) track;
        if (remoteVideoTrack != null
                && remoteVideoTrack.id().equals(videoTrack.id())) {
            return;
        }

        if (remoteVideoTrack != null) {
            remoteVideoTrack.removeSink(remoteRenderer);
        }

        remoteVideoTrack = videoTrack;
        remoteVideoTrack.setEnabled(true);
        remoteVideoTrack.addSink(remoteRenderer);
        Log.d(TAG, "Remote video track attached: " + videoTrack.id());
    }

    private void createLocalMedia() {
        if (peerConnection == null) {
            return;
        }

        createLocalAudio();
        if (videoEnabled) {
            createLocalVideo();
        }
    }

    private void createLocalAudio() {
        MediaConstraints audioConstraints = new MediaConstraints();
        audioSource = factory.createAudioSource(audioConstraints);
        localAudioTrack = factory.createAudioTrack(
                "healthmate-audio",
                audioSource
        );
        localAudioTrack.setEnabled(true);

        try {
            peerConnection.addTrack(
                    localAudioTrack,
                    Collections.singletonList(STREAM_ID)
            );
        } catch (IllegalStateException error) {
            callback.onError(
                    "Unable to add microphone audio to the call: "
                            + errorMessage(error)
            );
        }
    }

    private void createLocalVideo() {
        videoCapturer = createCameraCapturer();
        if (videoCapturer == null) {
            callback.onError("No camera is available for this video call.");
            return;
        }

        surfaceTextureHelper = SurfaceTextureHelper.create(
                "HealthMateCaptureThread",
                eglBase.getEglBaseContext()
        );
        videoSource = factory.createVideoSource(false);
        videoCapturer.initialize(
                surfaceTextureHelper,
                context,
                videoSource.getCapturerObserver()
        );

        try {
            /*
             * 640x480 is intentionally used as the negotiation baseline. It is
             * substantially more reliable on entry-level devices than forcing
             * 1280x720 while still providing a clear face image.
             */
            videoCapturer.startCapture(640, 480, 24);
        } catch (RuntimeException error) {
            Log.e(TAG, "Unable to start camera.", error);
            callback.onError(
                    "The camera could not start: " + errorMessage(error)
            );
            return;
        }

        localVideoTrack = factory.createVideoTrack(
                "healthmate-video",
                videoSource
        );
        localVideoTrack.setEnabled(true);

        if (localRenderer != null) {
            localVideoTrack.addSink(localRenderer);
        }

        try {
            peerConnection.addTrack(
                    localVideoTrack,
                    Collections.singletonList(STREAM_ID)
            );
        } catch (IllegalStateException error) {
            callback.onError(
                    "Unable to add camera video to the call: "
                            + errorMessage(error)
            );
        }
    }

    private VideoCapturer createCameraCapturer() {
        CameraEnumerator enumerator = Camera2Enumerator.isSupported(context)
                ? new Camera2Enumerator(context)
                : new Camera1Enumerator(true);

        VideoCapturer frontCamera = findFrontCamera(enumerator);
        return frontCamera != null
                ? frontCamera
                : findAnyCamera(enumerator);
    }

    private VideoCapturer findFrontCamera(CameraEnumerator enumerator) {
        for (String deviceName : enumerator.getDeviceNames()) {
            if (!enumerator.isFrontFacing(deviceName)) {
                continue;
            }

            VideoCapturer capturer = enumerator.createCapturer(
                    deviceName,
                    null
            );
            if (capturer != null) {
                return capturer;
            }
        }
        return null;
    }

    private VideoCapturer findAnyCamera(CameraEnumerator enumerator) {
        for (String deviceName : enumerator.getDeviceNames()) {
            VideoCapturer capturer = enumerator.createCapturer(
                    deviceName,
                    null
            );
            if (capturer != null) {
                return capturer;
            }
        }
        return null;
    }

    public void createOffer(DescriptionCallback descriptionCallback) {
        if (descriptionCallback == null) {
            return;
        }
        if (peerConnection == null) {
            descriptionCallback.onError("Peer connection is unavailable.");
            return;
        }

        peerConnection.createOffer(
                new CreateSdpObserver(descriptionCallback),
                createMediaConstraints()
        );
    }

    public void createAnswer(DescriptionCallback descriptionCallback) {
        if (descriptionCallback == null) {
            return;
        }
        if (peerConnection == null) {
            descriptionCallback.onError("Peer connection is unavailable.");
            return;
        }

        peerConnection.createAnswer(
                new CreateSdpObserver(descriptionCallback),
                createMediaConstraints()
        );
    }

    public void setRemoteDescription(
            SessionDescription description,
            OperationCallback operationCallback
    ) {
        if (operationCallback == null) {
            return;
        }
        if (description == null) {
            operationCallback.onError("Remote description is null.");
            return;
        }
        if (peerConnection == null) {
            operationCallback.onError("Peer connection is unavailable.");
            return;
        }

        peerConnection.setRemoteDescription(
                new SimpleSdpObserver(operationCallback),
                description
        );
    }

    public void addRemoteIceCandidate(IceCandidate candidate) {
        if (peerConnection == null || candidate == null) {
            return;
        }

        boolean added = peerConnection.addIceCandidate(candidate);
        if (!added) {
            callback.onError(
                    "A remote network candidate could not be applied."
            );
        }
    }

    public void setMuted(boolean muted) {
        if (localAudioTrack != null) {
            localAudioTrack.setEnabled(!muted);
        }
    }

    public void setVideoEnabled(boolean enabled) {
        videoEnabled = enabled;
        if (localVideoTrack != null) {
            localVideoTrack.setEnabled(enabled);
        }
    }

    public void switchCamera() {
        if (!(videoCapturer instanceof CameraVideoCapturer)) {
            return;
        }

        CameraVideoCapturer cameraVideoCapturer =
                (CameraVideoCapturer) videoCapturer;
        cameraVideoCapturer.switchCamera(
                new CameraVideoCapturer.CameraSwitchHandler() {
                    @Override
                    public void onCameraSwitchDone(boolean isFrontCamera) {
                        if (localRenderer != null) {
                            localRenderer.setMirror(isFrontCamera);
                        }
                        Log.d(
                                TAG,
                                "Camera switched. Front camera: "
                                        + isFrontCamera
                        );
                    }

                    @Override
                    public void onCameraSwitchError(
                            String errorDescription
                    ) {
                        Log.e(
                                TAG,
                                "Camera switch failed: " + errorDescription
                        );
                        callback.onError(
                                "Unable to switch camera: "
                                        + errorDescription
                        );
                    }
                }
        );
    }

    private MediaConstraints createMediaConstraints() {
        MediaConstraints constraints = new MediaConstraints();
        constraints.mandatory.add(
                new MediaConstraints.KeyValuePair(
                        "OfferToReceiveAudio",
                        "true"
                )
        );
        constraints.mandatory.add(
                new MediaConstraints.KeyValuePair(
                        "OfferToReceiveVideo",
                        String.valueOf(videoEnabled)
                )
        );
        return constraints;
    }

    public void close() {
        if (closed) {
            return;
        }
        closed = true;

        removeVideoSinks();
        stopAndDisposeCamera();
        disposePeerConnection();
        disposeMediaResources();
        releaseRenderers();
        factory.dispose();
        eglBase.release();
    }

    private void removeVideoSinks() {
        if (localVideoTrack != null && localRenderer != null) {
            localVideoTrack.removeSink(localRenderer);
        }
        if (remoteVideoTrack != null && remoteRenderer != null) {
            remoteVideoTrack.removeSink(remoteRenderer);
        }
        remoteVideoTrack = null;
    }

    private void stopAndDisposeCamera() {
        if (videoCapturer == null) {
            return;
        }

        try {
            videoCapturer.stopCapture();
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            Log.w(TAG, "Camera stop operation was interrupted.", interrupted);
        } catch (RuntimeException error) {
            Log.w(TAG, "Unable to stop camera cleanly.", error);
        }

        videoCapturer.dispose();
        videoCapturer = null;
    }

    private void disposePeerConnection() {
        if (peerConnection == null) {
            return;
        }
        peerConnection.close();
        peerConnection.dispose();
        peerConnection = null;
    }

    private void disposeMediaResources() {
        if (localAudioTrack != null) {
            localAudioTrack.dispose();
            localAudioTrack = null;
        }
        if (audioSource != null) {
            audioSource.dispose();
            audioSource = null;
        }
        if (localVideoTrack != null) {
            localVideoTrack.dispose();
            localVideoTrack = null;
        }
        if (videoSource != null) {
            videoSource.dispose();
            videoSource = null;
        }
        if (surfaceTextureHelper != null) {
            surfaceTextureHelper.dispose();
            surfaceTextureHelper = null;
        }
    }

    private void releaseRenderers() {
        if (localRenderer != null) {
            localRenderer.clearImage();
            localRenderer.release();
            localRenderer = null;
        }
        if (remoteRenderer != null) {
            remoteRenderer.clearImage();
            remoteRenderer.release();
            remoteRenderer = null;
        }
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private String errorMessage(Throwable error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty()
                ? error.getClass().getSimpleName()
                : message;
    }

    private final class CreateSdpObserver implements SdpObserver {

        private final DescriptionCallback descriptionCallback;

        private CreateSdpObserver(
                DescriptionCallback descriptionCallback
        ) {
            this.descriptionCallback = descriptionCallback;
        }

        @Override
        public void onCreateSuccess(SessionDescription description) {
            if (peerConnection == null) {
                descriptionCallback.onError(
                        "Peer connection closed before the description "
                                + "was created."
                );
                return;
            }

            peerConnection.setLocalDescription(
                    new SimpleSdpObserver(
                            new OperationCallback() {
                                @Override
                                public void onSuccess() {
                                    descriptionCallback.onSuccess(description);
                                }

                                @Override
                                public void onError(String message) {
                                    descriptionCallback.onError(message);
                                }
                            }
                    ),
                    description
            );
        }

        @Override
        public void onSetSuccess() {
            // Not used while creating an offer or answer.
        }

        @Override
        public void onCreateFailure(String error) {
            descriptionCallback.onError(error);
        }

        @Override
        public void onSetFailure(String error) {
            descriptionCallback.onError(error);
        }
    }

    private static final class SimpleSdpObserver implements SdpObserver {

        private final OperationCallback operationCallback;

        private SimpleSdpObserver(OperationCallback operationCallback) {
            this.operationCallback = operationCallback;
        }

        @Override
        public void onCreateSuccess(SessionDescription description) {
            // Not used while setting a description.
        }

        @Override
        public void onSetSuccess() {
            operationCallback.onSuccess();
        }

        @Override
        public void onCreateFailure(String error) {
            operationCallback.onError(error);
        }

        @Override
        public void onSetFailure(String error) {
            operationCallback.onError(error);
        }
    }

    public interface Callback {
        void onLocalIceCandidate(IceCandidate candidate);

        void onConnectionStateChanged(String state);

        void onRemoteVideoAvailable();

        void onError(String message);
    }

    public interface DescriptionCallback {
        void onSuccess(SessionDescription description);

        void onError(String message);
    }

    public interface OperationCallback {
        void onSuccess();

        void onError(String message);
    }
}
