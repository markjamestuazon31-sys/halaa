package com.example.app.viewmodels;


import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


import com.example.app.models.User;
import com.example.app.repositories.UserRepository;



public class UserViewModel extends ViewModel {



    private final UserRepository repository;



    public MutableLiveData<User> user =
            new MutableLiveData<>();


    public MutableLiveData<String> error =
            new MutableLiveData<>();




    public UserViewModel(){


        repository =
                new UserRepository();


    }





    public void loadUser(){


        repository.getCurrentUser(

                new UserRepository.UserCallback(){


                    @Override
                    public void onSuccess(User data){


                        user.postValue(data);


                    }



                    @Override
                    public void onError(String message){


                        error.postValue(message);


                    }


                });


    }





    public void update(User data){


        repository.updateUser(
                data,
                new UserRepository.UserCallback(){



                    @Override
                    public void onSuccess(User user){


                        UserViewModel.this.user
                                .postValue(user);


                    }



                    @Override
                    public void onError(String message){


                        error.postValue(message);


                    }


                });


    }


}