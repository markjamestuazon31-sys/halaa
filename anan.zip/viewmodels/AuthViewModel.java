package com.example.app.viewmodels;


import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


import com.example.app.models.User;

import com.example.app.repositories.AuthRepository;



public class AuthViewModel extends ViewModel {


    private final AuthRepository repository;


    public MutableLiveData<String> error =
            new MutableLiveData<>();


    public MutableLiveData<Boolean> success =
            new MutableLiveData<>();



    public AuthViewModel(){


        repository =
                new AuthRepository();


    }




    public void register(
            User user,
            String password
    ){


        repository.registerUser(
                user,
                password,
                new AuthRepository.AuthCallback(){


                    @Override
                    public void onSuccess(){

                        success.postValue(true);

                    }



                    @Override
                    public void onError(String message){

                        error.postValue(message);

                    }


                });


    }






    public void login(
            String email,
            String password
    ){


        repository.loginUser(
                email,
                password,
                new AuthRepository.AuthCallback(){


                    @Override
                    public void onSuccess(){

                        success.postValue(true);

                    }



                    @Override
                    public void onError(String message){

                        error.postValue(message);

                    }


                });


    }


}