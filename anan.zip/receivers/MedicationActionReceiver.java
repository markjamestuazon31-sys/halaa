package com.example.app.receivers;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.app.models.Medication;
import com.example.app.models.MedicationHistory;
import com.example.app.repositories.MedicationRepository;
import com.example.app.utils.MedicationAlarmScheduler;

public class MedicationActionReceiver extends BroadcastReceiver {

    public static final String ACTION_MARK_TAKEN =
            "com.example.healthmate.action.MEDICATION_TAKEN";
    public static final String ACTION_SNOOZE =
            "com.example.healthmate.action.MEDICATION_SNOOZE";
    public static final String EXTRA_NOTIFICATION_ID = "notificationId";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        String userId =
                intent.getStringExtra(MedicationAlarmScheduler.EXTRA_USER_ID);
        String medicationId =
                intent.getStringExtra(
                        MedicationAlarmScheduler.EXTRA_MEDICATION_ID
                );
        String name =
                intent.getStringExtra(
                        MedicationAlarmScheduler.EXTRA_MEDICINE_NAME
                );
        String dosage =
                intent.getStringExtra(MedicationAlarmScheduler.EXTRA_DOSAGE);
        int hour =
                intent.getIntExtra(MedicationAlarmScheduler.EXTRA_HOUR, -1);
        int minute =
                intent.getIntExtra(MedicationAlarmScheduler.EXTRA_MINUTE, -1);
        int notificationId =
                intent.getIntExtra(EXTRA_NOTIFICATION_ID, 0);

        if (ACTION_SNOOZE.equals(intent.getAction())) {
            Medication medication = new Medication(
                    medicationId,
                    name,
                    dosage,
                    "",
                    "Daily",
                    true,
                    hour,
                    minute,
                    true,
                    0L,
                    0L
            );
            MedicationAlarmScheduler.scheduleSnooze(
                    context,
                    userId,
                    medication,
                    10 * 60 * 1000L
            );
            cancelNotification(context, notificationId);
            return;
        }

        if (!ACTION_MARK_TAKEN.equals(intent.getAction())
                || userId == null
                || userId.trim().isEmpty()) {
            cancelNotification(context, notificationId);
            return;
        }

        PendingResult pendingResult = goAsync();
        MedicationHistory history = new MedicationHistory(
                "",
                userId,
                medicationId,
                name,
                dosage,
                "taken",
                System.currentTimeMillis()
        );
        new MedicationRepository()
                .addHistory(userId, history)
                .addOnCompleteListener(task -> {
                    cancelNotification(context, notificationId);
                    pendingResult.finish();
                });
    }

    private static void cancelNotification(
            Context context,
            int notificationId
    ) {
        NotificationManager manager =
                (NotificationManager) context.getSystemService(
                        Context.NOTIFICATION_SERVICE
                );
        if (manager != null && notificationId != 0) {
            manager.cancel(notificationId);
        }
    }
}
