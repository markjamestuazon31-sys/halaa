package com.example.app.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.app.utils.MedicationAlarmScheduler;
import com.google.firebase.auth.FirebaseAuth;

public class MedicationBootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String userId = FirebaseAuth.getInstance().getUid();
        if (userId == null || userId.trim().isEmpty()) return;
        MedicationAlarmScheduler.rescheduleStoredReminders(
                context.getApplicationContext(),
                userId
        );
    }
}
