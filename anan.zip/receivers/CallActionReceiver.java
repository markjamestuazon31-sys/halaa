package com.example.app.receivers;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.app.repositories.CallRepository;

public class CallActionReceiver extends BroadcastReceiver {
    public static final String ACTION_DECLINE =
            "com.example.app.action.DECLINE_CALL";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_DECLINE.equals(intent.getAction())) {
            return;
        }

        String callId = intent.getStringExtra("callId");
        if (callId == null || callId.trim().isEmpty()) return;

        NotificationManager manager =
                context.getSystemService(NotificationManager.class);
        if (manager != null) manager.cancel(callId.hashCode());

        new CallRepository().updateStatus(callId, "rejected");
    }
}
