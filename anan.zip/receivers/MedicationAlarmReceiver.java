package com.example.app.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.app.models.Medication;
import com.example.app.utils.MedicationAlarmScheduler;
import com.example.app.services.MedicationReminderService;

public class MedicationAlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        String userId =
                intent.getStringExtra(MedicationAlarmScheduler.EXTRA_USER_ID);
        String medicationId =
                intent.getStringExtra(
                        MedicationAlarmScheduler.EXTRA_MEDICATION_ID
                );
        String name =
                intent.getStringExtra(
                        MedicationAlarmScheduler.EXTRA_MEDICINE_NAME
                );
        String dosage =
                intent.getStringExtra(MedicationAlarmScheduler.EXTRA_DOSAGE);
        int hour =
                intent.getIntExtra(MedicationAlarmScheduler.EXTRA_HOUR, -1);
        int minute =
                intent.getIntExtra(MedicationAlarmScheduler.EXTRA_MINUTE, -1);
        boolean snooze =
                intent.getBooleanExtra(
                        MedicationAlarmScheduler.EXTRA_SNOOZE,
                        false
                );

        Medication medication = new Medication(
                medicationId,
                name,
                dosage,
                "",
                "Daily",
                true,
                hour,
                minute,
                true,
                0L,
                0L
        );

        MedicationReminderService.showReminder(
                context,
                userId,
                medication
        );

        if (!snooze && medication.hasValidReminderTime()) {
            MedicationAlarmScheduler.scheduleDaily(
                    context,
                    userId,
                    medication
            );
        }
    }
}
