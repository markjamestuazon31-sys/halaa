package com.example.app.map;

/**
 * Single map-style source used by both the home preview and full family map.
 * It intentionally avoids generated BuildConfig fields so it compiles with
 * the user's current Gradle configuration.
 */
public final class MapConfiguration {
    private static final String MAPTILER_STYLE_URL =
            "https://api.maptiler.com/maps/openstreetmap/style.json"
                    + "?key=pAUZ5HV1EioQIuqNbiGZ";

    private static final String OFFLINE_STYLE_URL =
            "asset://healthmate_openstreetmap_style.json";

    private MapConfiguration() {
    }

    public static String styleUrl() {
        return MAPTILER_STYLE_URL;
    }

    public static String offlineStyleUrl() {
        return OFFLINE_STYLE_URL;
    }

    public static boolean usesMapTiler() {
        return MAPTILER_STYLE_URL.startsWith(
                "https://api.maptiler.com/"
        );
    }
}
