package com.example.app.map;

import android.os.Bundle;
import org.maplibre.android.maps.MapView;

public final class MapLifecycleController {
    private final MapView mapView;
    private boolean created,started,resumed,destroyed;
    public MapLifecycleController(MapView mapView){this.mapView=mapView;}
    public void onCreate(Bundle state){if(!created&&!destroyed){mapView.onCreate(state);created=true;}}
    public void onStart(){if(created&&!started&&!destroyed){mapView.onStart();started=true;}}
    public void onResume(){if(started&&!resumed&&!destroyed){mapView.onResume();resumed=true;}}
    public void onPause(){if(resumed&&!destroyed){mapView.onPause();resumed=false;}}
    public void onStop(){if(started&&!destroyed){if(resumed)onPause();mapView.onStop();started=false;}}
    public void onLowMemory(){if(created&&!destroyed)mapView.onLowMemory();}
    public void onDestroy(){if(created&&!destroyed){if(started)onStop();mapView.onDestroy();destroyed=true;}}
}
