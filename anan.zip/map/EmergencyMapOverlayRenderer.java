package com.example.app.map;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.app.models.ContactLocation;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.models.EmergencyMapOverlay;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.FeatureCollection;
import org.maplibre.geojson.LineString;
import org.maplibre.geojson.Point;

import org.maplibre.android.style.expressions.Expression;
import org.maplibre.android.style.layers.LineLayer;
import org.maplibre.android.style.layers.Property;
import org.maplibre.android.style.layers.SymbolLayer;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.android.maps.Style;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap;
import static org.maplibre.android.style.layers.PropertyFactory.iconAnchor;
import static org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement;
import static org.maplibre.android.style.layers.PropertyFactory.iconImage;
import static org.maplibre.android.style.layers.PropertyFactory.lineCap;
import static org.maplibre.android.style.layers.PropertyFactory.lineColor;
import static org.maplibre.android.style.layers.PropertyFactory.lineDasharray;
import static org.maplibre.android.style.layers.PropertyFactory.lineJoin;
import static org.maplibre.android.style.layers.PropertyFactory.lineOpacity;
import static org.maplibre.android.style.layers.PropertyFactory.lineWidth;

/** Draws the incident-only red SOS layer without changing normal contact pins. */
public final class EmergencyMapOverlayRenderer {

    private static final String POINT_SOURCE_ID =
            "healthmate-emergency-overlay-points";
    private static final String LINE_SOURCE_ID =
            "healthmate-emergency-overlay-lines";
    private static final String LINE_LAYER_ID =
            "healthmate-emergency-overlay-line-layer";
    private static final String POINT_LAYER_ID =
            "healthmate-emergency-overlay-point-layer";
    private static final String SOS_ICON_ID =
            "healthmate-sos-red-pin-v1";

    private final Context context;

    private Style style;
    private GeoJsonSource pointSource;
    private GeoJsonSource lineSource;

    public EmergencyMapOverlayRenderer(@NonNull Context context) {
        this.context = context.getApplicationContext();
    }

    public void attach(@NonNull Style style) {
        this.style = style;

        pointSource = style.getSourceAs(POINT_SOURCE_ID);
        if (pointSource == null) {
            pointSource = new GeoJsonSource(
                    POINT_SOURCE_ID,
                    FeatureCollection.fromFeatures(new Feature[0])
            );
            style.addSource(pointSource);
        }

        lineSource = style.getSourceAs(LINE_SOURCE_ID);
        if (lineSource == null) {
            lineSource = new GeoJsonSource(
                    LINE_SOURCE_ID,
                    FeatureCollection.fromFeatures(new Feature[0])
            );
            style.addSource(lineSource);
        }

        if (style.getImage(SOS_ICON_ID) == null) {
            style.addImage(SOS_ICON_ID, createSosMarker());
        }

        if (style.getLayer(LINE_LAYER_ID) == null) {
            LineLayer lineLayer = new LineLayer(
                    LINE_LAYER_ID,
                    LINE_SOURCE_ID
            ).withProperties(
                    lineColor("#E11F2A"),
                    lineWidth(4.5f),
                    lineOpacity(0.88f),
                    lineDasharray(new Float[]{1.3f, 1.1f}),
                    lineCap(Property.LINE_CAP_ROUND),
                    lineJoin(Property.LINE_JOIN_ROUND)
            );
            style.addLayer(lineLayer);
        }

        if (style.getLayer(POINT_LAYER_ID) == null) {
            SymbolLayer pointLayer = new SymbolLayer(
                    POINT_LAYER_ID,
                    POINT_SOURCE_ID
            ).withProperties(
                    iconImage(Expression.image(Expression.get("iconId"))),
                    iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                    iconAllowOverlap(true),
                    iconIgnorePlacement(true)
            );
            style.addLayer(pointLayer);
        }
    }

    public void render(
            @Nullable List<EmergencyMapOverlay> emergencies,
            @Nullable ContactLocation viewerLocation
    ) {
        if (style == null || pointSource == null || lineSource == null) {
            return;
        }

        List<Feature> points = new ArrayList<>();
        List<Feature> lines = new ArrayList<>();
        Point viewerPoint = valid(viewerLocation)
                ? Point.fromLngLat(
                        viewerLocation.getLongitude(),
                        viewerLocation.getLatitude()
                )
                : null;

        if (emergencies != null) {
            for (EmergencyMapOverlay emergency : emergencies) {
                if (emergency == null || !emergency.hasValidLocation()) {
                    continue;
                }

                EmergencyLocationPoint location =
                        emergency.getPatientLocation();
                if (location == null) {
                    continue;
                }

                Point emergencyPoint = Point.fromLngLat(
                        location.getLongitude(),
                        location.getLatitude()
                );
                Feature pointFeature = Feature.fromGeometry(emergencyPoint);
                pointFeature.addStringProperty(
                        "incidentId",
                        safe(emergency.getIncidentId())
                );
                pointFeature.addStringProperty(
                        "patientName",
                        safe(emergency.getPatientName())
                );
                pointFeature.addStringProperty(
                        "status",
                        safe(emergency.getStatus())
                );
                pointFeature.addStringProperty("iconId", SOS_ICON_ID);
                pointFeature.addNumberProperty(
                        "updatedAt",
                        emergency.getDisplayTimestamp()
                );
                points.add(pointFeature);

                if (viewerPoint != null) {
                    Feature lineFeature = Feature.fromGeometry(
                            LineString.fromLngLats(Arrays.asList(
                                    viewerPoint,
                                    emergencyPoint
                            ))
                    );
                    lineFeature.addStringProperty(
                            "incidentId",
                            safe(emergency.getIncidentId())
                    );
                    lines.add(lineFeature);
                }
            }
        }

        pointSource.setGeoJson(FeatureCollection.fromFeatures(points));
        lineSource.setGeoJson(FeatureCollection.fromFeatures(lines));
    }

    public void clear() {
        if (pointSource != null) {
            pointSource.setGeoJson(FeatureCollection.fromFeatures(
                    new Feature[0]
            ));
        }
        if (lineSource != null) {
            lineSource.setGeoJson(FeatureCollection.fromFeatures(
                    new Feature[0]
            ));
        }
    }

    private Bitmap createSosMarker() {
        int width = dp(76);
        int height = dp(94);
        float centerX = width / 2f;
        float centerY = dp(35);
        float radius = dp(31);

        Bitmap bitmap = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
        );
        bitmap.setDensity(context.getResources()
                .getDisplayMetrics().densityDpi);

        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        Path tail = new Path();
        tail.moveTo(centerX - dp(13), centerY + dp(22));
        tail.lineTo(centerX + dp(13), centerY + dp(22));
        tail.lineTo(centerX, height - dp(3));
        tail.close();
        paint.setColor(Color.parseColor("#E11F2A"));
        canvas.drawPath(tail, paint);

        paint.setColor(Color.parseColor("#E11F2A"));
        canvas.drawCircle(centerX, centerY, radius, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(4));
        paint.setColor(Color.WHITE);
        canvas.drawCircle(centerX, centerY, radius - dp(4), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(15));
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float baseline = centerY
                - (metrics.ascent + metrics.descent) / 2f;
        canvas.drawText("SOS", centerX, baseline, paint);

        return bitmap;
    }

    private boolean valid(@Nullable ContactLocation location) {
        return location != null
                && Double.isFinite(location.getLatitude())
                && Double.isFinite(location.getLongitude())
                && location.getLatitude() >= -90d
                && location.getLatitude() <= 90d
                && location.getLongitude() >= -180d
                && location.getLongitude() <= 180d;
    }

    private int dp(float value) {
        return Math.round(value * context.getResources()
                .getDisplayMetrics().density);
    }

    private String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }
}
