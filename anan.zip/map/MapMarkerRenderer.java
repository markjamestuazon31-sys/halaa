package com.example.app.map;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.Base64;

import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.ContactLocation;

import org.maplibre.android.style.expressions.Expression;
import org.maplibre.android.style.layers.Property;
import org.maplibre.android.style.layers.SymbolLayer;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.android.maps.Style;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.FeatureCollection;
import org.maplibre.geojson.Point;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import static org.maplibre.android.style.layers.PropertyFactory.iconAllowOverlap;
import static org.maplibre.android.style.layers.PropertyFactory.iconAnchor;
import static org.maplibre.android.style.layers.PropertyFactory.iconIgnorePlacement;
import static org.maplibre.android.style.layers.PropertyFactory.iconImage;

/**
 * Renders every location as a profile-photo map pin. A colored initial marker
 * is generated when no account photograph exists.
 */
public final class MapMarkerRenderer {
    private static final String SOURCE_ID =
            "healthmate-contact-locations";
    private static final String LAYER_ID =
            "healthmate-contact-profile-pins";

    private final Context context;
    private final Set<String> registeredImages = new HashSet<>();

    private Style style;
    private GeoJsonSource source;

    public MapMarkerRenderer(Context context) {
        this.context = context.getApplicationContext();
    }

    public void attach(Style style) {
        this.style = style;
        registeredImages.clear();

        source = style.getSourceAs(SOURCE_ID);
        if (source == null) {
            source = new GeoJsonSource(
                    SOURCE_ID,
                    FeatureCollection.fromFeatures(new Feature[0])
            );
            style.addSource(source);
        }

        if (style.getLayer(LAYER_ID) == null) {
            SymbolLayer layer = new SymbolLayer(LAYER_ID, SOURCE_ID)
                    .withProperties(
                            iconImage(Expression.image(Expression.get("iconId"))),
                            iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                            iconAllowOverlap(true),
                            iconIgnorePlacement(true)
                    );
            style.addLayer(layer);
        }
    }

    public void render(List<ContactLocation> locations) {
        if (source == null || style == null) {
            return;
        }

        List<Feature> features = new ArrayList<>();

        if (locations != null) {
            for (ContactLocation location : locations) {
                if (!valid(location)) {
                    continue;
                }

                String iconId = iconId(location);
                registerIcon(iconId, location);

                Feature feature = Feature.fromGeometry(
                        Point.fromLngLat(
                                location.getLongitude(),
                                location.getLatitude()
                        )
                );

                feature.addStringProperty("uid", safe(location.getUid()));
                feature.addStringProperty(
                        "name",
                        safe(location.getDisplayName())
                );
                feature.addStringProperty(
                        "relationshipType",
                        safe(location.getRelationshipType())
                );
                feature.addStringProperty("iconId", iconId);
                feature.addNumberProperty(
                        "updatedAt",
                        location.getUpdatedAt()
                );
                features.add(feature);
            }
        }

        source.setGeoJson(FeatureCollection.fromFeatures(features));
    }

    private void registerIcon(
            String iconId,
            ContactLocation location
    ) {
        if (registeredImages.contains(iconId)
                && style.getImage(iconId) != null) {
            return;
        }

        Bitmap marker = createProfilePin(location);
        style.addImage(iconId, marker);
        registeredImages.add(iconId);
    }

    private Bitmap createProfilePin(ContactLocation location) {
        int width = dp(62);
        int height = dp(78);
        int centerX = width / 2;
        float circleCenterY = dp(29);
        float outerRadius = dp(26);
        float whiteRadius = dp(23);
        float avatarRadius = dp(20.5f);

        Bitmap output = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
        );
        output.setDensity(context.getResources()
                .getDisplayMetrics().densityDpi);

        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int accent = markerColor(location.getRelationshipType());

        Path tail = new Path();
        tail.moveTo(centerX - dp(10), circleCenterY + dp(18));
        tail.lineTo(centerX + dp(10), circleCenterY + dp(18));
        tail.lineTo(centerX, height - dp(2));
        tail.close();
        paint.setColor(accent);
        canvas.drawPath(tail, paint);

        paint.setColor(accent);
        canvas.drawCircle(
                centerX,
                circleCenterY,
                outerRadius,
                paint
        );

        paint.setColor(Color.WHITE);
        canvas.drawCircle(
                centerX,
                circleCenterY,
                whiteRadius,
                paint
        );

        Bitmap avatar = decodeProfileImage(
                location.getProfileImage()
        );

        if (avatar != null) {
            drawCenterCropCircle(
                    canvas,
                    avatar,
                    centerX,
                    circleCenterY,
                    avatarRadius
            );
        } else {
            paint.setColor(accent);
            canvas.drawCircle(
                    centerX,
                    circleCenterY,
                    avatarRadius,
                    paint
            );

            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            paint.setTextSize(dp(15));

            Paint.FontMetrics metrics = paint.getFontMetrics();
            float baseline = circleCenterY
                    - (metrics.ascent + metrics.descent) / 2f;

            canvas.drawText(
                    initials(location.getDisplayName()),
                    centerX,
                    baseline,
                    paint
            );
        }

        return output;
    }

    private void drawCenterCropCircle(
            Canvas canvas,
            Bitmap sourceBitmap,
            float centerX,
            float centerY,
            float radius
    ) {
        BitmapShader shader = new BitmapShader(
                sourceBitmap,
                Shader.TileMode.CLAMP,
                Shader.TileMode.CLAMP
        );

        float diameter = radius * 2f;
        float scale = Math.max(
                diameter / sourceBitmap.getWidth(),
                diameter / sourceBitmap.getHeight()
        );

        float scaledWidth = sourceBitmap.getWidth() * scale;
        float scaledHeight = sourceBitmap.getHeight() * scale;

        Matrix matrix = new Matrix();
        matrix.setScale(scale, scale);
        matrix.postTranslate(
                centerX - scaledWidth / 2f,
                centerY - scaledHeight / 2f
        );
        shader.setLocalMatrix(matrix);

        Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        imagePaint.setShader(shader);
        canvas.drawCircle(centerX, centerY, radius, imagePaint);
    }

    private Bitmap decodeProfileImage(String raw) {
        String value = safe(raw);
        if (value.isEmpty()) {
            return null;
        }

        int comma = value.indexOf(',');
        if (comma >= 0 && comma + 1 < value.length()) {
            value = value.substring(comma + 1);
        }

        try {
            byte[] bytes = Base64.decode(value, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(
                    bytes,
                    0,
                    bytes.length
            );
        } catch (IllegalArgumentException error) {
            return null;
        }
    }

    private String iconId(ContactLocation location) {
        String uid = safe(location.getUid()).replaceAll(
                "[^A-Za-z0-9_-]",
                "_"
        );
        String imageSignature = Integer.toHexString(
                safe(location.getProfileImage()).hashCode()
        );
        String relationship = safe(location.getRelationshipType())
                .toLowerCase(Locale.US);
        return "healthmate-pin-"
                + uid
                + "-"
                + relationship
                + "-"
                + imageSignature;
    }

    private int markerColor(String relationshipType) {
        String type = safe(relationshipType).toUpperCase(Locale.US);
        if ("SELF".equals(type)) {
            return Color.parseColor("#1565C0");
        }
        if (RelationshipPolicy.FRIEND.equals(type)) {
            return Color.parseColor("#6E56B5");
        }
        return Color.parseColor("#0B9D8F");
    }

    private String initials(String name) {
        String value = safe(name);
        if (value.isEmpty()) {
            return "H";
        }

        String[] parts = value.split("\\s+");
        if (parts.length >= 2) {
            return (first(parts[0]) + first(parts[1]))
                    .toUpperCase(Locale.US);
        }
        return value.substring(0, Math.min(2, value.length()))
                .toUpperCase(Locale.US);
    }

    private String first(String value) {
        return value == null || value.isEmpty()
                ? ""
                : value.substring(0, 1);
    }

    private boolean valid(ContactLocation location) {
        return location != null
                && Double.isFinite(location.getLatitude())
                && Double.isFinite(location.getLongitude())
                && location.getLatitude() >= -90d
                && location.getLatitude() <= 90d
                && location.getLongitude() >= -180d
                && location.getLongitude() <= 180d;
    }

    private int dp(float value) {
        return Math.round(
                value * context.getResources()
                        .getDisplayMetrics().density
        );
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
