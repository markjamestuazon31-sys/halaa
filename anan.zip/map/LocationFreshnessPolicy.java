package com.example.app.map;

public final class LocationFreshnessPolicy {
    public enum Freshness { CURRENT, AGING, STALE, UNKNOWN }
    private LocationFreshnessPolicy() { }
    public static Freshness classify(long updatedAt, long now) {
        if (updatedAt <= 0 || now < updatedAt) return Freshness.UNKNOWN;
        long age = now - updatedAt;
        if (age <= 60_000L) return Freshness.CURRENT;
        if (age <= 120_000L) return Freshness.AGING;
        return Freshness.STALE;
    }
}
