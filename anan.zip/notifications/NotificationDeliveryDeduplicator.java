package com.example.app.notifications;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import java.util.Map;

/** Cross-service deduplication for RTDB foreground alerts and FCM delivery. */
public final class NotificationDeliveryDeduplicator {

    private static final String PREFERENCES =
            "healthmate_notification_delivery_dedupe";
    private static final long RETENTION_MS =
            7L * 24L * 60L * 60L * 1000L;

    private NotificationDeliveryDeduplicator() {
        // Utility class.
    }

    public static boolean claim(
            @NonNull Context context,
            @NonNull String notificationId
    ) {
        String key = notificationId.trim();
        if (key.isEmpty()) {
            return true;
        }

        SharedPreferences preferences = context.getSharedPreferences(
                PREFERENCES,
                Context.MODE_PRIVATE
        );
        long now = System.currentTimeMillis();
        if (preferences.contains(key)) {
            return false;
        }

        SharedPreferences.Editor editor = preferences.edit();
        for (Map.Entry<String, ?> entry
                : preferences.getAll().entrySet()) {
            Object value = entry.getValue();
            if (value instanceof Long
                    && now - (Long) value > RETENTION_MS) {
                editor.remove(entry.getKey());
            }
        }
        editor.putLong(key, now).apply();
        return true;
    }
}
