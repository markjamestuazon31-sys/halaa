package com.example.app.notifications;

import android.os.Build;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.messaging.FirebaseMessaging;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public final class TokenRegistrationManager {

    private TokenRegistrationManager() {
    }

    /** Call this after a successful login and whenever the notification screen opens. */
    public static void syncCurrentToken() {
        FirebaseMessaging.getInstance()
                .getToken()
                .addOnSuccessListener(TokenRegistrationManager::saveToken);
    }

    /** Called by FirebaseMessagingService when FCM rotates the registration token. */
    public static void saveToken(@NonNull String token) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null || token.trim().isEmpty()) {
            return;
        }

        Map<String, Object> record = new HashMap<>();
        record.put("token", token);
        record.put("platform", "android");
        record.put("device", Build.MANUFACTURER + " " + Build.MODEL);
        record.put("active", true);
        record.put("updatedAt", ServerValue.TIMESTAMP);

        tokenReference(uid, token).setValue(record);
    }

    /** Call this before FirebaseAuth.signOut() to stop notifications for the old account. */
    public static void unregisterCurrentToken(@NonNull Runnable completion) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            completion.run();
            return;
        }

        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful() || task.getResult() == null) {
                        completion.run();
                        return;
                    }

                    tokenReference(uid, task.getResult())
                            .removeValue()
                            .addOnCompleteListener(removeTask -> completion.run());
                });
    }

    @NonNull
    private static DatabaseReference tokenReference(
            @NonNull String uid,
            @NonNull String token
    ) {
        return FirebaseDatabase.getInstance()
                .getReference("fcmTokens")
                .child(uid)
                .child(sha256(token));
    }

    @NonNull
    private static String sha256(@NonNull String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder(bytes.length * 2);
            for (byte item : bytes) {
                result.append(String.format("%02x", item));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is unavailable", impossible);
        }
    }
}
