package com.example.app.notifications;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Locale;

/** Categories used by the notification screen tabs. */
public enum NotificationCategory {
    ALERTS,
    CALLS,
    ACCOUNT;

    @NonNull
    public static NotificationCategory fromType(@Nullable String type) {
        String normalized = type == null
                ? ""
                : type.trim().toLowerCase(Locale.US);

        if (normalized.contains("call")) {
            return CALLS;
        }

        if (normalized.startsWith("account")
                || normalized.startsWith("profile")
                || normalized.startsWith("security")
                || normalized.startsWith("contact_")
                || normalized.equals("contact_request")
                || normalized.equals("contact_accepted")) {
            return ACCOUNT;
        }

        return ALERTS;
    }
}
