package com.example.app.notifications;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.NonNull;

import com.example.app.R;

import java.util.Locale;

public final class NotificationChannelManager {

    /**
     * Versioned IDs are intentional. Android does not let an app silently raise
     * the importance or sound of a channel that was already created by an older build.
     */
    public static final String CHANNEL_URGENT = "healthmate_urgent_v2";
    public static final String CHANNEL_GENERAL = "healthmate_general_v2";

    private NotificationChannelManager() {
    }

    public static void ensureCreated(@NonNull Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationManager manager =
                context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmSound == null) {
            alarmSound = RingtoneManager.getDefaultUri(
                    RingtoneManager.TYPE_NOTIFICATION
            );
        }

        AudioAttributes urgentAudioAttributes = new AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build();

        NotificationChannel urgent = new NotificationChannel(
                CHANNEL_URGENT,
                context.getString(R.string.hm_notify_channel_urgent_name),
                NotificationManager.IMPORTANCE_HIGH
        );
        urgent.setDescription(
                context.getString(R.string.hm_notify_channel_urgent_description)
        );
        urgent.enableLights(true);
        urgent.enableVibration(true);
        urgent.setVibrationPattern(new long[]{0L, 500L, 250L, 500L, 250L, 800L});
        urgent.setSound(alarmSound, urgentAudioAttributes);
        urgent.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

        NotificationChannel general = new NotificationChannel(
                CHANNEL_GENERAL,
                context.getString(R.string.hm_notify_channel_general_name),
                NotificationManager.IMPORTANCE_DEFAULT
        );
        general.setDescription(
                context.getString(R.string.hm_notify_channel_general_description)
        );
        general.enableVibration(true);
        general.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        manager.createNotificationChannel(urgent);
        manager.createNotificationChannel(general);
    }

    public static boolean isUrgentType(String type) {
        if (type == null) {
            return false;
        }
        String normalized = type.trim().toLowerCase(Locale.US);
        return normalized.equals("emergency_sos")
                || normalized.equals("emergency_alert")
                || normalized.startsWith("sos")
                || normalized.equals("incoming_call")
                || normalized.equals("alert")
                || normalized.equals("critical_alert")
                || normalized.equals("emergency_backup");
    }
}
