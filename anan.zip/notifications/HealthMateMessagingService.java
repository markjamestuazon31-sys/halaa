package com.example.app.notifications;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.app.R;
import com.example.app.activities.AnnouncementActivity;
import com.example.app.activities.CallActivity;
import com.example.app.activities.ChatActivity;
import com.example.app.activities.EmergencyContactsActivity;
import com.example.app.activities.FamilyTrackingMapActivity;
import com.example.app.activities.NotificationActivity;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class HealthMateMessagingService extends FirebaseMessagingService {

    private static final String DEDUPE_PREFERENCES = "healthmate_fcm_dedupe";
    private static final long DEDUPE_RETENTION_MS = 7L * 24L * 60L * 60L * 1000L;

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        TokenRegistrationManager.saveToken(token);
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        Map<String, String> data = remoteMessage.getData();
        String notificationId = firstNonBlank(
                data.get("notificationId"),
                remoteMessage.getMessageId(),
                String.valueOf(System.currentTimeMillis())
        );

        if (isDuplicate(notificationId)) {
            return;
        }

        String type = safe(data.get("type"));
        boolean urgent = NotificationChannelManager.isUrgentType(type);

        String title = firstNonBlank(
                data.get("title"),
                remoteMessage.getNotification() == null
                        ? null
                        : remoteMessage.getNotification().getTitle(),
                getString(R.string.app_name)
        );
        String body = firstNonBlank(
                data.get("message"),
                data.get("body"),
                remoteMessage.getNotification() == null
                        ? null
                        : remoteMessage.getNotification().getBody(),
                getString(R.string.hm_notify_default_body)
        );

        NotificationChannelManager.ensureCreated(this);
        PendingIntent contentIntent = buildContentIntent(type, data, notificationId);

        String channelId = urgent
                ? NotificationChannelManager.CHANNEL_URGENT
                : NotificationChannelManager.CHANNEL_GENERAL;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_healthmate_notification_small)
                .setColor(ContextCompat.getColor(this, R.color.hm_notify_teal))
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setVisibility(
                        urgent
                                ? NotificationCompat.VISIBILITY_PUBLIC
                                : NotificationCompat.VISIBILITY_PRIVATE
                )
                .setPriority(
                        urgent
                                ? NotificationCompat.PRIORITY_MAX
                                : NotificationCompat.PRIORITY_DEFAULT
                )
                .setCategory(resolveCategory(type));

        if (urgent) {
            builder.setVibrate(new long[]{0L, 500L, 250L, 500L, 250L, 800L});
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                builder.setSound(
                        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                );
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        NotificationManagerCompat.from(this).notify(
                stableNotificationId(notificationId),
                builder.build()
        );
    }

    @NonNull
    private PendingIntent buildContentIntent(
            @NonNull String type,
            @NonNull Map<String, String> data,
            @NonNull String notificationId
    ) {
        Intent intent;

        if ("announcement".equals(type)) {
            intent = new Intent(this, AnnouncementActivity.class)
                    .putExtra("announcementId", data.get("announcementId"));
        } else if ("incoming_call".equals(type)) {
            intent = new Intent(this, CallActivity.class)
                    .putExtra("callId", data.get("callId"))
                    .putExtra("incoming", true);
        } else if ("contact_request".equals(type)
                || "contact_accepted".equals(type)) {
            intent = new Intent(this, EmergencyContactsActivity.class);
        } else if ("chat_message".equals(type)) {
            intent = new Intent(this, ChatActivity.class)
                    .putExtra("receiverId", data.get("createdBy"));
        } else if (type.startsWith("emergency") || type.startsWith("sos")) {
            String incidentId = firstNonBlank(
                    data.get("incidentId"),
                    data.get("emergencyId")
            );
            intent = new Intent(this, FamilyTrackingMapActivity.class)
                    .putExtra(
                            "userId",
                            firstNonBlank(data.get("createdBy"), data.get("userId"))
                    )
                    .putExtra("incidentId", incidentId)
                    .putExtra("emergencyId", incidentId);
        } else {
            intent = new Intent(this, NotificationActivity.class);
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("notificationId", notificationId);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        return PendingIntent.getActivity(
                this,
                stableNotificationId(notificationId),
                intent,
                flags
        );
    }

    @NonNull
    private String resolveCategory(@NonNull String type) {
        if ("incoming_call".equals(type)) {
            return NotificationCompat.CATEGORY_CALL;
        }
        if (NotificationChannelManager.isUrgentType(type)) {
            return NotificationCompat.CATEGORY_ALARM;
        }
        if (type.startsWith("emergency") || type.startsWith("sos")) {
            return NotificationCompat.CATEGORY_STATUS;
        }
        if ("chat_message".equals(type)) {
            return NotificationCompat.CATEGORY_MESSAGE;
        }
        return NotificationCompat.CATEGORY_STATUS;
    }

    private boolean isDuplicate(@NonNull String notificationId) {
        SharedPreferences preferences = getSharedPreferences(
                DEDUPE_PREFERENCES,
                Context.MODE_PRIVATE
        );
        long now = System.currentTimeMillis();

        if (preferences.contains(notificationId)) {
            return true;
        }

        SharedPreferences.Editor editor = preferences.edit();
        for (Map.Entry<String, ?> entry : preferences.getAll().entrySet()) {
            Object value = entry.getValue();
            if (value instanceof Long && now - (Long) value > DEDUPE_RETENTION_MS) {
                editor.remove(entry.getKey());
            }
        }
        editor.putLong(notificationId, now).apply();
        return false;
    }

    private int stableNotificationId(@NonNull String value) {
        return value.hashCode() & 0x7fffffff;
    }

    @NonNull
    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    @NonNull
    private String firstNonBlank(String... candidates) {
        for (String candidate : candidates) {
            if (candidate != null && !candidate.trim().isEmpty()) {
                return candidate.trim();
            }
        }
        return "";
    }
}
