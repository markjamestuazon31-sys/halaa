package com.example.app.models;

import java.util.HashMap;
import java.util.Map;

public class EmergencyIncident {
    private String id;
    private String clientRequestId;
    private String patientUid;
    private String patientName;
    private String patientPhone;
    private String assignedBarangayId;
    private String type;
    private String description;
    private String severity;
    private String priority;
    private String status;
    private String coordinatorResponderId;
    private Map<String, Object> locationSummary;
    private long createdAt;
    private long updatedAt;
    private long closedAt;
    private long cancelledAt;
    public EmergencyIncident() { }
    public static EmergencyIncident createSos(String id, User user, String barangayName) {
        long now = System.currentTimeMillis();
        EmergencyIncident incident = new EmergencyIncident();
        incident.id = id; incident.clientRequestId = id;
        incident.patientUid = user.getUid(); incident.patientName = user.getFullName(); incident.patientPhone = user.getPhone();
        incident.assignedBarangayId = user.getAssignedBarangayId(); incident.type = "SOS Alert";
        incident.description = "Emergency assistance requested from the HealthMate Android app.";
        incident.severity = "HIGH"; incident.priority = "HIGH"; incident.status = "PENDING";
        incident.locationSummary = new HashMap<>();
        incident.locationSummary.put("barangayId", user.getAssignedBarangayId());
        incident.locationSummary.put("barangayName", barangayName == null ? "" : barangayName);
        incident.locationSummary.put("description", "Exact coordinates are available only to authorized incident participants.");
        incident.createdAt = now; incident.updatedAt = now;
        return incident;
    }
    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getClientRequestId() { return clientRequestId; } public void setClientRequestId(String value) { clientRequestId = value; }
    public String getPatientUid() { return patientUid; } public void setPatientUid(String value) { patientUid = value; }
    public String getPatientName() { return patientName; } public void setPatientName(String value) { patientName = value; }
    public String getPatientPhone() { return patientPhone; } public void setPatientPhone(String value) { patientPhone = value; }
    public String getAssignedBarangayId() { return assignedBarangayId; } public void setAssignedBarangayId(String value) { assignedBarangayId = value; }
    public String getType() { return type; } public void setType(String value) { type = value; }
    public String getDescription() { return description; } public void setDescription(String value) { description = value; }
    public String getSeverity() { return severity; } public void setSeverity(String value) { severity = value; }
    public String getPriority() { return priority; } public void setPriority(String value) { priority = value; }
    public String getStatus() { return status; } public void setStatus(String value) { status = value; }
    public String getCoordinatorResponderId() { return coordinatorResponderId; } public void setCoordinatorResponderId(String value) { coordinatorResponderId = value; }
    public Map<String, Object> getLocationSummary() { return locationSummary; } public void setLocationSummary(Map<String, Object> value) { locationSummary = value; }
    public long getCreatedAt() { return createdAt; } public void setCreatedAt(long value) { createdAt = value; }
    public long getUpdatedAt() { return updatedAt; } public void setUpdatedAt(long value) { updatedAt = value; }
    public long getClosedAt() { return closedAt; } public void setClosedAt(long value) { closedAt = value; }
    public long getCancelledAt() { return cancelledAt; } public void setCancelledAt(long value) { cancelledAt = value; }
}
