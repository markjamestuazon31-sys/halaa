package com.example.app.models;

public class MedicationHistory {

    private String id;
    private String userId;
    private String medicationId;
    private String medicineName;
    private String dosage;
    private String status;
    private long timestamp;

    public MedicationHistory() {
        // Required by Firebase Realtime Database.
    }

    public MedicationHistory(
            String id,
            String userId,
            String medicationId,
            String medicineName,
            String dosage,
            String status,
            long timestamp
    ) {
        this.id = id;
        this.userId = userId;
        this.medicationId = medicationId;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getMedicationId() { return medicationId; }
    public void setMedicationId(String medicationId) { this.medicationId = medicationId; }
    public String getMedicineName() { return medicineName; }
    public void setMedicineName(String medicineName) { this.medicineName = medicineName; }
    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
