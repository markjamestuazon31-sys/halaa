package com.example.app.models;


public class EmergencyContact {


    private String uid;

    private String name;

    private String phone;

    private String status;

    private boolean accepted;



    public EmergencyContact(){}



    public EmergencyContact(
            String uid,
            String name,
            String phone,
            String status,
            boolean accepted
    ){

        this.uid = uid;
        this.name = name;
        this.phone = phone;
        this.status = status;
        this.accepted = accepted;

    }



    public String getUid(){

        return uid;

    }


    public String getName(){

        return name;

    }


    public String getPhone(){

        return phone;

    }


    public String getStatus(){

        return status;

    }


    public boolean isAccepted(){

        return accepted;

    }


}