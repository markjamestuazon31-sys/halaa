package com.example.app.models;

public class ResponderProfile {
    private String authUid;
    private String role;
    private String accountStatus;
    private String name;
    private String email;
    private String contact;
    private String address;
    private String position;
    private String assignedBarangayId;
    private String serviceArea;
    private String respondentInvitationKey;
    private String availability;
    private long createdAt;
    private long updatedAt;
    public ResponderProfile() { }
    public String getAuthUid() { return authUid; }
    public void setAuthUid(String authUid) { this.authUid = authUid; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getAccountStatus() { return accountStatus; }
    public void setAccountStatus(String accountStatus) { this.accountStatus = accountStatus; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    public String getAssignedBarangayId() { return assignedBarangayId; }
    public void setAssignedBarangayId(String assignedBarangayId) { this.assignedBarangayId = assignedBarangayId; }
    public String getServiceArea() { return serviceArea; }
    public void setServiceArea(String serviceArea) { this.serviceArea = serviceArea; }
    public String getRespondentInvitationKey() { return respondentInvitationKey; }
    public void setRespondentInvitationKey(String respondentInvitationKey) { this.respondentInvitationKey = respondentInvitationKey; }
    public String getAvailability() { return availability; }
    public void setAvailability(String availability) { this.availability = availability; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
