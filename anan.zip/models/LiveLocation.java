package com.example.app.models;


public class LiveLocation {


    private double latitude;

    private double longitude;

    private long timestamp;

    private boolean online;

    private boolean emergency;



    public LiveLocation(){}




    public LiveLocation(
            double latitude,
            double longitude,
            long timestamp,
            boolean online,
            boolean emergency
    ){

        this.latitude = latitude;

        this.longitude = longitude;

        this.timestamp = timestamp;

        this.online = online;

        this.emergency = emergency;

    }



    public double getLatitude(){

        return latitude;

    }


    public double getLongitude(){

        return longitude;

    }


    public long getTimestamp(){

        return timestamp;

    }


    public boolean isOnline(){

        return online;

    }


    public boolean isEmergency(){

        return emergency;

    }

}