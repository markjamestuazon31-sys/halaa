package com.example.app.models;

public class ContactPublicProfile {
    private String uid;
    private String fullName;
    private String profileImage;
    private String role;
    private long updatedAt;
    public ContactPublicProfile() { }
    public ContactPublicProfile(String uid, String fullName, String profileImage, String role, long updatedAt) {
        this.uid = uid; this.fullName = fullName; this.profileImage = profileImage; this.role = role; this.updatedAt = updatedAt;
    }
    public String getUid() { return uid; } public void setUid(String uid) { this.uid = uid; }
    public String getFullName() { return fullName; } public void setFullName(String fullName) { this.fullName = fullName; }
    public String getProfileImage() { return profileImage; } public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
    public String getRole() { return role; } public void setRole(String role) { this.role = role; }
    public long getUpdatedAt() { return updatedAt; } public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
