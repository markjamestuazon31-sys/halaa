package com.example.app.models;


public class Friend {


    private String friendId;

    private String status;

    private long timestamp;



    public Friend(){}



    public Friend(
            String friendId,
            String status,
            long timestamp
    ){

        this.friendId = friendId;

        this.status = status;

        this.timestamp = timestamp;

    }



    public String getFriendId(){

        return friendId;

    }



    public void setFriendId(String friendId){

        this.friendId = friendId;

    }



    public String getStatus(){

        return status;

    }



    public void setStatus(String status){

        this.status=status;

    }



    public long getTimestamp(){

        return timestamp;

    }



    public void setTimestamp(long timestamp){

        this.timestamp=timestamp;

    }



}