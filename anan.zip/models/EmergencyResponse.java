package com.example.app.models;

public class EmergencyResponse {
    private String responderUid;
    private String responderName;
    private String teamRole;
    private String responseStatus;
    private long acceptedAt;
    private long updatedAt;
    private long lastLocationUpdate;
    private String notes;
    private boolean backupRequested;
    private boolean active;
    public EmergencyResponse() { }
    public String getResponderUid() { return responderUid; } public void setResponderUid(String value) { responderUid = value; }
    public String getResponderName() { return responderName; } public void setResponderName(String value) { responderName = value; }
    public String getTeamRole() { return teamRole; } public void setTeamRole(String value) { teamRole = value; }
    public String getResponseStatus() { return responseStatus; } public void setResponseStatus(String value) { responseStatus = value; }
    public long getAcceptedAt() { return acceptedAt; } public void setAcceptedAt(long value) { acceptedAt = value; }
    public long getUpdatedAt() { return updatedAt; } public void setUpdatedAt(long value) { updatedAt = value; }
    public long getLastLocationUpdate() { return lastLocationUpdate; } public void setLastLocationUpdate(long value) { lastLocationUpdate = value; }
    public String getNotes() { return notes; } public void setNotes(String value) { notes = value; }
    public boolean isBackupRequested() { return backupRequested; } public void setBackupRequested(boolean value) { backupRequested = value; }
    public boolean isActive() { return active; } public void setActive(boolean value) { active = value; }
}
