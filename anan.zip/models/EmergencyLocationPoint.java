package com.example.app.models;

public class EmergencyLocationPoint {
    private double latitude;
    private double longitude;
    private float accuracy;
    private long updatedAt;
    public EmergencyLocationPoint() { }
    public EmergencyLocationPoint(double latitude, double longitude, float accuracy, long updatedAt) {
        this.latitude = latitude; this.longitude = longitude; this.accuracy = accuracy; this.updatedAt = updatedAt;
    }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public float getAccuracy() { return accuracy; }
    public void setAccuracy(float accuracy) { this.accuracy = accuracy; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
