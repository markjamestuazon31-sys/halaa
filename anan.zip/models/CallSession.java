package com.example.app.models;

public class CallSession {

    private String callId;
    private String callerId;
    private String receiverId;
    private String type;
    private String status;
    private long createdAt;
    private long updatedAt;

    public CallSession() { }

    public CallSession(String callId, String callerId, String receiverId, String type, String status, long timestamp) {
        this.callId = callId;
        this.callerId = callerId;
        this.receiverId = receiverId;
        this.type = type;
        this.status = status;
        this.createdAt = timestamp;
        this.updatedAt = timestamp;
    }

    public String getCallId() { return callId; }
    public void setCallId(String callId) { this.callId = callId; }
    public String getCallerId() { return callerId; }
    public void setCallerId(String callerId) { this.callerId = callerId; }
    public String getReceiverId() { return receiverId; }
    public void setReceiverId(String receiverId) { this.receiverId = receiverId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
