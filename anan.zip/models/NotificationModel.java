package com.example.app.models;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * Firebase Realtime Database notification record.
 *
 * Keep the public no-argument constructor and bean getters/setters so Firebase
 * can deserialize the model.
 */
public class NotificationModel {

    private String id;
    private String title;
    private String message;
    private String body;
    private String type;
    private String announcementId;
    private String callId;
    private String createdBy;
    private String emergencyId;
    private String incidentId;
    private long createdAt;
    private long timestamp;
    private boolean read;

    public NotificationModel() {
        // Required by Firebase.
    }

    @Nullable
    public String getId() {
        return id;
    }

    public void setId(@Nullable String id) {
        this.id = id;
    }

    @Nullable
    public String getTitle() {
        return title;
    }

    public void setTitle(@Nullable String title) {
        this.title = title;
    }

    @Nullable
    public String getMessage() {
        return message;
    }

    public void setMessage(@Nullable String message) {
        this.message = message;
    }

    @Nullable
    public String getBody() {
        return body;
    }

    public void setBody(@Nullable String body) {
        this.body = body;
    }

    @Nullable
    public String getType() {
        return type;
    }

    public void setType(@Nullable String type) {
        this.type = type;
    }

    @Nullable
    public String getAnnouncementId() {
        return announcementId;
    }

    public void setAnnouncementId(@Nullable String announcementId) {
        this.announcementId = announcementId;
    }

    @Nullable
    public String getCallId() {
        return callId;
    }

    public void setCallId(@Nullable String callId) {
        this.callId = callId;
    }

    @Nullable
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(@Nullable String createdBy) {
        this.createdBy = createdBy;
    }

    @Nullable
    public String getEmergencyId() {
        return emergencyId;
    }

    public void setEmergencyId(@Nullable String emergencyId) {
        this.emergencyId = emergencyId;
    }

    @Nullable
    public String getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(@Nullable String incidentId) {
        this.incidentId = incidentId;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public boolean isRead() {
        return read;
    }

    public boolean getRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public long getDisplayTimestamp() {
        return createdAt > 0L ? createdAt : timestamp;
    }

    @NonNull
    public String getDisplayTitle() {
        if (title != null && !title.trim().isEmpty()) {
            return title.trim();
        }
        return "HealthMate notification";
    }

    @NonNull
    public String getDisplayMessage() {
        if (message != null && !message.trim().isEmpty()) {
            return message.trim();
        }
        if (body != null && !body.trim().isEmpty()) {
            return body.trim();
        }
        return "Open HealthMate to view the notification details.";
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof NotificationModel)) {
            return false;
        }
        NotificationModel that = (NotificationModel) other;
        return createdAt == that.createdAt
                && timestamp == that.timestamp
                && read == that.read
                && Objects.equals(id, that.id)
                && Objects.equals(title, that.title)
                && Objects.equals(message, that.message)
                && Objects.equals(body, that.body)
                && Objects.equals(type, that.type)
                && Objects.equals(announcementId, that.announcementId)
                && Objects.equals(callId, that.callId)
                && Objects.equals(createdBy, that.createdBy)
                && Objects.equals(emergencyId, that.emergencyId)
                && Objects.equals(incidentId, that.incidentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                id,
                title,
                message,
                body,
                type,
                announcementId,
                callId,
                createdBy,
                emergencyId,
                incidentId,
                createdAt,
                timestamp,
                read
        );
    }
}
