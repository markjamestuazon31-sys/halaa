package com.example.app.models;

public class EmergencyDirectoryContact {
    private String id;
    private String shortName;
    private String organizationName;
    private String category;
    private String phone;
    private String alternatePhone;
    private String email;
    private String address;
    private boolean active;
    private int displayOrder = 100;
    public EmergencyDirectoryContact() { }
    public String getId() { return id; } public void setId(String value) { id = value; }
    public String getShortName() { return shortName; } public void setShortName(String value) { shortName = value; }
    public String getOrganizationName() { return organizationName; } public void setOrganizationName(String value) { organizationName = value; }
    public String getCategory() { return category; } public void setCategory(String value) { category = value; }
    public String getPhone() { return phone; } public void setPhone(String value) { phone = value; }
    public String getAlternatePhone() { return alternatePhone; } public void setAlternatePhone(String value) { alternatePhone = value; }
    public String getEmail() { return email; } public void setEmail(String value) { email = value; }
    public String getAddress() { return address; } public void setAddress(String value) { address = value; }
    public boolean isActive() { return active; } public void setActive(boolean value) { active = value; }
    public int getDisplayOrder() { return displayOrder; } public void setDisplayOrder(int value) { displayOrder = value; }
}
