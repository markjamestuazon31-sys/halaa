package com.example.app.models;

public class CallIceCandidate {
    private String sdpMid;
    private int sdpMLineIndex;
    private String sdp;
    private long createdAt;

    public CallIceCandidate() { }

    public CallIceCandidate(String sdpMid, int sdpMLineIndex, String sdp, long createdAt) {
        this.sdpMid = sdpMid;
        this.sdpMLineIndex = sdpMLineIndex;
        this.sdp = sdp;
        this.createdAt = createdAt;
    }

    public String getSdpMid() { return sdpMid; }
    public void setSdpMid(String sdpMid) { this.sdpMid = sdpMid; }
    public int getSdpMLineIndex() { return sdpMLineIndex; }
    public void setSdpMLineIndex(int sdpMLineIndex) { this.sdpMLineIndex = sdpMLineIndex; }
    public String getSdp() { return sdp; }
    public void setSdp(String sdp) { this.sdp = sdp; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
