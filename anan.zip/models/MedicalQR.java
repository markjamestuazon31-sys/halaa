package com.example.app.models;


public class MedicalQR {


    private String medicalToken;

    private boolean qrEnabled;

    private long createdAt;



    public MedicalQR(){}



    public MedicalQR(
            String medicalToken,
            boolean qrEnabled,
            long createdAt
    ){

        this.medicalToken = medicalToken;

        this.qrEnabled = qrEnabled;

        this.createdAt = createdAt;

    }



    public String getMedicalToken(){

        return medicalToken;

    }



    public boolean isQrEnabled(){

        return qrEnabled;

    }



    public long getCreatedAt(){

        return createdAt;

    }


}