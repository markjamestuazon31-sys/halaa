package com.example.app.models;

import androidx.annotation.Nullable;

/**
 * Read-only map representation of one authorized SOS incident.
 * Exact coordinates are loaded from the incident-scoped emergency location path.
 */
public class EmergencyMapOverlay {
    private String incidentId;
    private String patientUid;
    private String patientName;
    private String status;
    private String severity;
    private String priority;
    private long createdAt;
    private long updatedAt;
    private EmergencyLocationPoint patientLocation;

    public EmergencyMapOverlay() {
        // Required for simple construction and future Firebase compatibility.
    }

    public String getIncidentId() {
        return incidentId;
    }

    public void setIncidentId(String incidentId) {
        this.incidentId = incidentId;
    }

    public String getPatientUid() {
        return patientUid;
    }

    public void setPatientUid(String patientUid) {
        this.patientUid = patientUid;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Nullable
    public EmergencyLocationPoint getPatientLocation() {
        return patientLocation;
    }

    public void setPatientLocation(@Nullable EmergencyLocationPoint patientLocation) {
        this.patientLocation = patientLocation;
    }

    public long getDisplayTimestamp() {
        if (patientLocation != null && patientLocation.getUpdatedAt() > 0L) {
            return patientLocation.getUpdatedAt();
        }
        return updatedAt > 0L ? updatedAt : createdAt;
    }

    public boolean hasValidLocation() {
        if (patientLocation == null) {
            return false;
        }
        double latitude = patientLocation.getLatitude();
        double longitude = patientLocation.getLongitude();
        return Double.isFinite(latitude)
                && Double.isFinite(longitude)
                && latitude >= -90d
                && latitude <= 90d
                && longitude >= -180d
                && longitude <= 180d;
    }
}
