package com.example.app.models;

/** Canonical authenticated mobile profile stored at /users/{uid}. */
public class User {
    private String uid;
    private String fullName;
    private String email;
    private String phone;
    private String contactNumber;
    private String profileImage;
    private String qrCode;
    private String status;
    private String accountStatus;
    private String role;
    private String assignedBarangayId;
    private String respondentInvitationKey;
    private long createdAt;
    private long updatedAt;

    public User() { }

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public String getProfileImage() { return profileImage; }
    public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAccountStatus() { return accountStatus; }
    public void setAccountStatus(String accountStatus) { this.accountStatus = accountStatus; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getAssignedBarangayId() { return assignedBarangayId; }
    public void setAssignedBarangayId(String assignedBarangayId) { this.assignedBarangayId = assignedBarangayId; }
    public String getRespondentInvitationKey() { return respondentInvitationKey; }
    public void setRespondentInvitationKey(String respondentInvitationKey) { this.respondentInvitationKey = respondentInvitationKey; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
