package com.example.app.models;

public class Message {
    private String messageId;
    private String senderUid;
    private String receiverUid;
    private String senderId;
    private String receiverId;
    private String type;
    private String text;
    private String imageBase64;
    private long sentAt;
    private long timestamp;
    private long deliveredAt;
    private long seenAt;
    private String replyToMessageId;
    private String status;
    private boolean seen;

    public Message() { }
    public Message(String messageId, String senderId, String receiverId, String text, String imageBase64, long timestamp, boolean seen) {
        this.messageId=messageId; this.senderUid=senderId; this.receiverUid=receiverId; this.senderId=senderId; this.receiverId=receiverId;
        this.type="TEXT"; this.text=text; this.imageBase64=imageBase64; this.sentAt=timestamp; this.timestamp=timestamp; this.seen=seen;
        this.status=seen?"SEEN":"SENT"; this.seenAt=seen?timestamp:0L;
    }
    public static Message text(String senderUid, String receiverUid, String text, String replyTo, long now) {
        Message value=new Message(); value.senderUid=senderUid; value.receiverUid=receiverUid; value.senderId=senderUid; value.receiverId=receiverUid;
        value.type="TEXT"; value.text=text; value.sentAt=now; value.timestamp=now; value.replyToMessageId=replyTo; value.status="SENDING"; return value;
    }
    public String getMessageId(){return messageId;} public void setMessageId(String v){messageId=v;}
    public String getSenderUid(){return senderUid!=null?senderUid:senderId;} public void setSenderUid(String v){senderUid=v;senderId=v;}
    public String getReceiverUid(){return receiverUid!=null?receiverUid:receiverId;} public void setReceiverUid(String v){receiverUid=v;receiverId=v;}
    public String getSenderId(){return getSenderUid();} public void setSenderId(String v){setSenderUid(v);}
    public String getReceiverId(){return getReceiverUid();} public void setReceiverId(String v){setReceiverUid(v);}
    public String getType(){return type==null?"TEXT":type;} public void setType(String v){type=v;}
    public String getText(){return text;} public void setText(String v){text=v;}
    public String getImageBase64(){return imageBase64;} public void setImageBase64(String v){imageBase64=v;}
    public long getSentAt(){return sentAt>0?sentAt:timestamp;} public void setSentAt(long v){sentAt=v;timestamp=v;}
    public long getTimestamp(){return getSentAt();} public void setTimestamp(long v){setSentAt(v);}
    public long getDeliveredAt(){return deliveredAt;} public void setDeliveredAt(long v){deliveredAt=v;}
    public long getSeenAt(){return seenAt;} public void setSeenAt(long v){seenAt=v;seen=v>0;}
    public String getReplyToMessageId(){return replyToMessageId;} public void setReplyToMessageId(String v){replyToMessageId=v;}
    public String getStatus(){return status==null?(seen?"SEEN":"SENT"):status;} public void setStatus(String v){status=v;}
    public boolean isSeen(){return seen||seenAt>0||"SEEN".equalsIgnoreCase(status);} public void setSeen(boolean v){seen=v;}
}
