package com.example.app.models;

public class RescueReport {
    private String incidentId;
    private String responderUid;
    private String responderName;
    private String teamRole;
    private long arrivalAt;
    private long completedAt;
    private String observedCondition;
    private String actionsPerformed;
    private String agenciesContacted;
    private String transportDestination;
    private String notes;
    private String classificationRecommendation;
    private String coordinatorUid;
    private String classification;
    private String summary;
    private String reviewStatus;
    private long submittedAt;
    private long updatedAt;
    public RescueReport() { }
    public String getIncidentId() { return incidentId; } public void setIncidentId(String value) { incidentId = value; }
    public String getResponderUid() { return responderUid; } public void setResponderUid(String value) { responderUid = value; }
    public String getResponderName() { return responderName; } public void setResponderName(String value) { responderName = value; }
    public String getTeamRole() { return teamRole; } public void setTeamRole(String value) { teamRole = value; }
    public long getArrivalAt() { return arrivalAt; } public void setArrivalAt(long value) { arrivalAt = value; }
    public long getCompletedAt() { return completedAt; } public void setCompletedAt(long value) { completedAt = value; }
    public String getObservedCondition() { return observedCondition; } public void setObservedCondition(String value) { observedCondition = value; }
    public String getActionsPerformed() { return actionsPerformed; } public void setActionsPerformed(String value) { actionsPerformed = value; }
    public String getAgenciesContacted() { return agenciesContacted; } public void setAgenciesContacted(String value) { agenciesContacted = value; }
    public String getTransportDestination() { return transportDestination; } public void setTransportDestination(String value) { transportDestination = value; }
    public String getNotes() { return notes; } public void setNotes(String value) { notes = value; }
    public String getClassificationRecommendation() { return classificationRecommendation; } public void setClassificationRecommendation(String value) { classificationRecommendation = value; }
    public String getCoordinatorUid() { return coordinatorUid; } public void setCoordinatorUid(String value) { coordinatorUid = value; }
    public String getClassification() { return classification; } public void setClassification(String value) { classification = value; }
    public String getSummary() { return summary; } public void setSummary(String value) { summary = value; }
    public String getReviewStatus() { return reviewStatus; } public void setReviewStatus(String value) { reviewStatus = value; }
    public long getSubmittedAt() { return submittedAt; } public void setSubmittedAt(long value) { submittedAt = value; }
    public long getUpdatedAt() { return updatedAt; } public void setUpdatedAt(long value) { updatedAt = value; }
}
