package com.example.app.models;

public class RespondentInvitation {
    private String id;
    private String normalizedEmail;
    private String fullName;
    private String phone;
    private String position;
    private String assignedBarangayId;
    private String serviceArea;
    private String status;
    private String registeredUid;
    private String createdBy;
    private String updatedBy;
    private long createdAt;
    private long updatedAt;
    public RespondentInvitation() { }
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getNormalizedEmail() { return normalizedEmail; }
    public void setNormalizedEmail(String normalizedEmail) { this.normalizedEmail = normalizedEmail; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    public String getAssignedBarangayId() { return assignedBarangayId; }
    public void setAssignedBarangayId(String assignedBarangayId) { this.assignedBarangayId = assignedBarangayId; }
    public String getServiceArea() { return serviceArea; }
    public void setServiceArea(String serviceArea) { this.serviceArea = serviceArea; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRegisteredUid() { return registeredUid; }
    public void setRegisteredUid(String registeredUid) { this.registeredUid = registeredUid; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }
    public String getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
}
