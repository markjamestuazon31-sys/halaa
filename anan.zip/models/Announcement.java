package com.example.app.models;

import com.example.app.utils.AnnouncementEligibility;

public class Announcement {

    private String id;
    private String title;
    private String content;
    private String category;
    private String status;
    private String createdBy;
    private long createdAt;
    private long updatedAt;
    private long expiresAt;
    private String imageData;
    private String imageMimeType;

    public Announcement() {
        // Required by Firebase Realtime Database.
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
    public long getExpiresAt() { return expiresAt; }
    public void setExpiresAt(long expiresAt) { this.expiresAt = expiresAt; }
    public String getImageData() { return imageData; }
    public void setImageData(String imageData) { this.imageData = imageData; }
    public String getImageMimeType() { return imageMimeType; }
    public void setImageMimeType(String imageMimeType) { this.imageMimeType = imageMimeType; }

    public boolean isVisible(long nowMillis) {
        return AnnouncementEligibility.isVisible(status, createdAt, expiresAt, nowMillis);
    }
}
