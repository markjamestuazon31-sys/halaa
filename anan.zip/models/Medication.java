package com.example.app.models;

public class Medication {

    private String id;
    private String name;
    private String dosage;
    private String schedule;
    private String frequency;
    private boolean active;
    private int reminderHour = -1;
    private int reminderMinute = -1;
    private boolean reminderEnabled;
    private long createdAt;
    private long updatedAt;

    public Medication() {
        // Required by Firebase Realtime Database.
    }

    public Medication(
            String id,
            String name,
            String dosage,
            String schedule,
            String frequency,
            boolean active
    ) {
        this(id, name, dosage, schedule, frequency, active, -1, -1, false, 0L, 0L);
    }

    public Medication(
            String id,
            String name,
            String dosage,
            String schedule,
            String frequency,
            boolean active,
            int reminderHour,
            int reminderMinute,
            boolean reminderEnabled,
            long createdAt,
            long updatedAt
    ) {
        this.id = id;
        this.name = name;
        this.dosage = dosage;
        this.schedule = schedule;
        this.frequency = frequency;
        this.active = active;
        this.reminderHour = reminderHour;
        this.reminderMinute = reminderMinute;
        this.reminderEnabled = reminderEnabled;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public int getReminderHour() { return reminderHour; }
    public void setReminderHour(int reminderHour) { this.reminderHour = reminderHour; }
    public int getReminderMinute() { return reminderMinute; }
    public void setReminderMinute(int reminderMinute) { this.reminderMinute = reminderMinute; }
    public boolean isReminderEnabled() { return reminderEnabled; }
    public void setReminderEnabled(boolean reminderEnabled) { this.reminderEnabled = reminderEnabled; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }

    public boolean hasValidReminderTime() {
        return reminderHour >= 0 && reminderHour <= 23
                && reminderMinute >= 0 && reminderMinute <= 59;
    }
}
