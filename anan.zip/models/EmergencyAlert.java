package com.example.app.models;

public class EmergencyAlert {

    private String id;
    private String userId;
    private String clientRequestId;
    private String userName;
    private String phone;
    private String type;
    private String description;
    private String priority;
    private String status;
    private EmergencyLocation location;
    private double latitude;
    private double longitude;
    private int peopleInvolved;
    private long createdAt;
    private long updatedAt;

    public EmergencyAlert() {
        // Required by Firebase Realtime Database.
    }

    public static EmergencyAlert createSos(
            String clientRequestId,
            String userId,
            String userName,
            String phone,
            double latitude,
            double longitude
    ) {
        long now = System.currentTimeMillis();
        EmergencyAlert alert = new EmergencyAlert();
        alert.clientRequestId = clientRequestId;
        alert.userId = userId;
        alert.userName = userName;
        alert.phone = phone;
        alert.type = "SOS Alert";
        alert.description = "Emergency assistance requested from the HealthMate mobile app.";
        alert.priority = "High";
        alert.status = "Received";
        alert.location = new EmergencyLocation(latitude, longitude);
        alert.latitude = latitude;
        alert.longitude = longitude;
        alert.peopleInvolved = 1;
        alert.createdAt = now;
        alert.updatedAt = now;
        return alert;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getClientRequestId() { return clientRequestId; }
    public void setClientRequestId(String clientRequestId) { this.clientRequestId = clientRequestId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public EmergencyLocation getLocation() { return location; }
    public void setLocation(EmergencyLocation location) { this.location = location; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public int getPeopleInvolved() { return peopleInvolved; }
    public void setPeopleInvolved(int peopleInvolved) { this.peopleInvolved = peopleInvolved; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }

    public static class EmergencyLocation {
        private double latitude;
        private double longitude;

        public EmergencyLocation() {
            // Required by Firebase Realtime Database.
        }

        public EmergencyLocation(double latitude, double longitude) {
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public double getLatitude() { return latitude; }
        public void setLatitude(double latitude) { this.latitude = latitude; }
        public double getLongitude() { return longitude; }
        public void setLongitude(double longitude) { this.longitude = longitude; }
    }
}
