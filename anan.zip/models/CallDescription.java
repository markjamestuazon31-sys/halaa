package com.example.app.models;

public class CallDescription {
    private String type;
    private String sdp;
    private long createdAt;

    public CallDescription() { }

    public CallDescription(String type, String sdp, long createdAt) {
        this.type = type;
        this.sdp = sdp;
        this.createdAt = createdAt;
    }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getSdp() { return sdp; }
    public void setSdp(String sdp) { this.sdp = sdp; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
