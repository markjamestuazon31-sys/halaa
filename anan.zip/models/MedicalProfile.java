package com.example.app.models;

public class MedicalProfile {

    private String fullName;
    private String birthDate;
    private String bloodType;
    private String allergies;
    private String medicalConditions;
    private String medications;
    private String emergencyNote;
    private String doctorName;
    private String doctorPhone;

    public MedicalProfile() {
        // Required by Firebase Realtime Database.
    }

    public MedicalProfile(
            String fullName,
            String birthDate,
            String bloodType,
            String allergies,
            String medicalConditions,
            String medications,
            String emergencyNote,
            String doctorName,
            String doctorPhone
    ) {
        this.fullName = fullName;
        this.birthDate = birthDate;
        this.bloodType = bloodType;
        this.allergies = allergies;
        this.medicalConditions = medicalConditions;
        this.medications = medications;
        this.emergencyNote = emergencyNote;
        this.doctorName = doctorName;
        this.doctorPhone = doctorPhone;
    }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getBirthDate() { return birthDate; }
    public void setBirthDate(String birthDate) { this.birthDate = birthDate; }
    public String getBloodType() { return bloodType; }
    public void setBloodType(String bloodType) { this.bloodType = bloodType; }
    public String getAllergies() { return allergies; }
    public void setAllergies(String allergies) { this.allergies = allergies; }
    public String getMedicalConditions() { return medicalConditions; }
    public void setMedicalConditions(String medicalConditions) { this.medicalConditions = medicalConditions; }
    public String getMedications() { return medications; }
    public void setMedications(String medications) { this.medications = medications; }
    public String getEmergencyNote() { return emergencyNote; }
    public void setEmergencyNote(String emergencyNote) { this.emergencyNote = emergencyNote; }
    public String getDoctorName() { return doctorName; }
    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }
    public String getDoctorPhone() { return doctorPhone; }
    public void setDoctorPhone(String doctorPhone) { this.doctorPhone = doctorPhone; }
}
