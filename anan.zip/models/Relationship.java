package com.example.app.models;

public class Relationship {
    private String requestId;
    private String contactUid;
    private String relationshipType;
    private String status;
    private boolean canMessage;
    private boolean canCall;
    private boolean explicitLocationGrant;
    private long createdAt;
    private long updatedAt;
    public Relationship() { }
    public Relationship(String requestId, String contactUid, String relationshipType, String status, boolean canMessage, boolean canCall, boolean explicitLocationGrant, long createdAt, long updatedAt) {
        this.requestId=requestId; this.contactUid=contactUid; this.relationshipType=relationshipType; this.status=status; this.canMessage=canMessage; this.canCall=canCall; this.explicitLocationGrant=explicitLocationGrant; this.createdAt=createdAt; this.updatedAt=updatedAt;
    }
    public String getRequestId(){return requestId;} public void setRequestId(String v){requestId=v;}
    public String getContactUid(){return contactUid;} public void setContactUid(String v){contactUid=v;}
    public String getRelationshipType(){return relationshipType;} public void setRelationshipType(String v){relationshipType=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public boolean isCanMessage(){return canMessage;} public void setCanMessage(boolean v){canMessage=v;}
    public boolean isCanCall(){return canCall;} public void setCanCall(boolean v){canCall=v;}
    public boolean isExplicitLocationGrant(){return explicitLocationGrant;} public void setExplicitLocationGrant(boolean v){explicitLocationGrant=v;}
    public long getCreatedAt(){return createdAt;} public void setCreatedAt(long v){createdAt=v;}
    public long getUpdatedAt(){return updatedAt;} public void setUpdatedAt(long v){updatedAt=v;}
}
