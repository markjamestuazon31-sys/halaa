package com.example.app.models;

public class RelationshipRequest {
    private String requestId;
    private String requesterUid;
    private String targetUid;
    private String relationshipType;
    private String status;
    private long createdAt;
    private long updatedAt;
    public RelationshipRequest() { }
    public RelationshipRequest(String requestId, String requesterUid, String targetUid, String relationshipType, String status, long createdAt, long updatedAt) {
        this.requestId=requestId; this.requesterUid=requesterUid; this.targetUid=targetUid; this.relationshipType=relationshipType; this.status=status; this.createdAt=createdAt; this.updatedAt=updatedAt;
    }
    public String getRequestId(){return requestId;} public void setRequestId(String v){requestId=v;}
    public String getRequesterUid(){return requesterUid;} public void setRequesterUid(String v){requesterUid=v;}
    public String getTargetUid(){return targetUid;} public void setTargetUid(String v){targetUid=v;}
    public String getRelationshipType(){return relationshipType;} public void setRelationshipType(String v){relationshipType=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public long getCreatedAt(){return createdAt;} public void setCreatedAt(long v){createdAt=v;}
    public long getUpdatedAt(){return updatedAt;} public void setUpdatedAt(long v){updatedAt=v;}
}
