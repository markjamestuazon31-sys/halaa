package com.example.app.models;


public class HealthLog {


    private int waterIntake;

    private double weight;

    private int heartRate;

    private String note;

    private long timestamp;



    public HealthLog(){}



    public HealthLog(
            int waterIntake,
            double weight,
            int heartRate,
            String note,
            long timestamp
    ){

        this.waterIntake = waterIntake;

        this.weight = weight;

        this.heartRate = heartRate;

        this.note = note;

        this.timestamp = timestamp;

    }



    public int getWaterIntake(){

        return waterIntake;

    }



    public double getWeight(){

        return weight;

    }



    public int getHeartRate(){

        return heartRate;

    }



    public String getNote(){

        return note;

    }


}