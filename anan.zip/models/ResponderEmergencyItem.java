package com.example.app.models;

public final class ResponderEmergencyItem {

    private final EmergencyAlert emergency;
    private final boolean acceptedByCurrentResponder;

    public ResponderEmergencyItem(EmergencyAlert emergency, boolean acceptedByCurrentResponder) {
        this.emergency = emergency;
        this.acceptedByCurrentResponder = acceptedByCurrentResponder;
    }

    public EmergencyAlert getEmergency() {
        return emergency;
    }

    public boolean isAcceptedByCurrentResponder() {
        return acceptedByCurrentResponder;
    }
}
