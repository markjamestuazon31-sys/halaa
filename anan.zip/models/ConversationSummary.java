package com.example.app.models;

public class ConversationSummary {
    private String conversationId;
    private String otherParticipantUid;
    private String lastMessageText;
    private String lastMessageType;
    private String lastMessageSenderUid;
    private long lastMessageAt;
    private long unreadCount;
    private boolean muted;
    private boolean archived;
    private String displayName;
    private String profileImage;
    private String relationshipType;
    private String presenceState;
    private long lastSeenAt;
    public ConversationSummary() { }
    public String getConversationId(){return conversationId;} public void setConversationId(String v){conversationId=v;}
    public String getOtherParticipantUid(){return otherParticipantUid;} public void setOtherParticipantUid(String v){otherParticipantUid=v;}
    public String getLastMessageText(){return lastMessageText;} public void setLastMessageText(String v){lastMessageText=v;}
    public String getLastMessageType(){return lastMessageType;} public void setLastMessageType(String v){lastMessageType=v;}
    public String getLastMessageSenderUid(){return lastMessageSenderUid;} public void setLastMessageSenderUid(String v){lastMessageSenderUid=v;}
    public long getLastMessageAt(){return lastMessageAt;} public void setLastMessageAt(long v){lastMessageAt=v;}
    public long getUnreadCount(){return unreadCount;} public void setUnreadCount(long v){unreadCount=v;}
    public boolean isMuted(){return muted;} public void setMuted(boolean v){muted=v;}
    public boolean isArchived(){return archived;} public void setArchived(boolean v){archived=v;}
    public String getDisplayName(){return displayName;} public void setDisplayName(String v){displayName=v;}
    public String getProfileImage(){return profileImage;} public void setProfileImage(String v){profileImage=v;}
    public String getRelationshipType(){return relationshipType;} public void setRelationshipType(String v){relationshipType=v;}
    public String getPresenceState(){return presenceState;} public void setPresenceState(String v){presenceState=v;}
    public long getLastSeenAt(){return lastSeenAt;} public void setLastSeenAt(long v){lastSeenAt=v;}
}
