package com.example.app.firebase;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class FirebaseDatabaseManager {


    private static FirebaseDatabaseManager instance;


    private final DatabaseReference database;



    private FirebaseDatabaseManager(){


        database =
                FirebaseDatabase.getInstance()
                        .getReference();


    }



    public static synchronized FirebaseDatabaseManager getInstance(){


        if(instance==null){

            instance =
                    new FirebaseDatabaseManager();

        }


        return instance;

    }



    public DatabaseReference getDatabase(){

        return database;

    }


}