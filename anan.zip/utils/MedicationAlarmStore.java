package com.example.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.app.models.Medication;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MedicationAlarmStore {

    private static final String PREFS = "healthmate_medication_alarms";
    private static final String KEY_IDS = "medication_ids";
    private static final String PREFIX = "medication_";

    private MedicationAlarmStore() {
    }

    public static void save(Context context, String userId, Medication medication) {
        if (medication == null || isBlank(medication.getId())) return;

        try {
            JSONObject json = new JSONObject();
            json.put("userId", safe(userId));
            json.put("id", medication.getId());
            json.put("name", safe(medication.getName()));
            json.put("dosage", safe(medication.getDosage()));
            json.put("schedule", safe(medication.getSchedule()));
            json.put("frequency", safe(medication.getFrequency()));
            json.put("active", medication.isActive());
            json.put("reminderEnabled", medication.isReminderEnabled());
            json.put("hour", medication.getReminderHour());
            json.put("minute", medication.getReminderMinute());

            SharedPreferences preferences =
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            Set<String> ids = new HashSet<>(
                    preferences.getStringSet(KEY_IDS, new HashSet<>())
            );
            ids.add(medication.getId());
            preferences.edit()
                    .putString(PREFIX + medication.getId(), json.toString())
                    .putStringSet(KEY_IDS, ids)
                    .apply();
        } catch (Exception ignored) {
            // A malformed local cache must never prevent the Firebase save.
        }
    }

    public static void remove(Context context, String medicationId) {
        if (isBlank(medicationId)) return;
        SharedPreferences preferences =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = new HashSet<>(
                preferences.getStringSet(KEY_IDS, new HashSet<>())
        );
        ids.remove(medicationId);
        preferences.edit()
                .remove(PREFIX + medicationId)
                .putStringSet(KEY_IDS, ids)
                .apply();
    }

    public static List<ReminderRecord> loadAll(Context context) {
        SharedPreferences preferences =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = new HashSet<>(
                preferences.getStringSet(KEY_IDS, new HashSet<>())
        );
        List<ReminderRecord> records = new ArrayList<>();

        for (String id : ids) {
            String value = preferences.getString(PREFIX + id, null);
            if (value == null) continue;
            try {
                JSONObject json = new JSONObject(value);
                Medication medication = new Medication(
                        json.optString("id", id),
                        json.optString("name", "Medication"),
                        json.optString("dosage", ""),
                        json.optString("schedule", ""),
                        json.optString("frequency", "Daily"),
                        json.optBoolean("active", true),
                        json.optInt("hour", -1),
                        json.optInt("minute", -1),
                        json.optBoolean("reminderEnabled", true),
                        0L,
                        0L
                );
                records.add(
                        new ReminderRecord(json.optString("userId", ""), medication)
                );
            } catch (Exception ignored) {
                remove(context, id);
            }
        }
        return records;
    }

    public static final class ReminderRecord {
        private final String userId;
        private final Medication medication;

        ReminderRecord(String userId, Medication medication) {
            this.userId = userId;
            this.medication = medication;
        }

        public String getUserId() { return userId; }
        public Medication getMedication() { return medication; }
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
