package com.example.app.utils;

public final class ChatUtils {

    private ChatUtils() { }

    public static String generateChatId(String user1, String user2) {
        if (user1 == null || user2 == null || user1.trim().isEmpty() || user2.trim().isEmpty()) {
            throw new IllegalArgumentException("Both user IDs are required to create a chat.");
        }
        return user1.compareTo(user2) < 0 ? user1 + "_" + user2 : user2 + "_" + user1;
    }
}
