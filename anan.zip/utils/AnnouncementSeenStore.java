package com.example.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AnnouncementSeenStore {

    private static final String PREFS =
            "healthmate_announcements";
    private static final String CUTOFF_PREFIX = "cutoff_";
    private static final String SEEN_PREFIX = "seen_";
    private static final int MAX_SEEN_IDS = 300;

    private AnnouncementSeenStore() {
    }

    public static long getOrCreateCutoff(
            Context context,
            String userId
    ) {
        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREFS,
                        Context.MODE_PRIVATE
                );
        String key = CUTOFF_PREFIX + userId;
        long existing =
                preferences.getLong(key, 0L);
        if (existing > 0L) return existing;

        long now = System.currentTimeMillis();
        preferences.edit().putLong(key, now).apply();
        return now;
    }

    public static boolean isSeen(
            Context context,
            String userId,
            String announcementId
    ) {
        return getSeen(context, userId)
                .contains(announcementId);
    }

    public static void markSeen(
            Context context,
            String userId,
            String announcementId
    ) {
        if (announcementId == null
                || announcementId.trim().isEmpty()) {
            return;
        }
        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREFS,
                        Context.MODE_PRIVATE
                );
        Set<String> seen =
                getSeen(context, userId);
        seen.add(announcementId);

        if (seen.size() > MAX_SEEN_IDS) {
            List<String> values =
                    new ArrayList<>(seen);
            seen.clear();
            for (
                    int index =
                    Math.max(
                            0,
                            values.size()
                                    - MAX_SEEN_IDS
                    );
                    index < values.size();
                    index++
            ) {
                seen.add(values.get(index));
            }
        }
        preferences.edit()
                .putStringSet(
                        SEEN_PREFIX + userId,
                        seen
                )
                .apply();
    }

    private static Set<String> getSeen(
            Context context,
            String userId
    ) {
        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREFS,
                        Context.MODE_PRIVATE
                );
        return new HashSet<>(
                preferences.getStringSet(
                        SEEN_PREFIX + userId,
                        new HashSet<>()
                )
        );
    }
}
