package com.example.app.utils;


import android.content.Context;
import android.content.SharedPreferences;



public class SessionManager {


    private static final String PREF =
            "HealthMateSession";


    private static final String LOGIN =
            "LOGIN_STATUS";



    private SharedPreferences preferences;



    public SessionManager(Context context){


        preferences =
                context.getSharedPreferences(
                        PREF,
                        Context.MODE_PRIVATE
                );


    }



    public void createSession(){


        preferences.edit()
                .putBoolean(
                        LOGIN,
                        true
                )
                .apply();


    }



    public boolean isLoggedIn(){


        return preferences
                .getBoolean(
                        LOGIN,
                        false
                );


    }



    public void logout(){


        preferences.edit()
                .clear()
                .apply();


    }


}