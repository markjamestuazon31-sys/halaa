package com.example.app.utils;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.example.app.models.Medication;
import com.example.app.receivers.MedicationAlarmReceiver;

import java.util.List;

public final class MedicationAlarmScheduler {

    public static final String EXTRA_USER_ID = "userId";
    public static final String EXTRA_MEDICATION_ID = "medicationId";
    public static final String EXTRA_MEDICINE_NAME = "medicineName";
    public static final String EXTRA_DOSAGE = "dosage";
    public static final String EXTRA_HOUR = "reminderHour";
    public static final String EXTRA_MINUTE = "reminderMinute";
    public static final String EXTRA_SNOOZE = "isSnooze";

    private static final String ACTION_DAILY =
            "com.example.healthmate.MEDICATION_DAILY";
    private static final String ACTION_SNOOZE =
            "com.example.healthmate.MEDICATION_SNOOZE";

    private MedicationAlarmScheduler() {
    }

    public enum ScheduleMode {
        EXACT,
        INEXACT,
        NOT_SCHEDULED
    }

    public static ScheduleMode scheduleDaily(
            Context context,
            String userId,
            Medication medication
    ) {
        if (medication == null || !medication.isActive()
                || !medication.isReminderEnabled()
                || !medication.hasValidReminderTime()
                || isBlank(medication.getId())
                || isBlank(userId)) {
            if (medication != null) {
                cancelAllForMedication(context, medication.getId());
            }
            return ScheduleMode.NOT_SCHEDULED;
        }

        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return ScheduleMode.NOT_SCHEDULED;

        long triggerAt = MedicationTimeCalculator.nextDailyTriggerMillis(
                medication.getReminderHour(),
                medication.getReminderMinute(),
                System.currentTimeMillis()
        );
        PendingIntent pendingIntent = createPendingIntent(
                context,
                userId,
                medication,
                false,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        boolean exactAllowed = canScheduleExactAlarms(alarmManager);
        if (exactAllowed) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                );
            } else {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                );
            }
            MedicationAlarmStore.save(context, userId, medication);
            return ScheduleMode.EXACT;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt,
                    pendingIntent
            );
        } else {
            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt,
                    pendingIntent
            );
        }
        MedicationAlarmStore.save(context, userId, medication);
        return ScheduleMode.INEXACT;
    }

    public static void scheduleSnooze(
            Context context,
            String userId,
            Medication medication,
            long delayMillis
    ) {
        if (medication == null
                || isBlank(medication.getId())
                || isBlank(userId)) {
            return;
        }
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        long triggerAt =
                System.currentTimeMillis() + Math.max(60_000L, delayMillis);
        PendingIntent pendingIntent = createPendingIntent(
                context,
                userId,
                medication,
                true,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (canScheduleExactAlarms(alarmManager)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                );
            } else {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                );
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt,
                    pendingIntent
            );
        } else {
            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt,
                    pendingIntent
            );
        }
    }

    public static void cancelDaily(Context context, String medicationId) {
        cancelPendingIntent(context, medicationId, false);
        MedicationAlarmStore.remove(context, medicationId);
    }

    public static void cancelSnooze(Context context, String medicationId) {
        cancelPendingIntent(context, medicationId, true);
    }

    public static void cancelAllForMedication(
            Context context,
            String medicationId
    ) {
        cancelPendingIntent(context, medicationId, false);
        cancelPendingIntent(context, medicationId, true);
        MedicationAlarmStore.remove(context, medicationId);
    }

    public static void cancelAllStoredReminders(Context context) {
        List<MedicationAlarmStore.ReminderRecord> records =
                MedicationAlarmStore.loadAll(context);
        for (MedicationAlarmStore.ReminderRecord record : records) {
            cancelAllForMedication(
                    context,
                    record.getMedication().getId()
            );
        }
    }

    public static void rescheduleStoredReminders(
            Context context,
            String currentUserId
    ) {
        if (isBlank(currentUserId)) return;
        List<MedicationAlarmStore.ReminderRecord> records =
                MedicationAlarmStore.loadAll(context);
        for (MedicationAlarmStore.ReminderRecord record : records) {
            if (!currentUserId.equals(record.getUserId())) continue;
            scheduleDaily(
                    context,
                    record.getUserId(),
                    record.getMedication()
            );
        }
    }

    public static boolean canScheduleExactAlarms(Context context) {
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return alarmManager != null && canScheduleExactAlarms(alarmManager);
    }

    public static void openExactAlarmSettings(Activity activity) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        Intent intent = new Intent(
                Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:" + activity.getPackageName())
        );
        activity.startActivity(intent);
    }

    private static boolean canScheduleExactAlarms(
            AlarmManager alarmManager
    ) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || alarmManager.canScheduleExactAlarms();
    }

    private static void cancelPendingIntent(
            Context context,
            String medicationId,
            boolean snooze
    ) {
        if (isBlank(medicationId)) return;
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        String action = snooze ? ACTION_SNOOZE : ACTION_DAILY;
        String suffix = snooze ? "snooze" : "daily";
        Intent intent = new Intent(context, MedicationAlarmReceiver.class)
                .setAction(action)
                .setData(
                        Uri.parse(
                                "healthmate://medication/"
                                        + Uri.encode(medicationId)
                                        + "/"
                                        + suffix
                        )
                );
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode(medicationId, snooze),
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }

    private static PendingIntent createPendingIntent(
            Context context,
            String userId,
            Medication medication,
            boolean snooze,
            int flags
    ) {
        String action = snooze ? ACTION_SNOOZE : ACTION_DAILY;
        String suffix = snooze ? "snooze" : "daily";
        Intent intent = new Intent(context, MedicationAlarmReceiver.class)
                .setAction(action)
                .setData(
                        Uri.parse(
                                "healthmate://medication/"
                                        + Uri.encode(medication.getId())
                                        + "/"
                                        + suffix
                        )
                )
                .putExtra(EXTRA_USER_ID, userId)
                .putExtra(EXTRA_MEDICATION_ID, medication.getId())
                .putExtra(EXTRA_MEDICINE_NAME, medication.getName())
                .putExtra(EXTRA_DOSAGE, medication.getDosage())
                .putExtra(EXTRA_HOUR, medication.getReminderHour())
                .putExtra(EXTRA_MINUTE, medication.getReminderMinute())
                .putExtra(EXTRA_SNOOZE, snooze);

        return PendingIntent.getBroadcast(
                context,
                requestCode(medication.getId(), snooze),
                intent,
                flags
        );
    }

    private static int requestCode(String medicationId, boolean snooze) {
        int base = medicationId == null ? 1 : medicationId.hashCode();
        return (base * 31) + (snooze ? 7 : 3);
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
