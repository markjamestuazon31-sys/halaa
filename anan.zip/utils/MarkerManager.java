package com.example.app.utils;


import org.maplibre.android.geometry.LatLng;


import org.maplibre.android.maps.MapLibreMap;

import org.maplibre.android.annotations.MarkerOptions;



public class MarkerManager {



    public static void addMarker(

            MapLibreMap map,

            double latitude,

            double longitude,

            String title

    ){



        map.addMarker(

                new MarkerOptions()

                        .position(

                                new LatLng(
                                        latitude,
                                        longitude
                                )

                        )

                        .title(title)

        );



    }



}