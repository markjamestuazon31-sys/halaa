package com.example.app.utils;


import android.util.Patterns;


public class ValidationUtils {


    public static boolean emailValid(String email){


        return Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches();

    }



    public static boolean passwordValid(String password){


        return password.length() >= 8
                &&
                password.matches(".*[A-Z].*")
                &&
                password.matches(".*[0-9].*");


    }



    public static boolean phoneValid(String phone){


        return phone.length() >= 10;


    }



}