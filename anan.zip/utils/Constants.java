package com.example.app.utils;


public final class Constants {


    private Constants(){}


    public static final String USERS_NODE =
            "users";


    public static final String MESSAGES_NODE =
            "messages";


    public static final String FRIENDS_NODE =
            "friends";


    public static final String EMERGENCY_NODE =
            "emergency";


    public static final String CALL_NODE =
            "calls";


    public static final int IMAGE_MAX_SIZE =
            1024 * 1024;


}