package com.example.app.utils;

import android.content.Context;

import com.example.app.R;

public final class MapStyleProvider {

    private MapStyleProvider() { }

    public static String getStyleUrl(Context context) {
        String explicitStyle = context.getString(R.string.map_style_url).trim();
        if (!explicitStyle.isEmpty()) return explicitStyle;
        String key = context.getString(R.string.maptiler_key).trim();
        if (key.isEmpty()) return "";
        return "https://api.maptiler.com/maps/streets-v2/style.json?key=" + key;
    }
}
