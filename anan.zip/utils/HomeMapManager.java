package com.example.app.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.example.app.map.MapConfiguration;
import com.example.app.map.MapMarkerRenderer;
import com.example.app.models.ContactLocation;
import com.example.app.models.ContactPublicProfile;
import com.example.app.repositories.LiveContactLocationRepository;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Coordinates the non-interactive home map preview.
 *
 * The preview always loads a real map style, listens to accepted family live
 * locations, adds the signed-in user's last local position when permission is
 * available, draws profile-photo pins, and keeps all visible markers inside
 * the preview camera bounds.
 */
public final class HomeMapManager {
    private final Context context;
    private final MapView mapView;
    private final String viewerUid;
    private final LiveContactLocationRepository repository =
            new LiveContactLocationRepository();
    private final FusedLocationProviderClient locationClient;
    private final MapMarkerRenderer renderer;

    private final List<ContactLocation> repositoryLocations =
            new ArrayList<>();
    private final List<ContactLocation> latestLocations =
            new ArrayList<>();

    private MapLibreMap map;
    private Listener listener;
    private ContactLocation localSelfLocation;
    private ContactPublicProfile selfProfile;
    private int pairedFamilyCount;
    private boolean styleReady;
    private boolean fallbackAttempted;
    private String lastCameraSignature = "";

    private final MapView.OnDidFailLoadingMapListener mapFailureListener =
            errorMessage -> {
                if (!fallbackAttempted && map != null) {
                    fallbackAttempted = true;
                    if (listener != null) {
                        listener.onLoadingFallback();
                    }
                    loadStyle(MapConfiguration.offlineStyleUrl());
                    return;
                }

                if (listener != null) {
                    listener.onError(message(
                            errorMessage,
                            "Unable to load the map. Check the internet connection."
                    ));
                }
            };

    public HomeMapManager(
            Context context,
            MapView mapView,
            String viewerUid
    ) {
        this.context = context.getApplicationContext();
        this.mapView = mapView;
        this.viewerUid = safe(viewerUid);
        this.locationClient = LocationServices
                .getFusedLocationProviderClient(this.context);
        this.renderer = new MapMarkerRenderer(this.context);
    }

    public void start(Listener listener) {
        this.listener = listener;

        if (viewerUid.isEmpty()) {
            listener.onError("Please sign in again.");
            return;
        }

        MapLibre.getInstance(context);
        mapView.addOnDidFailLoadingMapListener(mapFailureListener);

        mapView.getMapAsync(mapLibreMap -> {
            map = mapLibreMap;
            map.getUiSettings().setAllGesturesEnabled(false);
            map.getUiSettings().setCompassEnabled(false);
            loadStyle(MapConfiguration.styleUrl());
        });

        repository.listenFamily(
                viewerUid,
                new LiveContactLocationRepository.Listener() {
                    @Override
                    public void onChanged(
                            List<ContactLocation> locations
                    ) {
                        repositoryLocations.clear();
                        if (locations != null) {
                            repositoryLocations.addAll(locations);
                        }
                        rebuildAndRender();
                    }

                    @Override
                    public void onRelationshipCount(int count) {
                        pairedFamilyCount = Math.max(0, count);
                        notifyState();
                    }

                    @Override
                    public void onError(String message) {
                        if (HomeMapManager.this.listener != null) {
                            HomeMapManager.this.listener.onError(message(
                                    message,
                                    "Unable to load family locations."
                            ));
                        }
                    }
                }
        );

        loadSelfProfile();
        loadLastLocalLocation();
    }

    private void loadStyle(String styleUrl) {
        if (map == null) {
            return;
        }

        styleReady = false;
        map.setStyle(styleUrl, style -> {
            styleReady = true;
            renderer.attach(style);
            renderer.render(latestLocations);
            fitAllVisibleLocations(false, true);
            notifyState();
        });
    }

    private void loadSelfProfile() {
        FirebaseDatabase.getInstance()
                .getReference("publicProfiles")
                .child(viewerUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(
                            @NonNull DataSnapshot snapshot
                    ) {
                        selfProfile = snapshot.getValue(
                                ContactPublicProfile.class
                        );
                        applySelfProfile();
                        rebuildAndRender();
                    }

                    @Override
                    public void onCancelled(
                            @NonNull DatabaseError error
                    ) {
                        // The self marker can still render with initials.
                    }
                });
    }

    private void loadLastLocalLocation() {
        if (!hasLocationPermission()) {
            return;
        }

        locationClient.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (location == null) {
                        return;
                    }
                    localSelfLocation = fromLocalLocation(location);
                    applySelfProfile();
                    rebuildAndRender();
                });
    }

    private ContactLocation fromLocalLocation(Location location) {
        ContactLocation result = new ContactLocation();
        result.setUid(viewerUid);
        result.setDisplayName("You");
        result.setRelationshipType("SELF");
        result.setLatitude(location.getLatitude());
        result.setLongitude(location.getLongitude());
        result.setAccuracy(location.getAccuracy());
        result.setBearing(location.getBearing());
        result.setSpeed(location.getSpeed());
        result.setUpdatedAt(
                location.getTime() > 0L
                        ? location.getTime()
                        : System.currentTimeMillis()
        );
        result.setSource("LOCAL");
        return result;
    }

    private void applySelfProfile() {
        if (localSelfLocation == null || selfProfile == null) {
            return;
        }

        localSelfLocation.setDisplayName(nonBlank(
                selfProfile.getFullName(),
                "You"
        ));
        localSelfLocation.setProfileImage(
                safe(selfProfile.getProfileImage())
        );
    }

    private void rebuildAndRender() {
        Map<String, ContactLocation> deduplicated =
                new LinkedHashMap<>();

        for (ContactLocation location : repositoryLocations) {
            if (location == null || safe(location.getUid()).isEmpty()) {
                continue;
            }
            deduplicated.put(location.getUid(), location);
        }

        if (localSelfLocation != null) {
            ContactLocation storedSelf = deduplicated.get(viewerUid);
            if (storedSelf == null
                    || localSelfLocation.getUpdatedAt()
                    >= storedSelf.getUpdatedAt()) {
                deduplicated.put(viewerUid, localSelfLocation);
            }
        }

        latestLocations.clear();
        latestLocations.addAll(deduplicated.values());
        sortLocations(latestLocations);

        if (styleReady) {
            renderer.render(latestLocations);
            fitAllVisibleLocations(false, false);
        }

        notifyState();
    }

    private void sortLocations(List<ContactLocation> locations) {
        Collections.sort(locations, new Comparator<ContactLocation>() {
            @Override
            public int compare(
                    ContactLocation left,
                    ContactLocation right
            ) {
                if (left.isSelf() && !right.isSelf()) {
                    return -1;
                }
                if (!left.isSelf() && right.isSelf()) {
                    return 1;
                }
                return safe(left.getDisplayName()).compareToIgnoreCase(
                        safe(right.getDisplayName())
                );
            }
        });
    }

    private void fitAllVisibleLocations(
            boolean animated,
            boolean force
    ) {
        if (map == null || latestLocations.isEmpty()) {
            if (map != null && force) {
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                        new LatLng(12.0d, 122.0d),
                        4.2d
                ));
            }
            return;
        }

        List<LatLng> points = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        LatLngBounds.Builder bounds = new LatLngBounds.Builder();

        for (ContactLocation location : latestLocations) {
            if (!valid(location)) {
                continue;
            }

            LatLng point = new LatLng(
                    location.getLatitude(),
                    location.getLongitude()
            );
            points.add(point);
            ids.add(safe(location.getUid()));
            bounds.include(point);
        }

        if (points.isEmpty()) {
            return;
        }

        Collections.sort(ids);
        String signature = ids.toString();
        if (!force && signature.equals(lastCameraSignature)) {
            return;
        }
        lastCameraSignature = signature;

        if (points.size() == 1) {
            if (animated) {
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(
                        points.get(0),
                        14.8d
                ));
            } else {
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                        points.get(0),
                        14.8d
                ));
            }
            return;
        }

        try {
            if (animated) {
                map.animateCamera(
                        CameraUpdateFactory.newLatLngBounds(
                                bounds.build(),
                                58
                        )
                );
            } else {
                map.moveCamera(
                        CameraUpdateFactory.newLatLngBounds(
                                bounds.build(),
                                58
                        )
                );
            }
        } catch (RuntimeException ignored) {
            // The preview will retry when the MapView has a measured size.
        }
    }

    private void notifyState() {
        if (listener == null) {
            return;
        }

        int visibleFamilyCount = 0;
        boolean selfVisible = false;

        for (ContactLocation location : latestLocations) {
            if (location == null) {
                continue;
            }
            if (location.isSelf()) {
                selfVisible = true;
            } else if ("FAMILY".equalsIgnoreCase(
                    location.getRelationshipType()
            )) {
                visibleFamilyCount++;
            }
        }

        listener.onStateChanged(
                styleReady,
                pairedFamilyCount,
                visibleFamilyCount,
                selfVisible
        );
    }

    public void stop() {
        repository.stop();
        mapView.removeOnDidFailLoadingMapListener(
                mapFailureListener
        );
        listener = null;
        map = null;
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean valid(ContactLocation location) {
        return location != null
                && Double.isFinite(location.getLatitude())
                && Double.isFinite(location.getLongitude())
                && location.getLatitude() >= -90d
                && location.getLatitude() <= 90d
                && location.getLongitude() >= -180d
                && location.getLongitude() <= 180d;
    }

    private String nonBlank(String value, String fallback) {
        return safe(value).isEmpty() ? fallback : value.trim();
    }

    private String message(String value, String fallback) {
        return safe(value).isEmpty() ? fallback : value.trim();
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    public interface Listener {
        void onStateChanged(
                boolean mapReady,
                int pairedFamilyCount,
                int visibleFamilyCount,
                boolean selfVisible
        );

        void onLoadingFallback();

        void onError(String message);
    }
}
