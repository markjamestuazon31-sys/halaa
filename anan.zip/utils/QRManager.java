package com.example.app.utils;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public final class QRManager {

    private static final int QR_SIZE = 500;

    private QRManager() {
    }

    public static Bitmap generateQR(String data) {
        if (data == null || data.trim().isEmpty()) {
            return null;
        }

        try {
            BitMatrix matrix = new QRCodeWriter().encode(
                    data,
                    BarcodeFormat.QR_CODE,
                    QR_SIZE,
                    QR_SIZE
            );
            Bitmap bitmap = Bitmap.createBitmap(QR_SIZE, QR_SIZE, Bitmap.Config.RGB_565);
            for (int x = 0; x < QR_SIZE; x++) {
                for (int y = 0; y < QR_SIZE; y++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bitmap;
        } catch (WriterException exception) {
            return null;
        }
    }
}
