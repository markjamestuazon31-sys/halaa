package com.example.app.utils;


import android.graphics.Bitmap;


import java.io.ByteArrayOutputStream;


import android.util.Base64;



public class ImageEncoder {



    public static String encode(Bitmap bitmap){


        ByteArrayOutputStream stream =
                new ByteArrayOutputStream();



        bitmap.compress(
                Bitmap.CompressFormat.JPEG,
                50,
                stream
        );



        return Base64.encodeToString(
                stream.toByteArray(),
                Base64.DEFAULT
        );


    }



}