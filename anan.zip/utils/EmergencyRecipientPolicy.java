package com.example.app.utils;

import java.util.Locale;

public final class EmergencyRecipientPolicy {

    private EmergencyRecipientPolicy() { }

    public static boolean isAdministratorRole(String role) {
        String normalized = normalize(role);
        return "administrator".equals(normalized)
                || "admin".equals(normalized)
                || "staff".equals(normalized);
    }

    public static boolean isAcceptedStatus(String status) {
        return "accepted".equals(normalize(status));
    }

    public static boolean isAcceptedEmergencyContact(boolean accepted, String status) {
        return accepted || isAcceptedStatus(status);
    }

    public static boolean isNotifiableResponder(String status) {
        return isNotifiableResponder(status, "active");
    }

    public static boolean isNotifiableResponder(String status, String accountStatus) {
        String normalizedAccount = normalize(accountStatus);
        boolean accountEnabled = normalizedAccount.isEmpty()
                || "active".equals(normalizedAccount)
                || "enabled".equals(normalizedAccount)
                || "approved".equals(normalizedAccount);
        String normalizedStatus = normalize(status);
        return accountEnabled
                && !normalizedStatus.isEmpty()
                && !"offline".equals(normalizedStatus)
                && !"unavailable".equals(normalizedStatus)
                && !"disabled".equals(normalizedStatus)
                && !"inactive".equals(normalizedStatus)
                && !"suspended".equals(normalizedStatus);
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }
}
