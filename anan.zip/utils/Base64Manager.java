package com.example.app.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;

public final class Base64Manager {

    private static final int JPEG_QUALITY = 80;

    private Base64Manager() {
        // Prevent object creation.
    }

    /**
     * Converts a Bitmap into a Base64 string.
     *
     * @param bitmap source bitmap
     * @return Base64 image string, or an empty string when conversion fails
     */
    @NonNull
    public static String bitmapToBase64(
            @Nullable Bitmap bitmap
    ) {
        if (bitmap == null || bitmap.isRecycled()) {
            return "";
        }

        ByteArrayOutputStream outputStream =
                new ByteArrayOutputStream();

        try {
            boolean compressed = bitmap.compress(
                    Bitmap.CompressFormat.JPEG,
                    JPEG_QUALITY,
                    outputStream
            );

            if (!compressed) {
                return "";
            }

            byte[] imageBytes =
                    outputStream.toByteArray();

            if (imageBytes.length == 0) {
                return "";
            }

            return Base64.encodeToString(
                    imageBytes,
                    Base64.NO_WRAP
            );

        } catch (Exception error) {
            return "";

        } finally {
            try {
                outputStream.close();
            } catch (Exception ignored) {
                // ByteArrayOutputStream does not require recovery.
            }
        }
    }

    /**
     * Converts a Base64 image string into a Bitmap.
     *
     * Safely handles null, empty, invalid, and data-URI values.
     *
     * @param base64String Base64 image value
     * @return decoded bitmap, or null when the value is unavailable or invalid
     */
    @Nullable
    public static Bitmap base64ToBitmap(
            @Nullable String base64String
    ) {
        if (base64String == null) {
            return null;
        }

        String normalized =
                base64String.trim();

        if (normalized.isEmpty()
                || "null".equalsIgnoreCase(normalized)) {
            return null;
        }

        /*
         * Supports values such as:
         *
         * data:image/jpeg;base64,/9j/4AAQSk...
         * data:image/png;base64,iVBORw0KGgo...
         */
        int commaIndex =
                normalized.indexOf(',');

        if (normalized.startsWith("data:image/")
                && commaIndex >= 0
                && commaIndex < normalized.length() - 1) {

            normalized =
                    normalized.substring(
                            commaIndex + 1
                    );
        }

        try {
            byte[] decodedBytes =
                    Base64.decode(
                            normalized,
                            Base64.DEFAULT
                    );

            if (decodedBytes.length == 0) {
                return null;
            }

            return BitmapFactory.decodeByteArray(
                    decodedBytes,
                    0,
                    decodedBytes.length
            );

        } catch (IllegalArgumentException error) {
            // The database value is not valid Base64.
            return null;

        } catch (OutOfMemoryError error) {
            // Prevent application termination for an excessively large image.
            return null;
        }
    }
}