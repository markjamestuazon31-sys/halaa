package com.example.app.utils;


import java.util.UUID;



public class MedicalTokenGenerator {


    public static String generate(){


        return

                "HM-"

                        +

                        UUID
                                .randomUUID()
                                .toString()
                                .substring(0,8)
                                .toUpperCase();



    }



}