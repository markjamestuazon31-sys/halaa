package com.example.app.utils;


import android.Manifest;
import android.app.Activity;


import androidx.core.app.ActivityCompat;



public class PermissionManager {


    public static void requestPermissions(
            Activity activity
    ){


        ActivityCompat.requestPermissions(

                activity,

                new String[]{


                        Manifest.permission.ACCESS_FINE_LOCATION,

                        Manifest.permission.ACCESS_COARSE_LOCATION,

                        Manifest.permission.CAMERA,

                        Manifest.permission.RECORD_AUDIO,

                        Manifest.permission.POST_NOTIFICATIONS


                },

                100

        );



    }


}