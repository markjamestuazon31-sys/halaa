package com.example.app.utils;

import java.util.Calendar;
import java.util.TimeZone;

public final class MedicationTimeCalculator {

    private MedicationTimeCalculator() {
    }

    public static long nextDailyTriggerMillis(int hour, int minute, long nowMillis) {
        return nextDailyTriggerMillis(hour, minute, nowMillis, TimeZone.getDefault());
    }

    public static long nextDailyTriggerMillis(int hour, int minute, long nowMillis, TimeZone timeZone) {
        if (hour < 0 || hour > 23) {
            throw new IllegalArgumentException("Hour must be between 0 and 23.");
        }
        if (minute < 0 || minute > 59) {
            throw new IllegalArgumentException("Minute must be between 0 and 59.");
        }

        Calendar trigger = Calendar.getInstance(timeZone);
        trigger.setTimeInMillis(nowMillis);
        trigger.set(Calendar.HOUR_OF_DAY, hour);
        trigger.set(Calendar.MINUTE, minute);
        trigger.set(Calendar.SECOND, 0);
        trigger.set(Calendar.MILLISECOND, 0);

        if (trigger.getTimeInMillis() <= nowMillis) {
            trigger.add(Calendar.DAY_OF_YEAR, 1);
        }
        return trigger.getTimeInMillis();
    }
}
