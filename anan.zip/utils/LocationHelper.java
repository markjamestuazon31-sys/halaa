package com.example.app.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

public class LocationHelper {

    private final Context context;
    private final FusedLocationProviderClient client;

    public LocationHelper(Context context) {
        this.context = context.getApplicationContext();
        client = LocationServices.getFusedLocationProviderClient(context);
    }

    public void getCurrentLocation(LocationResultCallback callback) {
        boolean fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        boolean coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;

        if (!fineGranted && !coarseGranted) {
            callback.onError("Location permission is required to send an SOS alert.");
            return;
        }

        try {
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, tokenSource.getToken())
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            callback.onLocation(location);
                        } else {
                            client.getLastLocation()
                                    .addOnSuccessListener(lastLocation -> {
                                        if (lastLocation != null) callback.onLocation(lastLocation);
                                        else callback.onError("Current location is unavailable. Turn on location services and try again.");
                                    })
                                    .addOnFailureListener(error -> callback.onError(safeMessage(error)));
                        }
                    })
                    .addOnFailureListener(error -> callback.onError(safeMessage(error)));
        } catch (SecurityException exception) {
            callback.onError("Location permission is not available.");
        }
    }

    private String safeMessage(Exception exception) {
        return exception.getMessage() == null ? "Unable to retrieve the current location." : exception.getMessage();
    }

    public interface LocationResultCallback {
        void onLocation(Location location);
        void onError(String message);
    }
}
