package com.example.app.utils;

public final class AnnouncementEligibility {

    private AnnouncementEligibility() {
    }

    public static boolean isVisible(String status, long createdAt, long expiresAt, long nowMillis) {
        String normalizedStatus = status == null || status.trim().isEmpty()
                ? "published"
                : status.trim().toLowerCase();
        if (!"published".equals(normalizedStatus)) {
            return false;
        }
        if (createdAt > nowMillis) {
            return false;
        }
        return expiresAt <= 0 || expiresAt > nowMillis;
    }
}
