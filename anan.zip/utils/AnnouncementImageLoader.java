package com.example.app.utils;

import android.util.Base64;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;

public final class AnnouncementImageLoader {

    private AnnouncementImageLoader() { }

    public static boolean load(ImageView imageView, @Nullable String encodedImage) {
        Glide.with(imageView).clear(imageView);
        imageView.setImageDrawable(null);

        byte[] imageBytes = decode(encodedImage);
        if (imageBytes == null || imageBytes.length == 0) {
            imageView.setVisibility(View.GONE);
            return false;
        }

        imageView.setVisibility(View.VISIBLE);
        Glide.with(imageView)
                .load(imageBytes)
                .centerCrop()
                .into(imageView);
        return true;
    }

    @Nullable
    static byte[] decode(@Nullable String encodedImage) {
        if (encodedImage == null || encodedImage.trim().isEmpty()) return null;
        String normalized = encodedImage.trim();
        int commaIndex = normalized.indexOf(',');
        if (normalized.startsWith("data:") && commaIndex >= 0) {
            normalized = normalized.substring(commaIndex + 1);
        }
        try {
            return Base64.decode(normalized, Base64.DEFAULT);
        } catch (IllegalArgumentException invalidBase64) {
            return null;
        }
    }
}
