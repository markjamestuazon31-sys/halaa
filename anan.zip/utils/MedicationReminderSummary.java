package com.example.app.utils;

import com.example.app.models.Medication;

import java.util.List;
import java.util.TimeZone;

/** Selects the next active medication reminder for compact dashboard display. */
public final class MedicationReminderSummary {

    private MedicationReminderSummary() {
    }

    public static Result findNext(
            List<Medication> medications,
            long nowMillis,
            TimeZone timeZone
    ) {
        if (medications == null || medications.isEmpty()) {
            return null;
        }

        TimeZone resolvedTimeZone =
                timeZone == null ? TimeZone.getDefault() : timeZone;
        Result selected = null;

        for (Medication medication : medications) {
            if (medication == null
                    || !medication.isActive()
                    || !medication.isReminderEnabled()
                    || !medication.hasValidReminderTime()) {
                continue;
            }

            long triggerAtMillis =
                    MedicationTimeCalculator.nextDailyTriggerMillis(
                            medication.getReminderHour(),
                            medication.getReminderMinute(),
                            nowMillis,
                            resolvedTimeZone
                    );

            if (selected == null
                    || triggerAtMillis < selected.triggerAtMillis) {
                selected = new Result(medication, triggerAtMillis);
            }
        }

        return selected;
    }

    public static final class Result {
        private final Medication medication;
        private final long triggerAtMillis;

        private Result(
                Medication medication,
                long triggerAtMillis
        ) {
            this.medication = medication;
            this.triggerAtMillis = triggerAtMillis;
        }

        public Medication getMedication() {
            return medication;
        }

        public long getTriggerAtMillis() {
            return triggerAtMillis;
        }
    }
}
