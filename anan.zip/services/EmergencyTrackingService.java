package com.example.app.services;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class EmergencyTrackingService {

    private final DatabaseReference database = FirebaseDatabase.getInstance().getReference("emergencies");

    public Query trackUser(String uid, ValueEventListener listener) {
        Query query = database.orderByChild("userId").equalTo(uid);
        query.addValueEventListener(listener);
        return query;
    }
}
