package com.example.app.services;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.activities.CallActivity;
import com.example.app.models.CallSession;
import com.example.app.repositories.CallRepository;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;

import java.util.HashSet;
import java.util.Set;

public class IncomingCallListener {

    private final Context context;
    private final CallRepository repository = new CallRepository();
    private final Set<String> notifiedCalls = new HashSet<>();
    private Query query;
    private ChildEventListener listener;

    public IncomingCallListener(Context context) {
        this.context = context.getApplicationContext();
    }

    public void listen(String userId) {
        stop();
        if (userId == null || userId.trim().isEmpty()) return;
        query = repository.incomingCalls(userId);
        listener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, String previousChildName) {
                handle(snapshot);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) {
                handle(snapshot);
            }

            @Override public void onChildRemoved(@NonNull DataSnapshot snapshot) { }
            @Override public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) { }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        query.addChildEventListener(listener);
    }

    private void handle(DataSnapshot snapshot) {
        CallSession call = snapshot.getValue(CallSession.class);
        if (call == null || call.getCallId() == null) return;
        if (!"ringing".equals(call.getStatus())) {
            notifiedCalls.remove(call.getCallId());
            return;
        }
        if (!notifiedCalls.add(call.getCallId())) return;

        Intent intent = new Intent(context, CallActivity.class);
        intent.putExtra("callId", call.getCallId());
        intent.putExtra("callType", call.getType());
        intent.putExtra("incoming", true);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                call.getCallId().hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder notification = new NotificationCompat.Builder(
                context,
                HealthMateApplication.CALL_CHANNEL_ID
        )
                .setSmallIcon("video".equals(call.getType()) ? R.drawable.ic_video : R.drawable.ic_call)
                .setContentTitle("Incoming HealthMate call")
                .setContentText("Tap to answer the " + ("video".equals(call.getType()) ? "video" : "voice") + " call.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(call.getCallId().hashCode(), notification.build());
    }

    public void stop() {
        if (query != null && listener != null) query.removeEventListener(listener);
        query = null;
        listener = null;
        notifiedCalls.clear();
    }
}
