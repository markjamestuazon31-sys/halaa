package com.example.app.services;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.activities.CallActivity;
import com.example.app.activities.ChatActivity;
import com.example.app.activities.EmergencyContactsActivity;
import com.example.app.activities.FamilyTrackingMapActivity;
import com.example.app.notifications.NotificationDeliveryDeduplicator;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Locale;
import java.util.Map;

/** Receives data-only FCM messages and builds immediate Android alerts. */
public class EmergencyNotificationService extends FirebaseMessagingService {

    private static final long[] SOS_VIBRATION =
            new long[]{0L, 350L, 180L, 650L, 180L, 900L};

    @Override
    public void onNewToken(@NonNull String token) {
        FcmTokenRegistrar.saveToken(token);
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        String title = valueOrDefault(
                data.get("title"),
                remoteMessage.getNotification() == null
                        ? null
                        : remoteMessage.getNotification().getTitle(),
                "HealthMate notification"
        );
        String body = valueOrDefault(
                data.get("message"),
                remoteMessage.getNotification() == null
                        ? null
                        : remoteMessage.getNotification().getBody(),
                "You have a new HealthMate update."
        );
        String type = valueOrDefault(data.get("type"), null, "general");
        String notificationId = firstNonBlank(
                data.get("notificationId"),
                remoteMessage.getMessageId()
        );
        if (!blank(notificationId)
                && !NotificationDeliveryDeduplicator.claim(
                        this,
                        "notification:" + notificationId
                )) {
            return;
        }
        String userId = data.get("userId");
        String incidentId = firstNonBlank(
                data.get("incidentId"),
                data.get("emergencyId")
        );
        String callId = data.get("callId");
        String createdBy = data.get("createdBy");

        showNotification(
                title,
                body,
                type,
                userId,
                incidentId,
                callId,
                createdBy
        );
    }

    private void showNotification(
            String title,
            String body,
            String type,
            String userId,
            String incidentId,
            String callId,
            String createdBy
    ) {
        boolean incomingCall = "incoming_call".equals(type)
                && !blank(callId);
        boolean emergency = isEmergencyType(type);
        boolean urgent = isUrgentEmergencyType(type);

        Intent intent;
        if (incomingCall) {
            intent = new Intent(this, CallActivity.class)
                    .putExtra("callId", callId)
                    .putExtra("incoming", true);
        } else if ("contact_request".equals(type)
                || "contact_accepted".equals(type)) {
            intent = new Intent(this, EmergencyContactsActivity.class);
        } else if ("chat_message".equals(type) && !blank(createdBy)) {
            intent = new Intent(this, ChatActivity.class)
                    .putExtra("receiverId", createdBy);
        } else if (emergency) {
            String emergencyUserId = firstNonBlank(createdBy, userId);
            intent = new Intent(this, FamilyTrackingMapActivity.class)
                    .putExtra("userId", emergencyUserId)
                    .putExtra("incidentId", incidentId)
                    .putExtra("emergencyId", incidentId);
        } else {
            intent = new Intent(this, MainActivity.class);
        }

        intent.addFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        | Intent.FLAG_ACTIVITY_NEW_TASK
        );

        String requestKey = emergency && !blank(incidentId)
                ? "sos:" + incidentId
                : incomingCall
                ? "call:" + callId
                : type + ":" + System.currentTimeMillis();
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                requestKey.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );

        String channelId = incomingCall
                ? HealthMateApplication.CALL_CHANNEL_ID
                : urgent
                ? HealthMateApplication.EMERGENCY_CHANNEL_ID
                : HealthMateApplication.GENERAL_CHANNEL_ID;

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(
                                incomingCall
                                        ? R.drawable.ic_call
                                        : emergency
                                        ? R.drawable.ic_warning
                                        : R.drawable.ic_notifications
                        )
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(
                                new NotificationCompat.BigTextStyle()
                                        .bigText(body)
                        )
                        .setPriority(
                                urgent || incomingCall
                                        ? NotificationCompat.PRIORITY_MAX
                                        : NotificationCompat.PRIORITY_DEFAULT
                        )
                        .setCategory(
                                incomingCall
                                        ? NotificationCompat.CATEGORY_CALL
                                        : urgent
                                        ? NotificationCompat.CATEGORY_ALARM
                                        : emergency
                                        ? NotificationCompat.CATEGORY_STATUS
                                        : NotificationCompat.CATEGORY_MESSAGE
                        )
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);

        if (urgent) {
            builder.setVibrate(SOS_VIBRATION)
                    .setDefaults(
                            NotificationCompat.DEFAULT_SOUND
                                    | NotificationCompat.DEFAULT_LIGHTS
                    )
                    .setColor(ContextCompat.getColor(
                            this,
                            R.color.hm_map_emergency
                    ));
        }

        NotificationManager manager =
                getSystemService(NotificationManager.class);
        if (manager != null) {
            int notificationId;
            if (incomingCall) {
                notificationId = callId.hashCode();
            } else if (emergency && !blank(incidentId)) {
                notificationId = ("sos:" + incidentId).hashCode();
            } else {
                notificationId = (int) (
                        System.currentTimeMillis() & 0x7fffffff
                );
            }
            manager.notify(notificationId, builder.build());
        }
    }

    private boolean isEmergencyType(@Nullable String type) {
        String value = safe(type).toLowerCase(Locale.US);
        return value.startsWith("emergency") || value.startsWith("sos");
    }

    private boolean isUrgentEmergencyType(@Nullable String type) {
        String value = safe(type).toLowerCase(Locale.US);
        return "emergency_sos".equals(value)
                || "emergency_alert".equals(value)
                || "emergency_backup".equals(value)
                || value.startsWith("sos")
                || "critical_alert".equals(value);
    }

    private String firstNonBlank(
            @Nullable String first,
            @Nullable String second
    ) {
        return blank(first) ? safe(second) : first.trim();
    }

    private String valueOrDefault(
            @Nullable String first,
            @Nullable String second,
            @NonNull String fallback
    ) {
        if (!blank(first)) {
            return first.trim();
        }
        if (!blank(second)) {
            return second.trim();
        }
        return fallback;
    }

    private boolean blank(@Nullable String value) {
        return value == null || value.trim().isEmpty();
    }

    private String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }
}
