package com.example.app.services;

import android.content.Context;

import com.example.app.models.Announcement;
import com.example.app.utils.AnnouncementSeenStore;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public final class AnnouncementDelivery {

    private AnnouncementDelivery() {
    }

    public static void deliver(
            Context context,
            String userId,
            Announcement announcement
    ) {
        if (announcement == null
                || isBlank(userId)
                || isBlank(announcement.getId())) {
            return;
        }
        if (!announcement.isVisible(
                System.currentTimeMillis()
        )) {
            return;
        }
        if (AnnouncementSeenStore.isSeen(
                context,
                userId,
                announcement.getId()
        )) {
            return;
        }

        AnnouncementSeenStore.markSeen(
                context,
                userId,
                announcement.getId()
        );
        writeInbox(userId, announcement);
        AnnouncementNotificationHelper.show(
                context,
                announcement
        );
    }

    private static void writeInbox(
            String userId,
            Announcement announcement
    ) {
        String inboxId =
                "announcement_"
                        + sanitize(announcement.getId());
        DatabaseReference reference =
                FirebaseDatabase.getInstance()
                        .getReference("notifications")
                        .child(userId)
                        .child(inboxId);

        Map<String, Object> notification =
                new HashMap<>();
        notification.put(
                "title",
                announcement.getTitle()
        );
        notification.put(
                "message",
                announcement.getContent()
        );
        notification.put("type", "announcement");
        notification.put(
                "announcementId",
                announcement.getId()
        );
        notification.put(
                "category",
                announcement.getCategory()
        );
        notification.put(
                "createdBy",
                announcement.getCreatedBy()
        );
        notification.put(
                "senderId",
                announcement.getCreatedBy()
        );
        notification.put("read", false);
        notification.put(
                "createdAt",
                announcement.getCreatedAt()
        );
        notification.put(
                "timestamp",
                announcement.getCreatedAt()
        );
        reference.setValue(notification);
    }

    private static String sanitize(String value) {
        return value.replaceAll(
                "[.#$\\[\\]/]",
                "_"
        );
    }

    private static boolean isBlank(String value) {
        return value == null
                || value.trim().isEmpty();
    }
}
