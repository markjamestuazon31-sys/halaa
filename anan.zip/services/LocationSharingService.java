package com.example.app.services;

import android.Manifest;
import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.repositories.LocationSharingRepository;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class LocationSharingService extends Service {
    private static final String ACTION_STOP="com.example.app.action.STOP_CONTACT_LOCATION";
    private static final int NOTIFICATION_ID=7402;
    private final LocationSharingRepository sharingRepository=new LocationSharingRepository();
    private FusedLocationProviderClient locationClient;
    private LocationCallback callback;
    private DatabaseReference locationRef;
    private String uid;
    private boolean sosActive;
    private Location lastWritten;
    private long lastWrittenAt;

    public static void refresh(Context context){
        String uid=FirebaseAuth.getInstance().getUid();
        if(uid==null){stop(context);return;}
        new LocationSharingRepository().publishingRequired(uid,new LocationSharingRepository.PublishingCallback(){
            @Override public void onResult(boolean required,boolean sos){
                if(!required){stop(context);return;}
                if(ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED
                        &&ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
                Intent intent=new Intent(context,LocationSharingService.class); intent.putExtra("sosActive",sos);
                ContextCompat.startForegroundService(context,intent);
            }
        });
    }

    public static void stop(Context context){
        String currentUid=FirebaseAuth.getInstance().getUid();
        if(currentUid!=null&&!currentUid.trim().isEmpty()){
            FirebaseDatabase.getInstance().getReference("liveLocations").child(currentUid).removeValue();
        }
        context.stopService(new Intent(context,LocationSharingService.class));
    }

    @Override public void onCreate(){
        super.onCreate(); locationClient=LocationServices.getFusedLocationProviderClient(this);
        callback=new LocationCallback(){@Override public void onLocationResult(@NonNull LocationResult result){Location location=result.getLastLocation();if(location!=null)publishIfMeaningful(location);}};
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&ACTION_STOP.equals(intent.getAction())){removePublishedLocation();stopSelf();return START_NOT_STICKY;}
        uid=FirebaseAuth.getInstance().getUid(); if(uid==null){stopSelf();return START_NOT_STICKY;}
        sosActive=intent!=null&&intent.getBooleanExtra("sosActive",false);
        locationRef=FirebaseDatabase.getInstance().getReference("liveLocations").child(uid);
        startForeground(NOTIFICATION_ID,notification()); startUpdates(); return START_STICKY;
    }

    private Notification notification(){
        return new NotificationCompat.Builder(this,HealthMateApplication.ACTIVE_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_home_map)
                .setContentTitle("HealthMate location sharing")
                .setContentText(sosActive?"Sharing location for an active SOS.":"Sharing location with approved contacts.")
                .setPriority(NotificationCompat.PRIORITY_LOW).setOngoing(true).setOnlyAlertOnce(true).build();
    }

    private void startUpdates(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED
                &&ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){stopSelf();return;}
        LocationRequest request=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,15_000L)
                .setMinUpdateIntervalMillis(5_000L).setMinUpdateDistanceMeters(15f).build();
        locationClient.removeLocationUpdates(callback); locationClient.requestLocationUpdates(request,callback,getMainLooper());
    }

    private void publishIfMeaningful(Location location){
        long now=System.currentTimeMillis();
        boolean heartbeat=now-lastWrittenAt>=60_000L;
        boolean moved=lastWritten==null||lastWritten.distanceTo(location)>=20f;
        if(!heartbeat&&!moved)return;
        Map<String,Object> value=new HashMap<>();
        value.put("uid",uid);value.put("latitude",location.getLatitude());value.put("longitude",location.getLongitude());
        value.put("accuracy",(double)location.getAccuracy());value.put("bearing",(double)location.getBearing());value.put("speed",(double)location.getSpeed());
        value.put("updatedAt",now);value.put("source",sosActive?"SOS":"DEVICE");
        if(locationRef!=null)locationRef.setValue(value);lastWritten=new Location(location);lastWrittenAt=now;
    }

    private void removePublishedLocation(){String current=uid!=null?uid:FirebaseAuth.getInstance().getUid();if(current!=null)FirebaseDatabase.getInstance().getReference("liveLocations").child(current).removeValue();}
    @Override public void onDestroy(){if(locationClient!=null&&callback!=null)locationClient.removeLocationUpdates(callback);super.onDestroy();}
    @Nullable @Override public IBinder onBind(Intent intent){return null;}
}
