package com.example.app.services;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.activities.CallActivity;
import com.example.app.activities.ChatActivity;
import com.example.app.activities.FamilyTrackingMapActivity;
import com.example.app.activities.NotificationActivity;
import com.example.app.activities.RelationshipRequestsActivity;
import com.example.app.notifications.NotificationDeliveryDeduplicator;
import com.example.app.receivers.CallActionReceiver;
import com.example.app.repositories.CallRepository;
import com.example.app.repositories.PresenceRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

/**
 * Foreground Realtime Database listener used while a signed-in HealthMate
 * session is active. FCM remains the delivery path when Android stops this
 * process; both paths route SOS alerts to the same incident-scoped map.
 */
public class HealthMateRealtimeService extends Service {

    private static final int ACTIVE_NOTIFICATION_ID = 7401;
    private static final long[] SOS_VIBRATION =
            new long[]{0L, 350L, 180L, 650L, 180L, 900L};

    private final Set<String> delivered = new HashSet<>();
    private final PresenceRepository presenceRepository =
            new PresenceRepository();

    private DatabaseReference conversationsRef;
    private DatabaseReference requestsRef;
    private DatabaseReference callsRef;
    private DatabaseReference notificationsRef;
    private DatabaseReference relationshipsRef;
    private DatabaseReference ownPresenceRef;

    private ChildEventListener conversationListener;
    private ChildEventListener requestListener;
    private ChildEventListener callListener;
    private ChildEventListener notificationListener;
    private ChildEventListener relationshipListener;
    private ValueEventListener ownPresenceListener;

    private String uid;
    private String activeConversationId = "";

    public static void start(@NonNull Context context) {
        if (FirebaseAuth.getInstance().getUid() != null) {
            ContextCompat.startForegroundService(
                    context,
                    new Intent(context, HealthMateRealtimeService.class)
            );
        }
    }

    public static void stop(@NonNull Context context) {
        context.stopService(
                new Intent(context, HealthMateRealtimeService.class)
        );
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(ACTIVE_NOTIFICATION_ID, activeNotification());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String current = FirebaseAuth.getInstance().getUid();
        if (current == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (current.equals(uid) && conversationListener != null) {
            return START_STICKY;
        }

        stopListeners();
        uid = current;
        presenceRepository.connect(uid);
        listen();
        return START_STICKY;
    }

    private Notification activeNotification() {
        Intent launch = getPackageManager()
                .getLaunchIntentForPackage(getPackageName());
        if (launch == null) {
            launch = new Intent(this, MainActivity.class);
        }
        launch.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
        );
        PendingIntent content = PendingIntent.getActivity(
                this,
                ACTIVE_NOTIFICATION_ID,
                launch,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(
                this,
                HealthMateApplication.ACTIVE_CHANNEL_ID
        )
                .setSmallIcon(R.drawable.ic_home_shield_check)
                .setContentTitle("HealthMate active")
                .setContentText(
                        "Monitoring messages, calls, location sharing, and emergency alerts."
                )
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(content)
                .build();
    }

    private void listen() {
        DatabaseReference root = FirebaseDatabase.getInstance()
                .getReference();

        ownPresenceRef = root.child("userPresence").child(uid);
        ownPresenceListener = ownPresenceRef.addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        activeConversationId = string(
                                snapshot,
                                "activeConversationId"
                        );
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        activeConversationId = "";
                    }
                }
        );

        conversationsRef = root.child("userConversations").child(uid);
        conversationListener = new BaseChildListener() {
            @Override
            void handle(DataSnapshot snapshot) {
                String conversationId = snapshot.getKey();
                String sender = string(snapshot, "lastMessageSenderUid");
                String other = string(snapshot, "otherParticipantUid");
                Long at = snapshot.child("lastMessageAt").getValue(Long.class);
                Long unread = snapshot.child("unreadCount").getValue(Long.class);
                boolean muted = Boolean.TRUE.equals(
                        snapshot.child("muted").getValue(Boolean.class)
                );

                if (blank(conversationId)
                        || uid.equals(sender)
                        || muted
                        || conversationId.equals(activeConversationId)
                        || at == null
                        || unread == null
                        || unread <= 0L) {
                    return;
                }
                notifyMessage(
                        conversationId,
                        other,
                        string(snapshot, "lastMessageText"),
                        at
                );
            }
        };
        conversationsRef.addChildEventListener(conversationListener);

        relationshipsRef = root.child("relationships").child(uid);
        relationshipListener = new BaseChildListener() {
            @Override
            void handle(DataSnapshot snapshot) {
                LocationSharingService.refresh(
                        HealthMateRealtimeService.this
                );
            }
        };
        relationshipsRef.addChildEventListener(relationshipListener);

        requestsRef = root.child("relationshipRequests").child(uid);
        requestListener = new BaseChildListener() {
            @Override
            void handle(DataSnapshot snapshot) {
                String status = string(snapshot, "status");
                Long at = snapshot.child("updatedAt").getValue(Long.class);
                if (!"PENDING".equals(status) || at == null) {
                    return;
                }
                notifyRequest(
                        snapshot.getKey(),
                        string(snapshot, "relationshipType"),
                        at
                );
            }
        };
        requestsRef.addChildEventListener(requestListener);

        callsRef = root.child("incomingCalls").child(uid);
        callListener = new BaseChildListener() {
            @Override
            void handle(DataSnapshot snapshot) {
                String callId = snapshot.getKey();
                String status = string(snapshot, "status");
                if (!"RINGING".equals(status)) {
                    cancelCallNotification(callId);
                    return;
                }

                Long expiresAt = snapshot.child("expiresAt")
                        .getValue(Long.class);
                if (expiresAt != null
                        && expiresAt < System.currentTimeMillis()) {
                    if (!blank(callId)) {
                        new CallRepository().updateStatus(callId, "missed");
                    }
                    return;
                }
                notifyCall(snapshot);
            }
        };
        callsRef.addChildEventListener(callListener);

        notificationsRef = root.child("notifications").child(uid);
        notificationListener = new BaseChildListener() {
            @Override
            void handle(DataSnapshot snapshot) {
                Long at = snapshot.child("createdAt").getValue(Long.class);
                if (at == null
                        || Boolean.TRUE.equals(
                                snapshot.child("read").getValue(Boolean.class)
                        )) {
                    return;
                }

                String type = string(snapshot, "type");
                if ("chat_message".equals(type)
                        || "incoming_call".equals(type)
                        || "contact_request".equals(type)) {
                    return;
                }
                notifyDatabaseNotification(snapshot);
            }
        };
        notificationsRef.addChildEventListener(notificationListener);
    }

    private void notifyMessage(
            String conversationId,
            String otherUid,
            String text,
            long at
    ) {
        String key = "m:" + conversationId + ":" + at;
        if (!delivered.add(key)) {
            return;
        }

        Intent intent = new Intent(this, ChatActivity.class)
                .putExtra("conversationId", conversationId)
                .putExtra("receiverId", otherUid)
                .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                );
        PendingIntent pending = activityPendingIntent(key, intent);

        post(
                key.hashCode(),
                new NotificationCompat.Builder(
                        this,
                        HealthMateApplication.MESSAGE_CHANNEL_ID
                )
                        .setSmallIcon(R.drawable.ic_home_chat)
                        .setContentTitle("New HealthMate message")
                        .setContentText(
                                blank(text)
                                        ? "Open the conversation to read the message."
                                        : text
                        )
                        .setAutoCancel(true)
                        .setContentIntent(pending)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .build()
        );
    }

    private void notifyRequest(String requestId, String type, long at) {
        String key = "r:" + requestId + ":" + at;
        if (!delivered.add(key)) {
            return;
        }

        Intent intent = new Intent(
                this,
                RelationshipRequestsActivity.class
        ).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
        );
        PendingIntent pending = activityPendingIntent(key, intent);

        post(
                key.hashCode(),
                new NotificationCompat.Builder(
                        this,
                        HealthMateApplication.MESSAGE_CHANNEL_ID
                )
                        .setSmallIcon(R.drawable.ic_home_contacts)
                        .setContentTitle(
                                "New "
                                        + ("FAMILY".equals(type)
                                        ? "family"
                                        : "friend")
                                        + " request"
                        )
                        .setContentText(
                                "Open HealthMate to accept or reject the relationship request."
                        )
                        .setContentIntent(pending)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .build()
        );
    }

    private void notifyCall(DataSnapshot snapshot) {
        String callId = snapshot.getKey();
        if (blank(callId) || !delivered.add("c:" + callId)) {
            return;
        }

        String type = string(snapshot, "callType");
        Intent answer = new Intent(this, CallActivity.class)
                .putExtra("callId", callId)
                .putExtra(
                        "callType",
                        "VIDEO".equals(type) ? "video" : "audio"
                )
                .putExtra("incoming", true)
                .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                );
        PendingIntent answerPending = PendingIntent.getActivity(
                this,
                callId.hashCode(),
                answer,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );

        Intent decline = new Intent(this, CallActionReceiver.class)
                .setAction(CallActionReceiver.ACTION_DECLINE)
                .putExtra("callId", callId);
        PendingIntent declinePending = PendingIntent.getBroadcast(
                this,
                callId.hashCode() + 1,
                decline,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        this,
                        HealthMateApplication.CALL_CHANNEL_ID
                )
                        .setSmallIcon(
                                "VIDEO".equals(type)
                                        ? R.drawable.ic_video
                                        : R.drawable.ic_call
                        )
                        .setContentTitle("Incoming HealthMate call")
                        .setContentText("An accepted contact is calling you.")
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setCategory(NotificationCompat.CATEGORY_CALL)
                        .setOngoing(true)
                        .setContentIntent(answerPending)
                        .addAction(
                                R.drawable.ic_call,
                                "Answer",
                                answerPending
                        )
                        .addAction(
                                android.R.drawable.ic_menu_close_clear_cancel,
                                "Decline",
                                declinePending
                        );
        post(callId.hashCode(), builder.build());
    }

    private void notifyDatabaseNotification(DataSnapshot snapshot) {
        String notificationId = safe(snapshot.getKey());
        String key = "n:" + notificationId;
        if (notificationId.isEmpty()
                || !delivered.add(key)
                || !NotificationDeliveryDeduplicator.claim(
                        this,
                        "notification:" + notificationId
                )) {
            return;
        }

        String type = string(snapshot, "type");
        boolean emergency = isEmergencyType(type);
        boolean urgent = isUrgentEmergencyType(type);
        String title = string(snapshot, "title");
        String message = string(snapshot, "message");

        Intent intent;
        String incidentId = firstNonBlank(
                string(snapshot, "incidentId"),
                string(snapshot, "emergencyId")
        );
        if (emergency) {
            intent = new Intent(this, FamilyTrackingMapActivity.class)
                    .putExtra("incidentId", incidentId)
                    .putExtra("emergencyId", incidentId)
                    .putExtra("userId", string(snapshot, "createdBy"));
        } else {
            intent = new Intent(this, NotificationActivity.class);
        }
        intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
        );
        PendingIntent pending = activityPendingIntent(key, intent);

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        this,
                        urgent
                                ? HealthMateApplication.EMERGENCY_CHANNEL_ID
                                : HealthMateApplication.GENERAL_CHANNEL_ID
                )
                        .setSmallIcon(
                                emergency
                                        ? R.drawable.ic_warning
                                        : R.drawable.ic_home_bell
                        )
                        .setContentTitle(
                                blank(title)
                                        ? emergency
                                        ? "Emergency SOS"
                                        : "HealthMate update"
                                        : title
                        )
                        .setContentText(
                                blank(message)
                                        ? emergency
                                        ? "A paired contact needs immediate assistance."
                                        : "Open HealthMate for details."
                                        : message
                        )
                        .setStyle(new NotificationCompat.BigTextStyle()
                                .bigText(
                                        blank(message)
                                                ? "Open HealthMate for details."
                                                : message
                                ))
                        .setContentIntent(pending)
                        .setAutoCancel(true)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setPriority(
                                urgent
                                        ? NotificationCompat.PRIORITY_MAX
                                        : NotificationCompat.PRIORITY_HIGH
                        )
                        .setCategory(
                                urgent
                                        ? NotificationCompat.CATEGORY_ALARM
                                        : emergency
                                        ? NotificationCompat.CATEGORY_STATUS
                                        : NotificationCompat.CATEGORY_MESSAGE
                        );

        if (urgent) {
            builder.setVibrate(SOS_VIBRATION)
                    .setDefaults(
                            NotificationCompat.DEFAULT_SOUND
                                    | NotificationCompat.DEFAULT_LIGHTS
                    )
                    .setColor(ContextCompat.getColor(
                            this,
                            R.color.hm_map_emergency
                    ));
        }

        post(key.hashCode(), builder.build());
    }

    private PendingIntent activityPendingIntent(
            @NonNull String key,
            @NonNull Intent intent
    ) {
        return PendingIntent.getActivity(
                this,
                key.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void cancelCallNotification(@Nullable String callId) {
        if (blank(callId)) {
            return;
        }
        NotificationManager manager =
                getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.cancel(callId.hashCode());
        }
        delivered.remove("c:" + callId);
    }

    private void post(int id, Notification notification) {
        NotificationManager manager =
                getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.notify(id, notification);
        }
    }

    private void stopListeners() {
        if (conversationsRef != null && conversationListener != null) {
            conversationsRef.removeEventListener(conversationListener);
        }
        if (requestsRef != null && requestListener != null) {
            requestsRef.removeEventListener(requestListener);
        }
        if (callsRef != null && callListener != null) {
            callsRef.removeEventListener(callListener);
        }
        if (notificationsRef != null && notificationListener != null) {
            notificationsRef.removeEventListener(notificationListener);
        }
        if (relationshipsRef != null && relationshipListener != null) {
            relationshipsRef.removeEventListener(relationshipListener);
        }
        if (ownPresenceRef != null && ownPresenceListener != null) {
            ownPresenceRef.removeEventListener(ownPresenceListener);
        }

        conversationsRef = null;
        requestsRef = null;
        callsRef = null;
        notificationsRef = null;
        relationshipsRef = null;
        ownPresenceRef = null;
        conversationListener = null;
        requestListener = null;
        callListener = null;
        notificationListener = null;
        relationshipListener = null;
        ownPresenceListener = null;
        activeConversationId = "";
        delivered.clear();
    }

    @Override
    public void onDestroy() {
        stopListeners();
        if (uid != null) {
            presenceRepository.disconnect(uid);
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private boolean isEmergencyType(@Nullable String type) {
        String value = safe(type).toLowerCase(Locale.US);
        return value.startsWith("emergency")
                || value.startsWith("sos");
    }

    private boolean isUrgentEmergencyType(@Nullable String type) {
        String value = safe(type).toLowerCase(Locale.US);
        return "emergency_sos".equals(value)
                || "emergency_alert".equals(value)
                || "emergency_backup".equals(value)
                || value.startsWith("sos")
                || "critical_alert".equals(value);
    }

    private String string(DataSnapshot snapshot, String child) {
        String value = snapshot.child(child).getValue(String.class);
        return safe(value);
    }

    private String firstNonBlank(String first, String second) {
        return blank(first) ? safe(second) : first.trim();
    }

    private String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }

    private boolean blank(@Nullable String value) {
        return value == null || value.trim().isEmpty();
    }

    private abstract static class BaseChildListener
            implements ChildEventListener {

        abstract void handle(DataSnapshot snapshot);

        @Override
        public void onChildAdded(
                @NonNull DataSnapshot snapshot,
                @Nullable String previousChildName
        ) {
            handle(snapshot);
        }

        @Override
        public void onChildChanged(
                @NonNull DataSnapshot snapshot,
                @Nullable String previousChildName
        ) {
            handle(snapshot);
        }

        @Override
        public void onChildRemoved(@NonNull DataSnapshot snapshot) {
            // No action required for general records.
        }

        @Override
        public void onChildMoved(
                @NonNull DataSnapshot snapshot,
                @Nullable String previousChildName
        ) {
            // Ordering changes do not require a notification.
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {
            // FCM remains available if a foreground listener is interrupted.
        }
    }
}
