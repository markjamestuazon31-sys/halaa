package com.example.app.services;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.activities.MedicationActivity;
import com.example.app.models.Medication;
import com.example.app.receivers.MedicationActionReceiver;
import com.example.app.utils.MedicationAlarmScheduler;

public final class MedicationReminderService {

    private MedicationReminderService() {
    }

    public static void showReminder(
            Context context,
            String userId,
            Medication medication
    ) {
        if (medication == null) return;
        createChannel(context);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        int notificationId = stableNotificationId(medication.getId());
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                notificationId,
                new Intent(context, MedicationActivity.class)
                        .addFlags(
                                Intent.FLAG_ACTIVITY_CLEAR_TOP
                                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        ),
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );

        PendingIntent takenIntent = actionIntent(
                context,
                MedicationActionReceiver.ACTION_MARK_TAKEN,
                userId,
                medication,
                notificationId,
                11
        );
        PendingIntent snoozeIntent = actionIntent(
                context,
                MedicationActionReceiver.ACTION_SNOOZE,
                userId,
                medication,
                notificationId,
                17
        );

        String medicineName = safe(
                medication.getName(),
                "your medicine"
        );
        String dosage = safe(
                medication.getDosage(),
                "Follow your prescribed dosage"
        );
        String body =
                "Time to take " + medicineName + " — " + dosage;

        Notification notification =
                new NotificationCompat.Builder(
                        context,
                        HealthMateApplication.MEDICATION_CHANNEL_ID
                )
                        .setSmallIcon(
                                R.drawable.ic_hm_medication_capsule
                        )
                        .setContentTitle("Medication reminder")
                        .setContentText(body)
                        .setStyle(
                                new NotificationCompat.BigTextStyle()
                                        .bigText(body)
                        )
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setCategory(NotificationCompat.CATEGORY_REMINDER)
                        .setVisibility(
                                NotificationCompat.VISIBILITY_PUBLIC
                        )
                        .setAutoCancel(true)
                        .setContentIntent(contentIntent)
                        .addAction(0, "Taken", takenIntent)
                        .addAction(0, "Snooze 10 min", snoozeIntent)
                        .build();

        NotificationManagerCompat.from(context).notify(
                notificationId,
                notification
        );
    }

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager manager =
                context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        Uri alarmSound =
                RingtoneManager.getDefaultUri(
                        RingtoneManager.TYPE_ALARM
                );
        AudioAttributes audioAttributes =
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(
                                AudioAttributes.CONTENT_TYPE_SONIFICATION
                        )
                        .build();

        NotificationChannel channel = new NotificationChannel(
                HealthMateApplication.MEDICATION_CHANNEL_ID,
                "Medication reminders",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription(
                "Audible reminders for medicines scheduled by the user"
        );
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 500, 250, 500});
        channel.setSound(alarmSound, audioAttributes);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(channel);
    }

    private static PendingIntent actionIntent(
            Context context,
            String action,
            String userId,
            Medication medication,
            int notificationId,
            int suffix
    ) {
        Intent intent =
                new Intent(context, MedicationActionReceiver.class)
                        .setAction(action)
                        .putExtra(
                                MedicationAlarmScheduler.EXTRA_USER_ID,
                                userId
                        )
                        .putExtra(
                                MedicationAlarmScheduler.EXTRA_MEDICATION_ID,
                                medication.getId()
                        )
                        .putExtra(
                                MedicationAlarmScheduler.EXTRA_MEDICINE_NAME,
                                medication.getName()
                        )
                        .putExtra(
                                MedicationAlarmScheduler.EXTRA_DOSAGE,
                                medication.getDosage()
                        )
                        .putExtra(
                                MedicationAlarmScheduler.EXTRA_HOUR,
                                medication.getReminderHour()
                        )
                        .putExtra(
                                MedicationAlarmScheduler.EXTRA_MINUTE,
                                medication.getReminderMinute()
                        )
                        .putExtra(
                                MedicationActionReceiver.EXTRA_NOTIFICATION_ID,
                                notificationId
                        );

        return PendingIntent.getBroadcast(
                context,
                notificationId + suffix,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static int stableNotificationId(String medicationId) {
        return 50_000
                + Math.abs(
                (medicationId == null
                        ? "medication"
                        : medicationId
                ).hashCode() % 40_000
        );
    }

    private static String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty()
                ? fallback
                : value.trim();
    }
}
