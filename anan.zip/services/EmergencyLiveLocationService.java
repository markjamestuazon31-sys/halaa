package com.example.app.services;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.activities.EmergencyMapActivity;
import com.example.app.emergency.IncidentStatus;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.repositories.EmergencyLiveLocationRepository;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Incident-scoped foreground location publisher. It sends an update after
 * meaningful movement or a bounded heartbeat and stops for terminal incidents
 * or a withdrawn responder.
 */
public class EmergencyLiveLocationService extends Service {
    public static final String ACTION_START_PATIENT = "com.example.app.START_PATIENT_TRACKING";
    public static final String ACTION_START_RESPONDER = "com.example.app.START_RESPONDER_TRACKING";
    public static final String ACTION_STOP = "com.example.app.STOP_EMERGENCY_TRACKING";
    public static final String EXTRA_INCIDENT_ID = "incidentId";

    private static final int NOTIFICATION_ID = 7412;
    private static final long UPDATE_INTERVAL_MS = 15_000L;
    private static final long HEARTBEAT_MS = 60_000L;
    private static final float MIN_MOVEMENT_METERS = 12f;

    private final EmergencyLiveLocationRepository locationRepository = new EmergencyLiveLocationRepository();
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private DatabaseReference incidentReference;
    private DatabaseReference responseReference;
    private ValueEventListener incidentListener;
    private ValueEventListener responseListener;
    private String incidentId;
    private String uid;
    private boolean patientMode;
    private Location lastPublished;
    private long lastPublishedAt;

    @Override
    public void onCreate() {
        super.onCreate();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopTracking();
            return START_NOT_STICKY;
        }
        incidentId = safe(intent.getStringExtra(EXTRA_INCIDENT_ID));
        uid = safe(FirebaseAuth.getInstance().getUid());
        patientMode = ACTION_START_PATIENT.equals(intent.getAction());
        if (incidentId.isEmpty() || uid.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        observeLifecycle();
        startLocationUpdates();
        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, EmergencyMapActivity.class)
                .putExtra(EmergencyMapActivity.EXTRA_INCIDENT_ID, incidentId)
                .putExtra(EmergencyMapActivity.EXTRA_PATIENT_MODE, patientMode)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                incidentId.hashCode(),
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        return new NotificationCompat.Builder(this, HealthMateApplication.EMERGENCY_CHANNEL_ID)
                .setSmallIcon(R.drawable.hm_ic_location_pin)
                .setContentTitle(patientMode ? "Sharing SOS location" : "Sharing response location")
                .setContentText("HealthMate is securely updating this emergency map.")
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();
    }

    private void startLocationUpdates() {
        boolean fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) {
            stopTracking();
            return;
        }
        LocationRequest request = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, UPDATE_INTERVAL_MS)
                .setMinUpdateIntervalMillis(8_000L)
                .setMinUpdateDistanceMeters(5f)
                .build();
        locationCallback = new LocationCallback() {
            @Override public void onLocationResult(LocationResult result) {
                Location location = result.getLastLocation();
                if (location != null && shouldPublish(location)) publish(location);
            }
        };
        fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper());
    }

    private boolean shouldPublish(Location current) {
        long now = System.currentTimeMillis();
        if (lastPublished == null) return true;
        return current.distanceTo(lastPublished) >= MIN_MOVEMENT_METERS || now - lastPublishedAt >= HEARTBEAT_MS;
    }

    private void publish(Location location) {
        long now = System.currentTimeMillis();
        EmergencyLocationPoint point = new EmergencyLocationPoint(
                location.getLatitude(),
                location.getLongitude(),
                location.hasAccuracy() ? location.getAccuracy() : 0f,
                now
        );
        EmergencyLiveLocationRepository.Callback callback = new EmergencyLiveLocationRepository.Callback() {
            @Override public void onSuccess() {
                lastPublished = new Location(location);
                lastPublishedAt = now;
            }
            @Override public void onError(String message) { /* next heartbeat retries */ }
        };
        if (patientMode) {
            locationRepository.publishPatient(incidentId, point, callback);
            Map<String, Object> shared = new HashMap<>();
            shared.put("uid", uid);
            shared.put("latitude", location.getLatitude());
            shared.put("longitude", location.getLongitude());
            shared.put("accuracy", location.hasAccuracy() ? (double) location.getAccuracy() : 0d);
            shared.put("bearing", (double) location.getBearing());
            shared.put("speed", (double) location.getSpeed());
            shared.put("updatedAt", now);
            shared.put("source", "SOS");
            FirebaseDatabase.getInstance().getReference("liveLocations").child(uid).setValue(shared);
        } else locationRepository.publishRespondent(incidentId, uid, point, callback);
    }

    private void observeLifecycle() {
        incidentReference = FirebaseDatabase.getInstance().getReference("emergencies").child(incidentId);
        incidentListener = incidentReference.addValueEventListener(new com.google.firebase.database.ValueEventListener() {
            @Override public void onDataChange(com.google.firebase.database.DataSnapshot snapshot) {
                String status = snapshot.child("status").getValue(String.class);
                if (!snapshot.exists() || IncidentStatus.from(status).isTerminal()) {
                    if (patientMode && !uidSafe().isEmpty()) {
                        Map<String, Object> updates = new HashMap<>();
                        updates.put("sosActive", false);
                        updates.put("activeIncidentId", null);
                        updates.put("updatedAt", System.currentTimeMillis());
                        FirebaseDatabase.getInstance()
                                .getReference("locationSharingPreferences")
                                .child(uid)
                                .updateChildren(updates, (error, reference) ->
                                        LocationSharingService.refresh(EmergencyLiveLocationService.this)
                                );
                    }
                    stopTracking();
                }
            }
            @Override public void onCancelled(com.google.firebase.database.DatabaseError error) { }
        });
        if (!patientMode) {
            responseReference = FirebaseDatabase.getInstance().getReference("emergencyResponses").child(incidentId).child(uid);
            responseListener = responseReference.addValueEventListener(new com.google.firebase.database.ValueEventListener() {
                @Override public void onDataChange(com.google.firebase.database.DataSnapshot snapshot) {
                    Boolean active = snapshot.child("active").getValue(Boolean.class);
                    if (!snapshot.exists() || Boolean.FALSE.equals(active)) stopTracking();
                }
                @Override public void onCancelled(com.google.firebase.database.DatabaseError error) { }
            });
        }
    }

    private void stopTracking() {
        if (locationCallback != null && fusedLocationClient != null) fusedLocationClient.removeLocationUpdates(locationCallback);
        if (incidentReference != null && incidentListener != null) incidentReference.removeEventListener(incidentListener);
        if (responseReference != null && responseListener != null) responseReference.removeEventListener(responseListener);
        if (!patientMode && !incidentIdSafe().isEmpty() && !uidSafe().isEmpty()) {
            locationRepository.stopRespondentSharing(incidentId, uid, new EmergencyLiveLocationRepository.Callback() {
                @Override public void onSuccess() { }
                @Override public void onError(String message) { }
            });
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private String incidentIdSafe() { return incidentId == null ? "" : incidentId; }
    private String uidSafe() { return uid == null ? "" : uid; }
    private String safe(String value) { return value == null ? "" : value.trim(); }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        if (locationCallback != null && fusedLocationClient != null) fusedLocationClient.removeLocationUpdates(locationCallback);
        if (incidentReference != null && incidentListener != null) incidentReference.removeEventListener(incidentListener);
        if (responseReference != null && responseListener != null) responseReference.removeEventListener(responseListener);
        super.onDestroy();
    }
}
