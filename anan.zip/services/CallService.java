package com.example.app.services;

import com.example.app.repositories.CallRepository;

public class CallService {

    private final CallRepository repository;

    public CallService() {
        repository = new CallRepository();
    }

    public void startVoiceCall(String caller, String receiver, CallRepository.CreateCallCallback callback) {
        repository.createCall(caller, receiver, "audio", callback);
    }

    public void startVideoCall(String caller, String receiver, CallRepository.CreateCallCallback callback) {
        repository.createCall(caller, receiver, "video", callback);
    }
}
