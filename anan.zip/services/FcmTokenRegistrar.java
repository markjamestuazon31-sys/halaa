package com.example.app.services;

import android.content.Context;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public final class FcmTokenRegistrar {

    private static final String TAG = "FcmTokenRegistrar";

    private FcmTokenRegistrar() { }

    public static void registerCurrentToken(Context context) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(FcmTokenRegistrar::saveToken)
                .addOnFailureListener(error -> Log.e(TAG, "Unable to obtain FCM token", error));
    }

    public static void saveToken(String token) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null || token == null || token.trim().isEmpty()) return;

        String normalizedToken = token.trim();
        String tokenId = sha256(normalizedToken).substring(0, 24);
        long now = System.currentTimeMillis();

        Map<String, Object> device = new HashMap<>();
        device.put("token", normalizedToken);
        device.put("platform", "android");
        device.put("updatedAt", now);

        Map<String, Object> updates = new HashMap<>();
        updates.put("fcmToken", normalizedToken); // Legacy-compatible primary token.
        updates.put("fcmTokens/" + tokenId, device);
        updates.put("updatedAt", now);

        FirebaseDatabase.getInstance().getReference("users").child(uid)
                .updateChildren(updates)
                .addOnFailureListener(error -> Log.e(TAG, "Unable to register FCM token", error));
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder output = new StringBuilder(bytes.length * 2);
            for (byte item : bytes) output.append(String.format("%02x", item));
            return output.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is unavailable", impossible);
        }
    }
}
