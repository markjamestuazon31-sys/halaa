package com.example.app.services;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.app.models.Announcement;
import com.example.app.utils.AnnouncementSeenStore;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public final class AnnouncementRealtimeManager {

    private static boolean started;
    private static FirebaseAuth.AuthStateListener authListener;
    private static Query activeQuery;
    private static ChildEventListener childListener;

    private AnnouncementRealtimeManager() {
    }

    public static synchronized void start(
            Context context
    ) {
        if (started) return;
        started = true;
        Context appContext =
                context.getApplicationContext();

        authListener =
                auth -> attachForUser(
                        appContext,
                        auth.getCurrentUser()
                );
        FirebaseAuth.getInstance()
                .addAuthStateListener(authListener);
    }

    private static synchronized void attachForUser(
            Context context,
            @Nullable FirebaseUser user
    ) {
        detachQuery();
        if (user == null) return;

        String userId = user.getUid();
        long cutoff =
                AnnouncementSeenStore.getOrCreateCutoff(
                        context,
                        userId
                );
        activeQuery =
                FirebaseDatabase.getInstance()
                        .getReference("announcements")
                        .orderByChild("createdAt")
                        .startAt((double) cutoff)
                        .limitToLast(100);

        childListener =
                new ChildEventListener() {
                    @Override
                    public void onChildAdded(
                            @NonNull DataSnapshot snapshot,
                            @Nullable String previousChildName
                    ) {
                        deliver(snapshot);
                    }

                    @Override
                    public void onChildChanged(
                            @NonNull DataSnapshot snapshot,
                            @Nullable String previousChildName
                    ) {
                        deliver(snapshot);
                    }

                    @Override
                    public void onChildRemoved(
                            @NonNull DataSnapshot snapshot
                    ) { }

                    @Override
                    public void onChildMoved(
                            @NonNull DataSnapshot snapshot,
                            @Nullable String previousChildName
                    ) { }

                    @Override
                    public void onCancelled(
                            @NonNull DatabaseError error
                    ) { }

                    private void deliver(
                            DataSnapshot snapshot
                    ) {
                        Announcement announcement =
                                snapshot.getValue(
                                        Announcement.class
                                );
                        if (announcement == null) return;
                        announcement.setId(
                                snapshot.getKey()
                        );
                        AnnouncementDelivery.deliver(
                                context,
                                userId,
                                announcement
                        );
                    }
                };
        activeQuery.addChildEventListener(
                childListener
        );
    }

    private static void detachQuery() {
        if (activeQuery != null
                && childListener != null) {
            activeQuery.removeEventListener(
                    childListener
            );
        }
        activeQuery = null;
        childListener = null;
    }
}
