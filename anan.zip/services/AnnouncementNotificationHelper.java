package com.example.app.services;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.activities.AnnouncementActivity;
import com.example.app.models.Announcement;

public final class AnnouncementNotificationHelper {

    private AnnouncementNotificationHelper() {
    }

    public static void show(
            Context context,
            Announcement announcement
    ) {
        if (announcement == null
                || announcement.getId() == null) {
            return;
        }
        createChannel(context);

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Intent openIntent =
                new Intent(
                        context,
                        AnnouncementActivity.class
                )
                        .putExtra(
                                "announcementId",
                                announcement.getId()
                        )
                        .addFlags(
                                Intent.FLAG_ACTIVITY_CLEAR_TOP
                                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        );
        PendingIntent pendingIntent =
                PendingIntent.getActivity(
                        context,
                        stableId(announcement.getId()),
                        openIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                                | PendingIntent.FLAG_IMMUTABLE
                );

        String title = safe(
                announcement.getTitle(),
                "HealthMate announcement"
        );
        String content = safe(
                announcement.getContent(),
                "A new community advisory is available."
        );

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        context,
                        HealthMateApplication.ANNOUNCEMENT_CHANNEL_ID
                )
                        .setSmallIcon(
                                R.drawable.ic_notifications
                        )
                        .setContentTitle(title)
                        .setContentText(content)
                        .setStyle(
                                new NotificationCompat.BigTextStyle()
                                        .bigText(content)
                        )
                        .setSubText(
                                safe(
                                        announcement.getCategory(),
                                        "Community update"
                                )
                        )
                        .setPriority(
                                NotificationCompat.PRIORITY_DEFAULT
                        )
                        .setCategory(
                                NotificationCompat.CATEGORY_MESSAGE
                        )
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);

        NotificationManagerCompat.from(context).notify(
                stableId(announcement.getId()),
                builder.build()
        );
    }

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT
                < Build.VERSION_CODES.O) {
            return;
        }
        NotificationManager manager =
                context.getSystemService(
                        NotificationManager.class
                );
        if (manager == null) return;

        NotificationChannel channel =
                new NotificationChannel(
                        HealthMateApplication
                                .ANNOUNCEMENT_CHANNEL_ID,
                        "Barangay announcements",
                        NotificationManager
                                .IMPORTANCE_DEFAULT
                );
        channel.setDescription(
                "Health advisories, disease prevention "
                        + "information, disaster warnings, "
                        + "and community announcements"
        );
        manager.createNotificationChannel(channel);
    }

    private static int stableId(
            String announcementId
    ) {
        return 100_000
                + Math.abs(
                announcementId.hashCode()
                        % 50_000
        );
    }

    private static String safe(
            String value,
            String fallback
    ) {
        return value == null || value.trim().isEmpty()
                ? fallback
                : value.trim();
    }
}
