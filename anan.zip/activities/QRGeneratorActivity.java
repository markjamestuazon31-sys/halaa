package com.example.app.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.utils.QRManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class QRGeneratorActivity extends AppCompatActivity {

    public static final String USER_QR_PREFIX = "healthmate:user:";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_generator);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        ImageView qrImage = findViewById(R.id.qrImage);
        Bitmap qr = QRManager.generateQR(USER_QR_PREFIX + currentUser.getUid());
        if (qr == null) {
            Toast.makeText(this, "Unable to generate your QR code.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        qrImage.setImageBitmap(qr);
    }
}
