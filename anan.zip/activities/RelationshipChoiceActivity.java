package com.example.app.activities;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.app.R;
import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.ContactPublicProfile;
import com.example.app.repositories.ContactQrRepository;
import com.example.app.repositories.RelationshipRepository;
import com.example.app.utils.Base64Manager;
import com.google.android.material.button.MaterialButton;

public class RelationshipChoiceActivity extends AppCompatActivity {
    private String targetUid;private MaterialButton family,friend;private final RelationshipRepository relationships=new RelationshipRepository();
    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_relationship_choice);targetUid=getIntent().getStringExtra("targetUid");String token=getIntent().getStringExtra("contactToken");TextView name=findViewById(R.id.relationshipTargetName);ImageView image=findViewById(R.id.relationshipTargetImage);family=findViewById(R.id.addAsFamily);friend=findViewById(R.id.addAsFriend);family.setEnabled(false);friend.setEnabled(false);findViewById(R.id.relationshipChoiceBack).setOnClickListener(v->finish());
        new ContactQrRepository().resolve(targetUid,token,new ContactQrRepository.ResolveCallback(){@Override public void onResolved(ContactPublicProfile profile){name.setText(profile.getFullName()==null||profile.getFullName().trim().isEmpty()?"HealthMate user":profile.getFullName());Bitmap bitmap=Base64Manager.base64ToBitmap(profile.getProfileImage());if(bitmap!=null)image.setImageBitmap(bitmap);family.setEnabled(true);friend.setEnabled(true);}@Override public void onError(String message){Toast.makeText(RelationshipChoiceActivity.this,message,Toast.LENGTH_LONG).show();finish();}});
        family.setOnClickListener(v->send(RelationshipPolicy.FAMILY));friend.setOnClickListener(v->send(RelationshipPolicy.FRIEND));}
    private void send(String type){family.setEnabled(false);friend.setEnabled(false);relationships.sendRequest(targetUid,type,new RelationshipRepository.Callback(){@Override public void onSuccess(){Toast.makeText(RelationshipChoiceActivity.this,(RelationshipPolicy.FAMILY.equals(type)?"Family":"Friend")+" request sent.",Toast.LENGTH_LONG).show();finish();}@Override public void onError(String message){family.setEnabled(true);friend.setEnabled(true);Toast.makeText(RelationshipChoiceActivity.this,message,Toast.LENGTH_LONG).show();}});}
}
