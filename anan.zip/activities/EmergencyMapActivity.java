package com.example.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

import com.example.app.R;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.repositories.EmergencyLiveLocationRepository;
import com.example.app.utils.MapStyleProvider;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Incident-scoped live map. Firebase rules determine who can read exact points. */
public class EmergencyMapActivity extends AppCompatActivity {
    public static final String EXTRA_INCIDENT_ID = "incidentId";
    public static final String EXTRA_PATIENT_MODE = "patientMode";
    private static final long STALE_AFTER_MS = 120_000L;

    private final EmergencyLiveLocationRepository repository = new EmergencyLiveLocationRepository();
    private final Map<String, Marker> responderMarkers = new LinkedHashMap<>();
    private MapView mapView;
    private MapLibreMap map;
    private Marker patientMarker;
    private LatLng lastPatientPosition;
    private TextView mapContactName, mapStatus, mapCoordinates, mapUpdated, mapLiveBadge;
    private AppCompatImageButton mapRecenterButton;
    private MaterialButton mapCenterAction, mapNavigateAction, mapCallAction;
    private String incidentId;
    private String patientPhone = "";
    private ValueEventListener locationListener;
    private DatabaseReference locationReference;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_emergency_map);
        incidentId = safe(getIntent().getStringExtra(EXTRA_INCIDENT_ID));
        if (incidentId.isEmpty()) {
            // Legacy fallback remains read-only for old family/friend intents.
            incidentId = safe(getIntent().getStringExtra("emergencyId"));
        }
        bind();
        findViewById(R.id.mapBackButton).setOnClickListener(v -> finish());
        mapRecenterButton.setOnClickListener(v -> centerOnPatient());
        mapCenterAction.setOnClickListener(v -> centerOnPatient());
        mapNavigateAction.setOnClickListener(v -> navigate());
        mapCallAction.setOnClickListener(v -> callPatient());
        mapView.onCreate(state);
        String styleUrl = MapStyleProvider.getStyleUrl(this);
        if (styleUrl.isEmpty()) { mapStatus.setText("Map configuration is missing"); return; }
        mapView.getMapAsync(value -> { map = value; map.setStyle(styleUrl, style -> startListening()); });
        loadIncidentIdentity();
    }

    private void bind() {
        mapView=findViewById(R.id.mapView); mapContactName=findViewById(R.id.mapContactName); mapStatus=findViewById(R.id.mapStatus);
        mapCoordinates=findViewById(R.id.mapCoordinates); mapUpdated=findViewById(R.id.mapUpdated); mapLiveBadge=findViewById(R.id.mapLiveBadge);
        mapRecenterButton=findViewById(R.id.mapRecenterButton); mapCenterAction=findViewById(R.id.mapCenterAction);
        mapNavigateAction=findViewById(R.id.mapNavigateAction); mapCallAction=findViewById(R.id.mapCallAction);
        mapRecenterButton.setEnabled(false); mapCenterAction.setEnabled(false); mapNavigateAction.setEnabled(false); mapCallAction.setEnabled(false);
    }

    private void loadIncidentIdentity() {
        if (incidentId.isEmpty()) return;
        FirebaseDatabase.getInstance().getReference("emergencies").child(incidentId).get().addOnSuccessListener(snapshot -> {
            String name=snapshot.child("patientName").getValue(String.class); patientPhone=safe(snapshot.child("patientPhone").getValue(String.class));
            mapContactName.setText(name==null||name.trim().isEmpty()?"Emergency patient":name.trim()); mapCallAction.setEnabled(!patientPhone.isEmpty());
        });
    }

    private void startListening() {
        if (incidentId.isEmpty()) { showLegacyIntentLocation(); return; }
        locationReference=FirebaseDatabase.getInstance().getReference("emergencyLocations").child(incidentId);
        locationListener=repository.listen(incidentId,new EmergencyLiveLocationRepository.Listener(){
            @Override public void onChanged(EmergencyLocationPoint patient, Map<String,EmergencyLocationPoint> respondents){ render(patient,respondents); }
            @Override public void onError(String message){ mapStatus.setText("Live coordinates unavailable"); mapUpdated.setText(message==null?"Access may require incident acceptance.":message); }
        });
    }

    private void render(EmergencyLocationPoint patient, Map<String,EmergencyLocationPoint> respondents) {
        if(map==null)return;
        if(patient==null){mapStatus.setText("Waiting for patient location");mapLiveBadge.setVisibility(View.INVISIBLE);return;}
        LatLng position=new LatLng(patient.getLatitude(),patient.getLongitude()); lastPatientPosition=position;
        if(patientMarker==null)patientMarker=map.addMarker(new MarkerOptions().position(position).title("Patient")); else patientMarker.setPosition(position);
        for(Marker marker:responderMarkers.values())map.removeMarker(marker); responderMarkers.clear();
        if(respondents!=null)for(Map.Entry<String,EmergencyLocationPoint> entry:respondents.entrySet()){
            EmergencyLocationPoint point=entry.getValue(); if(point==null)continue;
            Marker marker=map.addMarker(new MarkerOptions().position(new LatLng(point.getLatitude(),point.getLongitude())).title("Responder "+shortUid(entry.getKey()))); responderMarkers.put(entry.getKey(),marker);
        }
        boolean stale=System.currentTimeMillis()-patient.getUpdatedAt()>STALE_AFTER_MS;
        mapStatus.setText(stale?"Patient location may be stale":"Patient location is live");
        mapCoordinates.setText(String.format(Locale.US,"%.5f, %.5f · accuracy %.0f m",patient.getLatitude(),patient.getLongitude(),patient.getAccuracy()));
        mapUpdated.setText((stale?"Stale — last updated ":"Updated ")+relative(patient.getUpdatedAt())+" · "+responderMarkers.size()+" responder marker(s)");
        mapLiveBadge.setVisibility(stale?View.INVISIBLE:View.VISIBLE); mapRecenterButton.setEnabled(true); mapCenterAction.setEnabled(true); mapNavigateAction.setEnabled(true);
        if(patientMarker!=null&&lastPatientPosition!=null&&patientMarker.getPosition().equals(position)) centerOnPatient();
    }

    private void showLegacyIntentLocation(){
        double lat=getIntent().getDoubleExtra("latitude",Double.NaN),lon=getIntent().getDoubleExtra("longitude",Double.NaN);if(!Double.isFinite(lat)||!Double.isFinite(lon)){mapStatus.setText("Waiting for authorized incident coordinates");return;}
        EmergencyLocationPoint point=new EmergencyLocationPoint(lat,lon,0f,getIntent().getLongExtra("updatedAt",0L));render(point,new LinkedHashMap<>());
    }
    private void centerOnPatient(){if(map!=null&&lastPatientPosition!=null)map.animateCamera(CameraUpdateFactory.newLatLngZoom(lastPatientPosition,15.5));}
    private void navigate(){if(lastPatientPosition==null)return;Uri uri=Uri.parse("google.navigation:q="+lastPatientPosition.getLatitude()+","+lastPatientPosition.getLongitude());Intent intent=new Intent(Intent.ACTION_VIEW,uri);if(intent.resolveActivity(getPackageManager())==null)intent=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+lastPatientPosition.getLatitude()+","+lastPatientPosition.getLongitude()+"?q="+lastPatientPosition.getLatitude()+","+lastPatientPosition.getLongitude()));startActivity(intent);}
    private void callPatient(){if(patientPhone.isEmpty())return;startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(patientPhone))));}
    private String relative(long time){if(time<=0)return"time unavailable";return String.valueOf(DateUtils.getRelativeTimeSpanString(time,System.currentTimeMillis(),DateUtils.MINUTE_IN_MILLIS,DateUtils.FORMAT_ABBREV_RELATIVE));}
    private String shortUid(String uid){return uid==null?"":uid.substring(0,Math.min(uid.length(),6));}
    private String safe(String value){return value==null?"":value.trim();}

    @Override protected void onStart(){super.onStart();mapView.onStart();}
    @Override protected void onResume(){super.onResume();mapView.onResume();}
    @Override protected void onPause(){mapView.onPause();super.onPause();}
    @Override protected void onStop(){mapView.onStop();super.onStop();}
    @Override public void onLowMemory(){super.onLowMemory();mapView.onLowMemory();}
    @Override protected void onDestroy(){if(locationReference!=null&&locationListener!=null)locationReference.removeEventListener(locationListener);mapView.onDestroy();super.onDestroy();}
}
