package com.example.app.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.Relationship;
import com.example.app.models.RelationshipRequest;
import com.example.app.repositories.LocationSharingRepository;
import com.example.app.repositories.RelationshipRepository;
import com.example.app.services.LocationSharingService;
import com.example.app.utils.Base64Manager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RelationshipRequestsActivity extends AppCompatActivity {
    private final RelationshipRepository repository=new RelationshipRepository();
    private final LocationSharingRepository sharingRepository=new LocationSharingRepository();
    private LinearLayout requestsContainer,contactsContainer;private TextView requestsEmpty,contactsEmpty;private String uid;private ValueEventListener requestListener,relationshipListener;

    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_relationship_requests);uid=FirebaseAuth.getInstance().getUid();if(uid==null){finish();return;}requestsContainer=findViewById(R.id.relationshipRequestsContainer);contactsContainer=findViewById(R.id.acceptedRelationshipsContainer);requestsEmpty=findViewById(R.id.relationshipRequestsEmpty);contactsEmpty=findViewById(R.id.acceptedRelationshipsEmpty);findViewById(R.id.relationshipBack).setOnClickListener(v->finish());listen();}

    private void listen(){
        requestListener=new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot snapshot){requestsContainer.removeAllViews();int count=0;for(DataSnapshot child:snapshot.getChildren()){RelationshipRequest request=child.getValue(RelationshipRequest.class);if(request==null||!RelationshipPolicy.PENDING.equals(RelationshipPolicy.normalize(request.getStatus())))continue;count++;addRequestCard(request);}requestsEmpty.setVisibility(count==0?View.VISIBLE:View.GONE);}@Override public void onCancelled(@NonNull DatabaseError error){show(error.getMessage());}};repository.listenIncoming(uid,requestListener);
        relationshipListener=new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot snapshot){contactsContainer.removeAllViews();int count=0;for(DataSnapshot child:snapshot.getChildren()){Relationship relationship=child.getValue(Relationship.class);if(relationship==null||!RelationshipPolicy.ACCEPTED.equals(RelationshipPolicy.normalize(relationship.getStatus())))continue;String contactUid=child.getKey();if(contactUid==null)continue;count++;addContactCard(contactUid,relationship);}contactsEmpty.setVisibility(count==0?View.VISIBLE:View.GONE);}@Override public void onCancelled(@NonNull DatabaseError error){show(error.getMessage());}};repository.listenRelationships(uid,relationshipListener);
    }

    private void addRequestCard(RelationshipRequest request){MaterialCardView card=card();LinearLayout content=content();TextView title=title("HealthMate contact");TextView subtitle=body("Requested to be added as "+pretty(request.getRelationshipType())+".");content.addView(title);content.addView(subtitle);LinearLayout actions=actions();MaterialButton accept=button("Accept",true),reject=button("Reject",false);actions.addView(accept,weighted());actions.addView(reject,weighted());content.addView(actions);card.addView(content);requestsContainer.addView(card,cardParams());loadName(request.getRequesterUid(),title,null);accept.setOnClickListener(v->repository.acceptRequest(request,callback("Relationship accepted.")));reject.setOnClickListener(v->repository.rejectRequest(request,callback("Request rejected.")));}

    private void addContactCard(String contactUid,Relationship relationship){MaterialCardView card=card();LinearLayout content=content();LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);header.setGravity(android.view.Gravity.CENTER_VERTICAL);ImageView avatar=new ImageView(this);avatar.setImageResource(R.drawable.ic_person);avatar.setBackgroundResource(R.drawable.bg_chat_avatar);avatar.setPadding(dp(12),dp(12),dp(12),dp(12));header.addView(avatar,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setPadding(dp(12),0,0,0);TextView name=title("HealthMate contact");TextView type=body(pretty(relationship.getRelationshipType()));text.addView(name);text.addView(type);header.addView(text,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f));content.addView(header);loadName(contactUid,name,avatar);
        if(RelationshipPolicy.FRIEND.equals(RelationshipPolicy.normalize(relationship.getRelationshipType()))){SwitchMaterial grant=new SwitchMaterial(this);grant.setText("Allow this friend to view my location");grant.setChecked(relationship.isExplicitLocationGrant());grant.setPadding(0,dp(12),0,dp(6));final boolean[] internalChange={false};grant.setOnCheckedChangeListener((button,checked)->{if(internalChange[0])return;sharingRepository.setFriendGrant(contactUid,checked,new LocationSharingRepository.Callback(){@Override public void onSuccess(){LocationSharingService.refresh(RelationshipRequestsActivity.this);}@Override public void onError(String message){internalChange[0]=true;button.setChecked(!checked);internalChange[0]=false;show(message);}});});content.addView(grant);}else{TextView familyInfo=body("Family location follows the switch in Profile and is forced on during an active SOS.");familyInfo.setPadding(0,dp(12),0,dp(6));content.addView(familyInfo);}
        LinearLayout actions=actions();MaterialButton message=button("Message",true),call=button("Call",false),map=button("Map",false);actions.addView(message,weighted());actions.addView(call,weighted());actions.addView(map,weighted());content.addView(actions);MaterialButton remove=button("Remove contact",false);remove.setTextColor(getColor(R.color.hm_danger));content.addView(remove,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(44)));card.addView(content);contactsContainer.addView(card,cardParams());message.setOnClickListener(v->{Intent i=new Intent(this,ChatActivity.class);i.putExtra("receiverId",contactUid);startActivity(i);});call.setOnClickListener(v->{Intent i=new Intent(this,CallActivity.class);i.putExtra("receiverId",contactUid);i.putExtra("callType","audio");startActivity(i);});map.setOnClickListener(v->startActivity(new Intent(this,FamilyTrackingMapActivity.class)));remove.setOnClickListener(v->repository.remove(contactUid,callback("Contact removed.")));}

    private void loadName(String contactUid,TextView target,ImageView avatar){FirebaseDatabase.getInstance().getReference("publicProfiles").child(contactUid).get().addOnSuccessListener(snapshot->{String value=snapshot.child("fullName").getValue(String.class);if(value!=null&&!value.trim().isEmpty())target.setText(value.trim());if(avatar!=null){Bitmap bitmap=Base64Manager.base64ToBitmap(snapshot.child("profileImage").getValue(String.class));if(bitmap!=null){avatar.setPadding(0,0,0,0);avatar.setImageBitmap(bitmap);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);}}});}
    private RelationshipRepository.Callback callback(String success){return new RelationshipRepository.Callback(){@Override public void onSuccess(){show(success);}@Override public void onError(String message){show(message);}};}
    private MaterialCardView card(){MaterialCardView card=new MaterialCardView(this);card.setRadius(dp(22));card.setCardBackgroundColor(getColor(R.color.hm_surface));card.setStrokeColor(getColor(R.color.hm_border));card.setStrokeWidth(dp(1));card.setCardElevation(0);return card;}
    private LinearLayout content(){LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(dp(18),dp(16),dp(18),dp(16));return layout;}
    private LinearLayout actions(){LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.HORIZONTAL);layout.setPadding(0,dp(14),0,dp(8));return layout;}
    private TextView title(String value){TextView view=new TextView(this);view.setText(value);view.setTextSize(16);view.setTextColor(getColor(R.color.hm_text_primary));view.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return view;}
    private TextView body(String value){TextView view=new TextView(this);view.setText(value);view.setTextSize(13);view.setTextColor(getColor(R.color.hm_text_secondary));view.setPadding(0,dp(4),0,0);return view;}
    private MaterialButton button(String value,boolean primary){MaterialButton button=new MaterialButton(this);button.setText(value);button.setAllCaps(false);if(primary)button.setBackgroundTintList(getColorStateList(R.color.hm_primary));return button;}
    private LinearLayout.LayoutParams weighted(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1f);p.setMargins(0,0,dp(6),0);return p;}
    private LinearLayout.LayoutParams cardParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);p.setMargins(0,0,0,dp(12));return p;}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private String pretty(String value){String safe=RelationshipPolicy.normalize(value).toLowerCase();return safe.isEmpty()?"contact":Character.toUpperCase(safe.charAt(0))+safe.substring(1);}
    private void show(String message){Toast.makeText(this,message==null?"Unable to update relationships.":message,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){repository.stopIncoming(uid,requestListener);repository.stopRelationships(uid,relationshipListener);super.onDestroy();}
}
