package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import com.example.app.contacts.ContactQrPayloadCodec;
import com.google.firebase.auth.FirebaseAuth;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class QRScannerActivity extends AppCompatActivity {
    private final ActivityResultLauncher<ScanOptions> scanner=registerForActivityResult(new ScanContract(),result->process(result.getContents()));
    @Override protected void onCreate(Bundle state){super.onCreate(state);if(FirebaseAuth.getInstance().getUid()==null){startActivity(new Intent(this,LoginActivity.class));finish();return;}ScanOptions options=new ScanOptions();options.setPrompt("Scan a HealthMate profile QR");options.setBeepEnabled(true);options.setOrientationLocked(false);scanner.launch(options);}
    private void process(String raw){if(raw==null){finish();return;}try{ContactQrPayloadCodec.Payload payload=ContactQrPayloadCodec.decode(raw);Intent intent=new Intent(this,RelationshipChoiceActivity.class);intent.putExtra("targetUid",payload.getUid());intent.putExtra("contactToken",payload.getToken());startActivity(intent);finish();}catch(IllegalArgumentException error){Toast.makeText(this,error.getMessage(),Toast.LENGTH_LONG).show();finish();}}
}
