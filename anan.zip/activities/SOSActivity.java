package com.example.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.models.EmergencyIncident;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.models.User;
import com.example.app.repositories.EmergencyIncidentRepository;
import com.example.app.services.EmergencyLiveLocationService;
import com.example.app.utils.LocationHelper;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

/** Patient SOS screen with a five-second cancellation window. */
public class SOSActivity extends AppCompatActivity {
    private static final String STATE_REQUEST_ID = "sos_request_id";
    private static final String STATE_SENT = "sos_sent";
    private static final int COUNTDOWN_SECONDS = 5;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final EmergencyIncidentRepository incidentRepository = new EmergencyIncidentRepository();
    private MaterialButton sosButton;
    private TextView emergencyStatus;
    private TextView locationStatus;
    private String uid;
    private String requestId;
    private boolean sending;
    private boolean sent;
    private boolean countdownActive;
    private int remainingSeconds;

    private final ActivityResultLauncher<String[]> locationPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean granted = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION))
                        || Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                if (granted) startCountdown();
                else updateError("Location permission is required to create an SOS incident.");
            }
    );

    private final Runnable countdownTick = new Runnable() {
        @Override public void run() {
            if (!countdownActive) return;
            if (remainingSeconds <= 0) {
                countdownActive = false;
                sosButton.setText(R.string.sending_alert);
                acquireLocation();
                return;
            }
            emergencyStatus.setText("SOS will be sent in " + remainingSeconds + " seconds. Tap the button to cancel.");
            sosButton.setText("Cancel SOS (" + remainingSeconds + ")");
            remainingSeconds--;
            handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_sos);
        if (getIntent().getBooleanExtra(MainActivity.EXTRA_OFFLINE_SESSION, false)) {
            Toast.makeText(this, "Reconnect before starting a new SOS incident.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        if (!HealthMateApplication.isFirebaseReady()) { Toast.makeText(this, R.string.home_firebase_missing_message, Toast.LENGTH_LONG).show(); finish(); return; }
        uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { redirectLogin(); return; }
        requestId = state == null ? UUID.randomUUID().toString() : state.getString(STATE_REQUEST_ID, UUID.randomUUID().toString());
        sent = state != null && state.getBoolean(STATE_SENT, false);
        sosButton = findViewById(R.id.sosButton);
        emergencyStatus = findViewById(R.id.emergencyStatus);
        locationStatus = findViewById(R.id.locationStatus);
        sosButton.setOnClickListener(v -> {
            if (sent) {
                openActiveEmergencyMap();
                return;
            }
            if (sending) return;
            if (countdownActive) cancelCountdown(); else verifyPermission();
        });
        if (sent) showSentState();
    }

    private void verifyPermission() {
        boolean fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (fine || coarse) startCountdown();
        else locationPermissionLauncher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
    }

    private void startCountdown() {
        if (sending || sent || countdownActive) return;
        countdownActive = true;
        remainingSeconds = COUNTDOWN_SECONDS;
        handler.removeCallbacks(countdownTick);
        handler.post(countdownTick);
    }

    private void cancelCountdown() {
        countdownActive = false;
        handler.removeCallbacks(countdownTick);
        emergencyStatus.setText("SOS cancelled before transmission.");
        sosButton.setText(R.string.send_sos);
        Toast.makeText(this, "SOS cancelled.", Toast.LENGTH_SHORT).show();
    }

    private void acquireLocation() {
        sending = true;
        sosButton.setEnabled(false);
        emergencyStatus.setText("Getting your current location…");
        new LocationHelper(this).getCurrentLocation(new LocationHelper.LocationResultCallback() {
            @Override public void onLocation(Location location) {
                locationStatus.setText(R.string.location_ready);
                loadProfile(location);
            }
            @Override public void onError(String message) { updateError(message); }
        });
    }

    private void loadProfile(Location location) {
        FirebaseDatabase.getInstance().getReference("users").child(uid).get().addOnSuccessListener(snapshot -> {
            User user = snapshot.getValue(User.class);
            if (user == null) { updateError("Your active HealthMate user profile was not found."); return; }
            user.setUid(uid);
            String barangayId = safe(user.getAssignedBarangayId());
            if (barangayId.isEmpty()) {
                barangayId = "UNASSIGNED";
                user.setAssignedBarangayId(barangayId);
            }
            if ("UNASSIGNED".equalsIgnoreCase(barangayId)) {
                createIncident(user, "Unassigned barangay", location);
                return;
            }
            FirebaseDatabase.getInstance().getReference("barangays").child(barangayId).child("name").get().addOnCompleteListener(task -> {
                String barangayName = task.isSuccessful() ? task.getResult().getValue(String.class) : "";
                createIncident(user, barangayName, location);
            });
        }).addOnFailureListener(error -> updateError(message(error.getMessage(), "Unable to load your user profile.")));
    }

    private void createIncident(User user, String barangayName, Location location) {
        EmergencyIncident incident = EmergencyIncident.createSos(requestId, user, barangayName);
        EmergencyLocationPoint point = new EmergencyLocationPoint(
                location.getLatitude(), location.getLongitude(),
                location.hasAccuracy() ? location.getAccuracy() : 0f,
                System.currentTimeMillis()
        );
        emergencyStatus.setText(R.string.sending_alert);
        incidentRepository.createIncident(incident, point, new EmergencyIncidentRepository.Callback() {
            @Override public void onSuccess(String incidentId) {
                activateIncident(
                        incidentId,
                        "SOS delivered to administrators, active respondents, and accepted family/friends."
                );
            }

            @Override public void onWarning(String incidentId, String message) {
                activateIncident(
                        incidentId,
                        message(message, "The SOS is active, but some phone notifications could not be confirmed. Authorized contacts can still open the live emergency map.")
                );
            }

            @Override public void onError(String message) { updateError(message); }
        });
    }

    private void startPatientTracking(String incidentId) {
        Intent service = new Intent(this, EmergencyLiveLocationService.class)
                .setAction(EmergencyLiveLocationService.ACTION_START_PATIENT)
                .putExtra(EmergencyLiveLocationService.EXTRA_INCIDENT_ID, incidentId);
        ContextCompat.startForegroundService(this, service);
    }

    private void activateIncident(String incidentId, String toastMessage) {
        sent = true;
        sending = false;
        requestId = incidentId;
        showSentState();
        startPatientTracking(incidentId);
        Toast.makeText(
                SOSActivity.this,
                toastMessage,
                Toast.LENGTH_LONG
        ).show();
    }

    private void showSentState() {
        emergencyStatus.setText(R.string.sos_active_status);
        locationStatus.setText(R.string.sos_active_location_sharing);
        sosButton.setText(R.string.sos_open_live_map);
        sosButton.setEnabled(true);
    }

    private void openActiveEmergencyMap() {
        if (safe(requestId).isEmpty()) {
            return;
        }
        Intent intent = new Intent(this, EmergencyMapActivity.class)
                .putExtra(EmergencyMapActivity.EXTRA_INCIDENT_ID, requestId)
                .putExtra(EmergencyMapActivity.EXTRA_PATIENT_MODE, true);
        startActivity(intent);
    }

    private void updateError(String value) {
        sending = false; countdownActive = false; handler.removeCallbacks(countdownTick);
        String readable = message(value, "Unable to create the SOS incident.");
        emergencyStatus.setText(readable); sosButton.setText(R.string.send_sos); sosButton.setEnabled(true);
        Toast.makeText(this, readable, Toast.LENGTH_LONG).show();
    }

    private void redirectLogin() { startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK)); finish(); }
    private String safe(String value) { return value == null ? "" : value.trim(); }
    private String message(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value.trim(); }
    @Override protected void onSaveInstanceState(Bundle out) { out.putString(STATE_REQUEST_ID, requestId); out.putBoolean(STATE_SENT, sent); super.onSaveInstanceState(out); }
    @Override protected void onDestroy() { handler.removeCallbacks(countdownTick); super.onDestroy(); }
}
