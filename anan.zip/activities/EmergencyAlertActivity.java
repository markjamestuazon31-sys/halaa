package com.example.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.models.User;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class EmergencyAlertActivity extends AppCompatActivity {

    private String userId;
    private String phoneNumber;
    private TextView alertText;
    private MaterialButton callButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_alert);

        userId = getIntent().getStringExtra("userId");
        alertText = findViewById(R.id.alertText);
        MaterialButton mapButton = findViewById(R.id.openMap);
        MaterialButton helpButton = findViewById(R.id.helpButton);
        callButton = findViewById(R.id.callButton);

        if (userId == null || userId.trim().isEmpty()) {
            alertText.setText("The emergency contact could not be identified.");
            mapButton.setEnabled(false);
            helpButton.setEnabled(false);
            callButton.setEnabled(false);
            return;
        }

        loadEmergencyUser();
        mapButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, FamilyTrackingMapActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        });
        helpButton.setOnClickListener(view -> sendHelpingStatus());
        callButton.setOnClickListener(view -> callUser());
    }

    private void loadEmergencyUser() {
        FirebaseDatabase.getInstance().getReference("users").child(userId).get()
                .addOnSuccessListener(snapshot -> {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        String name = user.getFullName() == null ? "A HealthMate contact" : user.getFullName();
                        phoneNumber = user.getPhone();
                        alertText.setText(name + " needs emergency assistance.");
                        callButton.setEnabled(phoneNumber != null && !phoneNumber.trim().isEmpty());
                    }
                });
    }

    private void sendHelpingStatus() {
        String helperId = FirebaseAuth.getInstance().getUid();
        if (helperId == null) return;
        Map<String, Object> response = new HashMap<>();
        response.put("helperId", helperId);
        response.put("status", "helping");
        response.put("updatedAt", System.currentTimeMillis());
        FirebaseDatabase.getInstance().getReference("emergencyResponses")
                .child(userId)
                .child(helperId)
                .setValue(response)
                .addOnSuccessListener(unused -> Toast.makeText(this, "The contact has been told that you are helping.", Toast.LENGTH_LONG).show())
                .addOnFailureListener(error -> Toast.makeText(this, "Unable to update the response status.", Toast.LENGTH_LONG).show());
    }

    private void callUser() {
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) return;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phoneNumber))));
    }
}
