package com.example.app.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.example.app.R;
import com.example.app.contacts.ContactQrPayloadCodec;
import com.example.app.repositories.AuthRepository;
import com.example.app.repositories.ContactQrRepository;
import com.example.app.repositories.LocationSharingRepository;
import com.example.app.services.HealthMateRealtimeService;
import com.example.app.services.LocationSharingService;
import com.example.app.utils.Base64Manager;
import com.example.app.utils.MedicationAlarmScheduler;
import com.example.app.utils.QRManager;
import com.example.app.viewmodels.UserViewModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {
    private final ContactQrRepository qrRepository=new ContactQrRepository();
    private final LocationSharingRepository sharingRepository=new LocationSharingRepository();
    private ImageView profileImage,qrImage;private TextView name,email,phone,status,relationshipSummary;private SwitchMaterial familySwitch;
    private Bitmap currentQr;private String uid;private ValueEventListener preferenceListener;private boolean renderingPreference;
    private final ActivityResultLauncher<String> locationPermission=registerForActivityResult(new ActivityResultContracts.RequestPermission(),granted->{if(granted)saveFamilySharing(true);else{renderingPreference=true;familySwitch.setChecked(false);renderingPreference=false;Toast.makeText(this,"Location permission is required before family sharing can be enabled.",Toast.LENGTH_LONG).show();}});

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);setContentView(R.layout.activity_profile);uid=FirebaseAuth.getInstance().getUid();if(uid==null){startActivity(new Intent(this,LoginActivity.class));finish();return;}
        profileImage=findViewById(R.id.profileImage);qrImage=findViewById(R.id.profileQrImage);name=findViewById(R.id.name);email=findViewById(R.id.email);phone=findViewById(R.id.phone);status=findViewById(R.id.status);relationshipSummary=findViewById(R.id.relationshipSummary);familySwitch=findViewById(R.id.familySharingSwitch);
        MaterialButton logout=findViewById(R.id.logoutButton),scan=findViewById(R.id.scanContactButton),show=findViewById(R.id.showQrButton),rotate=findViewById(R.id.rotateQrButton),relationships=findViewById(R.id.openRelationshipRequests);
        UserViewModel viewModel=new ViewModelProvider(this).get(UserViewModel.class);viewModel.user.observe(this,user->{if(user==null)return;name.setText(safe(user.getFullName(),"HealthMate user"));email.setText(safe(user.getEmail(),"No email"));phone.setText(safe(user.getPhone(),"No phone number"));status.setText(safe(user.getStatus(),"active"));Bitmap bitmap=Base64Manager.base64ToBitmap(user.getProfileImage());if(bitmap!=null)profileImage.setImageBitmap(bitmap);user.setUid(uid);qrRepository.syncPublicProfile(user);});viewModel.loadUser();
        loadQr(false);scan.setOnClickListener(v->startActivity(new Intent(this,QRScannerActivity.class)));show.setOnClickListener(v->showFullQr());rotate.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Refresh contact QR?").setMessage("The previous QR will stop working. Existing family and friend relationships are not removed.").setNegativeButton("Cancel",null).setPositiveButton("Refresh",(d,w)->loadQr(true)).show());relationships.setOnClickListener(v->startActivity(new Intent(this,RelationshipRequestsActivity.class)));
        familySwitch.setOnCheckedChangeListener((button,checked)->{if(renderingPreference)return;if(checked&&!hasLocationPermission()){locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION);return;}saveFamilySharing(checked);});listenPreferences();
        logout.setOnClickListener(v->{MedicationAlarmScheduler.cancelAllStoredReminders(this);HealthMateRealtimeService.stop(this);LocationSharingService.stop(this);new AuthRepository().logout();Intent intent=new Intent(this,LoginActivity.class);intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(intent);});
    }

    private void loadQr(boolean rotate){ContactQrRepository.Callback callback=new ContactQrRepository.Callback(){@Override public void onReady(String token,com.example.app.models.ContactPublicProfile profile){currentQr=QRManager.generateQR(ContactQrPayloadCodec.encode(uid,token));if(currentQr!=null)qrImage.setImageBitmap(currentQr);else Toast.makeText(ProfileActivity.this,"Unable to generate the QR image.",Toast.LENGTH_LONG).show();}@Override public void onError(String message){Toast.makeText(ProfileActivity.this,message,Toast.LENGTH_LONG).show();}};if(rotate)qrRepository.rotateCurrentToken(callback);else qrRepository.ensureCurrentToken(callback);}
    private void showFullQr(){if(currentQr==null){Toast.makeText(this,"Your QR is still loading.",Toast.LENGTH_SHORT).show();return;}ImageView image=new ImageView(this);image.setImageBitmap(currentQr);int padding=(int)(24*getResources().getDisplayMetrics().density);image.setPadding(padding,padding,padding,padding);image.setAdjustViewBounds(true);new AlertDialog.Builder(this).setTitle("My HealthMate contact QR").setMessage("The scanner chooses Add as Family or Add as Friend after validating this QR.").setView(image).setPositiveButton("Close",null).show();}
    private void listenPreferences(){preferenceListener=new ValueEventListener(){@Override public void onDataChange(DataSnapshot snapshot){boolean enabled=Boolean.TRUE.equals(snapshot.child("familySharingEnabled").getValue(Boolean.class));boolean sos=Boolean.TRUE.equals(snapshot.child("sosActive").getValue(Boolean.class));renderingPreference=true;familySwitch.setChecked(enabled);renderingPreference=false;relationshipSummary.setText(sos?"Active SOS is temporarily sharing your location with accepted family contacts.":enabled?"Accepted family contacts can view your live location.":"Family location sharing is off outside an active SOS.");}@Override public void onCancelled(DatabaseError error){relationshipSummary.setText("Location preference is temporarily unavailable.");}};sharingRepository.listenPreferences(uid,preferenceListener);}
    private void saveFamilySharing(boolean enabled){sharingRepository.setFamilySharing(enabled,new LocationSharingRepository.Callback(){@Override public void onSuccess(){LocationSharingService.refresh(ProfileActivity.this);Toast.makeText(ProfileActivity.this,enabled?"Family location sharing enabled.":"Family location sharing disabled.",Toast.LENGTH_SHORT).show();}@Override public void onError(String message){renderingPreference=true;familySwitch.setChecked(!enabled);renderingPreference=false;Toast.makeText(ProfileActivity.this,message,Toast.LENGTH_LONG).show();}});}
    private boolean hasLocationPermission(){return ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private String safe(String value,String fallback){return value==null||value.trim().isEmpty()?fallback:value.trim();}
    @Override protected void onDestroy(){if(preferenceListener!=null)sharingRepository.stopPreferences(uid,preferenceListener);super.onDestroy();}
}
