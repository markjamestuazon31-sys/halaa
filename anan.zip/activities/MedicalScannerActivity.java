package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.models.MedicalProfile;
import com.example.app.models.MedicalQR;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MedicalScannerActivity extends AppCompatActivity {

    public static final String MEDICAL_QR_PREFIX = "healthmate:medical:";

    private final ActivityResultLauncher<ScanOptions> scanner = registerForActivityResult(
            new ScanContract(),
            result -> processResult(result.getContents())
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        ScanOptions options = new ScanOptions();
        options.setPrompt("Scan a HealthMate emergency medical QR code");
        options.setBeepEnabled(true);
        options.setOrientationLocked(false);
        scanner.launch(options);
    }

    private void processResult(String rawValue) {
        if (rawValue == null) {
            Toast.makeText(this, "Scan cancelled.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        if (!rawValue.startsWith(MEDICAL_QR_PREFIX)) {
            showError("This is not a HealthMate medical QR code.");
            return;
        }
        String token = rawValue.substring(MEDICAL_QR_PREFIX.length()).trim();
        if (token.isEmpty()) {
            showError("The medical QR token is empty.");
            return;
        }
        lookupToken(token);
    }

    private void lookupToken(String token) {
        FirebaseDatabase.getInstance().getReference("medicalQR")
                .orderByChild("medicalToken")
                .equalTo(token)
                .limitToFirst(1)
                .get()
                .addOnSuccessListener(snapshot -> {
                    DataSnapshot match = null;
                    for (DataSnapshot child : snapshot.getChildren()) {
                        match = child;
                        break;
                    }
                    if (match == null) {
                        showError("This medical QR code is invalid or has been replaced.");
                        return;
                    }
                    MedicalQR qr = match.getValue(MedicalQR.class);
                    String userId = match.getKey();
                    if (qr == null || !qr.isQrEnabled() || userId == null) {
                        showError("This medical QR code is disabled.");
                        return;
                    }
                    loadMedicalProfile(userId);
                })
                .addOnFailureListener(error -> showError("Unable to verify the medical QR code."));
    }

    private void loadMedicalProfile(String userId) {
        FirebaseDatabase.getInstance().getReference("medicalProfiles").child(userId).get()
                .addOnSuccessListener(snapshot -> {
                    MedicalProfile profile = snapshot.getValue(MedicalProfile.class);
                    if (profile == null) {
                        showError("No medical profile is linked to this QR code.");
                        return;
                    }
                    showProfile(profile);
                })
                .addOnFailureListener(error -> showError("Unable to load the medical profile."));
    }

    private void showProfile(MedicalProfile profile) {
        String details = "Blood type: " + safe(profile.getBloodType())
                + "\n\nAllergies: " + safe(profile.getAllergies())
                + "\n\nMedical conditions: " + safe(profile.getMedicalConditions())
                + "\n\nCurrent medications: " + safe(profile.getMedications())
                + "\n\nEmergency note: " + safe(profile.getEmergencyNote())
                + "\n\nDoctor/clinic: " + safe(profile.getDoctorName())
                + "\nDoctor/clinic phone: " + safe(profile.getDoctorPhone());

        new MaterialAlertDialogBuilder(this)
                .setTitle("Emergency medical profile")
                .setMessage(details)
                .setPositiveButton("Close", (dialog, which) -> finish())
                .setOnCancelListener(dialog -> finish())
                .show();
    }

    private String safe(String value) {
        return value == null || value.trim().isEmpty() ? "Not provided" : value.trim();
    }

    private void showError(String message) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Medical QR unavailable")
                .setMessage(message)
                .setPositiveButton("Close", (dialog, which) -> finish())
                .setOnCancelListener(dialog -> finish())
                .show();
    }
}
