package com.example.app.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app.R;
import com.example.app.adapters.MessageAdapter;
import com.example.app.models.Message;
import com.example.app.repositories.ConversationRepository;
import com.example.app.repositories.MessageRepository;
import com.example.app.repositories.PresenceRepository;
import com.example.app.utils.Base64Manager;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity implements MessageAdapter.Listener{
    private final ArrayList<Message> messages=new ArrayList<>();private final ConversationRepository conversations=new ConversationRepository();private final MessageRepository messagesRepository=new MessageRepository();private final PresenceRepository presence=new PresenceRepository();
    private RecyclerView recycler;private LinearLayoutManager layoutManager;private EditText messageBox;private MaterialButton send;private MessageAdapter adapter;private TextView title,presenceText,replyPreview;private View replyContainer;private ImageView avatar;private String currentUid,receiverUid,conversationId,replyToMessageId;private ValueEventListener messageListener,presenceListener;private DatabaseReference presenceRef;
    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_chat);currentUid=FirebaseAuth.getInstance().getUid();if(currentUid==null){startActivity(new Intent(this,LoginActivity.class));finish();return;}receiverUid=getIntent().getStringExtra("receiverId");conversationId=getIntent().getStringExtra("conversationId");bind();if(blank(receiverUid)&&!blank(conversationId)){FirebaseDatabase.getInstance().getReference("userConversations").child(currentUid).child(conversationId).child("otherParticipantUid").get().addOnSuccessListener(s->{receiverUid=s.getValue(String.class);open();});}else open();}
    private void bind(){title=findViewById(R.id.chatTitle);presenceText=findViewById(R.id.chatPresence);avatar=findViewById(R.id.chatAvatar);recycler=findViewById(R.id.messagesRecycler);messageBox=findViewById(R.id.messageBox);send=findViewById(R.id.sendBtn);replyPreview=findViewById(R.id.replyPreview);replyContainer=findViewById(R.id.replyPreviewContainer);replyContainer.setVisibility(View.GONE);layoutManager=new LinearLayoutManager(this);layoutManager.setStackFromEnd(true);adapter=new MessageAdapter(messages,currentUid,this);recycler.setLayoutManager(layoutManager);recycler.setAdapter(adapter);findViewById(R.id.chatBack).setOnClickListener(v->finish());findViewById(R.id.replyCancel).setOnClickListener(v->clearReply());send.setOnClickListener(v->send());findViewById(R.id.voiceCall).setOnClickListener(v->openCall("audio"));findViewById(R.id.videoCall).setOnClickListener(v->openCall("video"));}
    private void open(){if(blank(receiverUid)){disable("Select an accepted contact to start messaging.");return;}loadContactHeader();messageBox.setEnabled(false);send.setEnabled(false);conversations.ensureConversation(currentUid,receiverUid,new ConversationRepository.Callback(){@Override public void onReady(String id){conversationId=id;messageBox.setEnabled(true);send.setEnabled(true);presence.setActiveConversation(currentUid,conversationId);listenMessages();conversations.markRead(currentUid,conversationId);}@Override public void onError(String message){disable(message);}});}
    private void loadContactHeader(){FirebaseDatabase.getInstance().getReference("publicProfiles").child(receiverUid).get().addOnSuccessListener(s->{String name=s.child("fullName").getValue(String.class);title.setText(blank(name)?"HealthMate contact":name);Bitmap bitmap=Base64Manager.base64ToBitmap(s.child("profileImage").getValue(String.class));if(bitmap!=null){avatar.setPadding(0,0,0,0);avatar.setImageBitmap(bitmap);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);}});presenceRef=FirebaseDatabase.getInstance().getReference("userPresence").child(receiverUid);presenceListener=presenceRef.addValueEventListener(new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot s){String state=s.child("state").getValue(String.class);Long last=s.child("lastSeenAt").getValue(Long.class);if("ONLINE".equals(state))presenceText.setText("Online");else if(last!=null&&last>0)presenceText.setText("Last seen "+DateUtils.getRelativeTimeSpanString(last,System.currentTimeMillis(),DateUtils.MINUTE_IN_MILLIS,DateUtils.FORMAT_ABBREV_RELATIVE));else presenceText.setText("Secure HealthMate conversation");}@Override public void onCancelled(@NonNull DatabaseError e){presenceText.setText("Secure HealthMate conversation");}});}
    private void listenMessages(){if(messageListener!=null)return;messageListener=new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot snapshot){boolean atBottom=messages.isEmpty()||layoutManager.findLastVisibleItemPosition()>=messages.size()-2;messages.clear();for(DataSnapshot child:snapshot.getChildren()){Message message=child.getValue(Message.class);if(message==null)continue;message.setMessageId(child.getKey());messages.add(message);messagesRepository.markDeliveredAndSeen(conversationId,message,currentUid,true);}adapter.notifyDataSetChanged();conversations.markRead(currentUid,conversationId);if(atBottom&&!messages.isEmpty())recycler.scrollToPosition(messages.size()-1);}@Override public void onCancelled(@NonNull DatabaseError error){show(error.getMessage());}};messagesRepository.listenMessages(conversationId,messageListener);}
    private void send(){String text=messageBox.getText().toString().trim();if(text.isEmpty())return;send.setEnabled(false);messagesRepository.sendText(conversationId,currentUid,receiverUid,text,replyToMessageId,new MessageRepository.MessageCallback(){@Override public void onSuccess(){messageBox.setText("");clearReply();send.setEnabled(true);}@Override public void onError(String message){send.setEnabled(true);show(message);}});}
    @Override public void onReply(Message message){replyToMessageId=message.getMessageId();replyContainer.setVisibility(View.VISIBLE);replyPreview.setVisibility(View.VISIBLE);replyPreview.setText("Replying to: "+preview(message.getText()));messageBox.requestFocus();}
    private void clearReply(){replyToMessageId=null;replyPreview.setVisibility(View.GONE);replyContainer.setVisibility(View.GONE);}
    private void openCall(String type){if(blank(receiverUid))return;Intent intent=new Intent(this,CallActivity.class);intent.putExtra("receiverId",receiverUid);intent.putExtra("callType",type);startActivity(intent);}
    private void disable(String message){title.setText("Conversation unavailable");presenceText.setText(message);messageBox.setEnabled(false);send.setEnabled(false);show(message);}
    private String preview(String value){if(blank(value))return"message";String v=value.trim();return v.length()<=70?v:v.substring(0,67)+"…";}
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
    private void show(String message){Toast.makeText(this,blank(message)?"Unable to update the conversation.":message,Toast.LENGTH_LONG).show();}
    @Override protected void onStart(){super.onStart();if(!blank(conversationId)){presence.setActiveConversation(currentUid,conversationId);conversations.markRead(currentUid,conversationId);}}
    @Override protected void onStop(){presence.setActiveConversation(currentUid,"");super.onStop();}
    @Override protected void onDestroy(){if(messageListener!=null&&!blank(conversationId))messagesRepository.stopListening(conversationId,messageListener);if(presenceRef!=null&&presenceListener!=null)presenceRef.removeEventListener(presenceListener);super.onDestroy();}
}
