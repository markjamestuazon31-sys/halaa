package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.models.MedicalProfile;
import com.example.app.repositories.MedicalRepository;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class MedicalProfileActivity
        extends AppCompatActivity {

    private EditText bloodType;
    private EditText allergies;
    private EditText conditions;
    private EditText medications;
    private EditText emergencyNote;
    private EditText doctorName;
    private EditText doctorPhone;
    private MaterialButton saveButton;
    private MedicalProfile loadedProfile;

    private MedicalRepository repository;
    private String userId;

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);
        setContentView(
                R.layout.activity_medical_profile
        );

        FirebaseUser currentUser =
                FirebaseAuth.getInstance()
                        .getCurrentUser();
        if (currentUser == null) {
            startActivity(
                    new Intent(
                            this,
                            LoginActivity.class
                    )
            );
            finish();
            return;
        }
        userId = currentUser.getUid();

        repository = new MedicalRepository();
        bindViews();
        loadProfile();
        saveButton.setOnClickListener(
                view -> saveMedicalProfile()
        );
        findViewById(
                R.id.manageMedicationReminders
        ).setOnClickListener(
                view -> startActivity(
                        new Intent(
                                this,
                                MedicationActivity.class
                        )
                )
        );
    }

    private void bindViews() {
        bloodType = findViewById(R.id.bloodType);
        allergies = findViewById(R.id.allergies);
        conditions = findViewById(R.id.conditions);
        medications = findViewById(R.id.medications);
        emergencyNote =
                findViewById(R.id.emergencyNote);
        doctorName = findViewById(R.id.doctorName);
        doctorPhone =
                findViewById(R.id.doctorPhone);
        saveButton = findViewById(R.id.saveMedical);
    }

    private void loadProfile() {
        repository.getProfile(userId)
                .addListenerForSingleValueEvent(
                        new ValueEventListener() {
                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot
                            ) {
                                loadedProfile =
                                        snapshot.getValue(
                                                MedicalProfile.class
                                        );
                                if (loadedProfile == null) {
                                    return;
                                }
                                bloodType.setText(
                                        loadedProfile.getBloodType()
                                );
                                allergies.setText(
                                        loadedProfile.getAllergies()
                                );
                                conditions.setText(
                                        loadedProfile
                                                .getMedicalConditions()
                                );
                                medications.setText(
                                        loadedProfile.getMedications()
                                );
                                emergencyNote.setText(
                                        loadedProfile
                                                .getEmergencyNote()
                                );
                                doctorName.setText(
                                        loadedProfile.getDoctorName()
                                );
                                doctorPhone.setText(
                                        loadedProfile.getDoctorPhone()
                                );
                            }

                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error
                            ) {
                                Toast.makeText(
                                        MedicalProfileActivity.this,
                                        "Unable to load "
                                                + "your medical profile.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                );
    }

    private void saveMedicalProfile() {
        String bloodTypeValue =
                valueOf(bloodType);
        if (bloodTypeValue.isEmpty()) {
            bloodType.setError(
                    "Blood type is required"
            );
            bloodType.requestFocus();
            return;
        }

        String existingFullName =
                loadedProfile == null
                        ? ""
                        : safe(
                        loadedProfile.getFullName()
                );
        String existingBirthDate =
                loadedProfile == null
                        ? ""
                        : safe(
                        loadedProfile.getBirthDate()
                );

        MedicalProfile profile =
                new MedicalProfile(
                        existingFullName,
                        existingBirthDate,
                        bloodTypeValue,
                        valueOf(allergies),
                        valueOf(conditions),
                        valueOf(medications),
                        valueOf(emergencyNote),
                        valueOf(doctorName),
                        valueOf(doctorPhone)
                );

        setSaving(true);
        repository.saveProfile(userId, profile)
                .addOnCompleteListener(task -> {
                    setSaving(false);
                    if (task.isSuccessful()) {
                        loadedProfile = profile;
                        Toast.makeText(
                                this,
                                "Medical profile saved.",
                                Toast.LENGTH_SHORT
                        ).show();
                    } else {
                        Toast.makeText(
                                this,
                                "Unable to save "
                                        + "the medical profile.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }

    private void setSaving(boolean saving) {
        saveButton.setEnabled(!saving);
        saveButton.setText(
                saving
                        ? "Saving…"
                        : "Save medical profile"
        );
    }

    private static String valueOf(EditText field) {
        return field.getText() == null
                ? ""
                : field.getText()
                .toString()
                .trim();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
