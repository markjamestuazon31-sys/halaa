package com.example.app.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.adapters.MedicationAdapter;
import com.example.app.models.Medication;
import com.example.app.repositories.MedicationRepository;
import com.example.app.utils.MedicationAlarmScheduler;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

public class MedicationActivity
        extends AppCompatActivity
        implements MedicationAdapter.Listener {

    private final List<Medication> medications =
            new ArrayList<>();

    private EditText medicineName;
    private EditText dosage;
    private EditText schedule;
    private EditText frequency;
    private MaterialSwitch reminderEnabled;
    private MaterialButton saveButton;
    private MaterialButton cancelEditButton;
    private TextView sectionTitle;
    private TextView emptyState;

    private MedicationRepository repository;
    private MedicationAdapter adapter;
    private DatabaseReference medicationReference;
    private Query medicationQuery;
    private ValueEventListener medicationListener;
    private String userId;
    private String editingMedicationId;
    private long editingCreatedAt;
    private int selectedHour = -1;
    private int selectedMinute = -1;
    private boolean retrySaveAfterNotificationPermission;

    private final ActivityResultLauncher<String>
            notificationPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            granted -> {
                boolean retry = retrySaveAfterNotificationPermission;
                retrySaveAfterNotificationPermission = false;
                if (granted && retry) {
                    saveMedication();
                    return;
                }
                if (!granted && retry) {
                    Toast.makeText(
                            this,
                            "Allow notifications to receive medication alarms.",
                            Toast.LENGTH_LONG
                    ).show();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medication);

        FirebaseUser currentUser =
                FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(
                    new Intent(this, LoginActivity.class)
            );
            finish();
            return;
        }
        userId = currentUser.getUid();

        repository = new MedicationRepository();
        medicationReference =
                repository.getMedicationList(userId);
        bindViews();
        configureList();
        configureForm();
        listenForMedications();
    }

    private void bindViews() {
        medicineName = findViewById(R.id.medicineName);
        dosage = findViewById(R.id.dosage);
        schedule = findViewById(R.id.schedule);
        frequency = findViewById(R.id.frequency);
        reminderEnabled =
                findViewById(R.id.enableMedicationReminder);
        saveButton = findViewById(R.id.saveMedication);
        cancelEditButton =
                findViewById(R.id.cancelMedicationEdit);
        sectionTitle =
                findViewById(R.id.medicationFormTitle);
        emptyState =
                findViewById(R.id.medicationEmptyState);
    }

    private void configureList() {
        RecyclerView recyclerView =
                findViewById(R.id.savedMedicationList);
        recyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );
        recyclerView.setNestedScrollingEnabled(false);
        adapter =
                new MedicationAdapter(medications, this);
        recyclerView.setAdapter(adapter);
    }

    private void configureForm() {
        frequency.setText("Daily");
        frequency.setFocusable(false);
        frequency.setClickable(false);
        schedule.setFocusable(false);
        schedule.setClickable(true);
        schedule.setOnClickListener(
                view -> showTimePicker()
        );
        saveButton.setOnClickListener(
                view -> saveMedication()
        );
        cancelEditButton.setOnClickListener(
                view -> clearFields()
        );
    }

    private void showTimePicker() {
        Calendar now = Calendar.getInstance();
        int hour =
                selectedHour >= 0
                        ? selectedHour
                        : now.get(Calendar.HOUR_OF_DAY);
        int minute =
                selectedMinute >= 0
                        ? selectedMinute
                        : now.get(Calendar.MINUTE);
        new TimePickerDialog(
                this,
                (view, selectedHourOfDay, selectedMinuteOfHour) -> {
                    selectedHour = selectedHourOfDay;
                    selectedMinute = selectedMinuteOfHour;
                    schedule.setText(
                            formatTime(
                                    selectedHour,
                                    selectedMinute
                            )
                    );
                },
                hour,
                minute,
                false
        ).show();
    }

    private void saveMedication() {
        String nameValue = valueOf(medicineName);
        String dosageValue = valueOf(dosage);
        String frequencyValue = valueOf(frequency);
        boolean reminderValue =
                reminderEnabled.isChecked();

        if (nameValue.isEmpty()) {
            medicineName.setError(
                    "Medicine name is required"
            );
            medicineName.requestFocus();
            return;
        }
        if (dosageValue.isEmpty()) {
            dosage.setError("Dosage is required");
            dosage.requestFocus();
            return;
        }
        if (reminderValue
                && (selectedHour < 0
                || selectedMinute < 0)) {
            schedule.setError(
                    "Choose the reminder time"
            );
            showTimePicker();
            return;
        }

        if (reminderValue && !hasNotificationPermission()) {
            retrySaveAfterNotificationPermission = true;
            notificationPermissionLauncher.launch(
                    Manifest.permission.POST_NOTIFICATIONS
            );
            return;
        }

        if (frequencyValue.isEmpty()) {
            frequencyValue = "Daily";
        }
        String scheduleValue =
                reminderValue
                        ? formatTime(
                        selectedHour,
                        selectedMinute
                )
                        : "Reminder disabled";

        Medication medication = new Medication(
                editingMedicationId == null
                        ? ""
                        : editingMedicationId,
                nameValue,
                dosageValue,
                scheduleValue,
                frequencyValue,
                reminderValue,
                selectedHour,
                selectedMinute,
                reminderValue,
                editingCreatedAt,
                0L
        );

        setSaving(true);
        com.google.android.gms.tasks.Task<Void> task =
                editingMedicationId == null
                        ? repository.addMedication(
                        userId,
                        medication
                )
                        : repository.updateMedication(
                        userId,
                        medication
                );

        boolean wasEditing =
                editingMedicationId != null;
        task.addOnCompleteListener(result -> {
            setSaving(false);
            if (!result.isSuccessful()) {
                Toast.makeText(
                        this,
                        "Unable to save the medication.",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            MedicationAlarmScheduler.ScheduleMode mode;
            if (reminderValue) {
                mode =
                        MedicationAlarmScheduler.scheduleDaily(
                                this,
                                userId,
                                medication
                        );
            } else {
                MedicationAlarmScheduler.cancelAllForMedication(
                        this,
                        medication.getId()
                );
                mode =
                        MedicationAlarmScheduler.ScheduleMode
                                .NOT_SCHEDULED;
            }

            String confirmation;
            if (wasEditing) {
                confirmation = reminderValue
                        ? "Medication and reminder updated."
                        : "Medication updated; reminder disabled.";
            } else {
                confirmation = reminderValue
                        ? "Medication and reminder saved."
                        : "Medication saved without a reminder.";
            }
            Toast.makeText(
                    this,
                    confirmation,
                    Toast.LENGTH_SHORT
            ).show();
            clearFields();

            if (mode
                    == MedicationAlarmScheduler.ScheduleMode
                    .INEXACT
                    && Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.S) {
                showExactAlarmPermissionExplanation();
            }
        });
    }

    private void listenForMedications() {
        medicationListener =
                new ValueEventListener() {
                    @Override
                    public void onDataChange(
                            @NonNull DataSnapshot snapshot
                    ) {
                        medications.clear();
                        for (DataSnapshot child :
                                snapshot.getChildren()) {
                            Medication medication =
                                    child.getValue(
                                            Medication.class
                                    );
                            if (medication == null) {
                                continue;
                            }
                            medication.setId(child.getKey());
                            medications.add(medication);
                        }
                        medications.sort(
                                Comparator.comparingLong(
                                        Medication::getUpdatedAt
                                ).reversed()
                        );
                        adapter.notifyDataSetChanged();
                        emptyState.setVisibility(
                                medications.isEmpty()
                                        ? View.VISIBLE
                                        : View.GONE
                        );
                    }

                    @Override
                    public void onCancelled(
                            @NonNull DatabaseError error
                    ) {
                        Toast.makeText(
                                MedicationActivity.this,
                                "Unable to load medications.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                };
        medicationQuery = medicationReference.orderByChild("updatedAt");
        medicationQuery.addValueEventListener(medicationListener);
    }

    @Override
    public void onEdit(Medication medication) {
        editingMedicationId = medication.getId();
        editingCreatedAt = medication.getCreatedAt();
        selectedHour = medication.getReminderHour();
        selectedMinute = medication.getReminderMinute();

        medicineName.setText(medication.getName());
        dosage.setText(medication.getDosage());
        frequency.setText(
                medication.getFrequency() == null
                        || medication.getFrequency()
                        .trim()
                        .isEmpty()
                        ? "Daily"
                        : medication.getFrequency()
        );
        reminderEnabled.setChecked(
                medication.isActive()
                        && medication.isReminderEnabled()
        );
        schedule.setText(
                medication.hasValidReminderTime()
                        ? formatTime(
                        selectedHour,
                        selectedMinute
                )
                        : ""
        );
        sectionTitle.setText("Edit medication");
        saveButton.setText("Update medication");
        cancelEditButton.setVisibility(View.VISIBLE);
        medicineName.requestFocus();
    }

    @Override
    public void onDelete(Medication medication) {
        new AlertDialog.Builder(this)
                .setTitle("Delete medication?")
                .setMessage(
                        "This removes the medication "
                                + "and cancels its reminder."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                repository.deleteMedication(
                                                userId,
                                                medication.getId()
                                        )
                                        .addOnCompleteListener(
                                                task -> {
                                                    if (task.isSuccessful()) {
                                                        MedicationAlarmScheduler
                                                                .cancelAllForMedication(
                                                                        this,
                                                                        medication.getId()
                                                                );
                                                        if (medication.getId()
                                                                .equals(
                                                                        editingMedicationId
                                                                )) {
                                                            clearFields();
                                                        }
                                                        Toast.makeText(
                                                                this,
                                                                "Medication deleted.",
                                                                Toast.LENGTH_SHORT
                                                        ).show();
                                                    } else {
                                                        Toast.makeText(
                                                                this,
                                                                "Unable to delete medication.",
                                                                Toast.LENGTH_LONG
                                                        ).show();
                                                    }
                                                }
                                        )
                )
                .show();
    }

    @Override
    public void onReminderChanged(
            Medication medication,
            boolean enabled
    ) {
        if (enabled && !medication.hasValidReminderTime()) {
            medication.setActive(false);
            medication.setReminderEnabled(false);
            adapter.notifyDataSetChanged();
            Toast.makeText(
                    this,
                    "Choose a reminder time before enabling the alarm.",
                    Toast.LENGTH_LONG
            ).show();
            onEdit(medication);
            return;
        }

        medication.setActive(enabled);
        medication.setReminderEnabled(enabled);
        repository.setReminderEnabled(
                        userId,
                        medication.getId(),
                        enabled
                )
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Toast.makeText(
                                this,
                                "Unable to update the reminder.",
                                Toast.LENGTH_LONG
                        ).show();
                        return;
                    }

                    if (enabled) {
                        MedicationAlarmScheduler.ScheduleMode mode =
                                MedicationAlarmScheduler
                                        .scheduleDaily(
                                                this,
                                                userId,
                                                medication
                                        );
                        if (mode
                                == MedicationAlarmScheduler.ScheduleMode
                                .INEXACT
                                && Build.VERSION.SDK_INT
                                >= Build.VERSION_CODES.S) {
                            showExactAlarmPermissionExplanation();
                        }
                    } else {
                        MedicationAlarmScheduler.cancelAllForMedication(
                                this,
                                medication.getId()
                        );
                    }
                });
    }

    private boolean hasNotificationPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void showExactAlarmPermissionExplanation() {
        if (MedicationAlarmScheduler
                .canScheduleExactAlarms(this)) {
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(
                        "Allow exact medication reminders"
                )
                .setMessage(
                        "The reminder is saved, but Android "
                                + "may deliver it a little later. "
                                + "Allow Alarms & reminders "
                                + "for precise delivery."
                )
                .setNegativeButton("Later", null)
                .setPositiveButton(
                        "Allow alarms",
                        (dialog, which) ->
                                MedicationAlarmScheduler
                                        .openExactAlarmSettings(
                                                this
                                        )
                )
                .show();
    }

    private void setSaving(boolean saving) {
        saveButton.setEnabled(!saving);
        saveButton.setText(
                saving
                        ? "Saving…"
                        : editingMedicationId == null
                        ? "Save medication"
                        : "Update medication"
        );
    }

    private void clearFields() {
        editingMedicationId = null;
        editingCreatedAt = 0L;
        selectedHour = -1;
        selectedMinute = -1;
        medicineName.setText("");
        dosage.setText("");
        schedule.setText("");
        schedule.setError(null);
        frequency.setText("Daily");
        reminderEnabled.setChecked(true);
        sectionTitle.setText("Medication details");
        saveButton.setText("Save medication");
        cancelEditButton.setVisibility(View.GONE);
        medicineName.requestFocus();
    }

    private String formatTime(int hour, int minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        return DateFormat.getTimeInstance(
                DateFormat.SHORT
        ).format(calendar.getTime());
    }

    private static String valueOf(EditText field) {
        return field.getText() == null
                ? ""
                : field.getText()
                .toString()
                .trim();
    }

    @Override
    protected void onDestroy() {
        if (medicationQuery != null
                && medicationListener != null) {
            medicationQuery.removeEventListener(
                    medicationListener
            );
        }
        super.onDestroy();
    }
}
