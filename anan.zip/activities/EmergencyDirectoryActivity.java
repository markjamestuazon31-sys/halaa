package com.example.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.adapters.EmergencyDirectoryAdapter;
import com.example.app.models.EmergencyDirectoryContact;
import com.example.app.repositories.EmergencyDirectoryRepository;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

public class EmergencyDirectoryActivity extends AppCompatActivity {
    public static final String EXTRA_INCIDENT_ID = "incidentId";
    private final EmergencyDirectoryRepository repository = new EmergencyDirectoryRepository();
    private String incidentId;
    private String uid;
    private TextView warning;
    private EmergencyDirectoryAdapter adapter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_emergency_directory);
        incidentId = safe(getIntent().getStringExtra(EXTRA_INCIDENT_ID));
        uid = safe(FirebaseAuth.getInstance().getUid());
        if (incidentId.isEmpty() || uid.isEmpty()) { finish(); return; }
        findViewById(R.id.directoryBack).setOnClickListener(v -> finish());
        warning = findViewById(R.id.directoryWarning);
        RecyclerView list = findViewById(R.id.directoryList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EmergencyDirectoryAdapter(this::openDialer);
        list.setAdapter(adapter);
        repository.loadForIncident(incidentId, new EmergencyDirectoryRepository.Listener() {
            @Override public void onLoaded(List<EmergencyDirectoryContact> contacts, boolean missing, String barangayId) {
                adapter.submit(contacts);
                warning.setVisibility(missing ? View.VISIBLE : View.GONE);
                warning.setText(missing ? "No active contact is configured for the assigned barangay. General Catbalogan emergency hotlines remain available." : "Assigned-barangay contacts are listed first, followed by general emergency hotlines.");
            }
            @Override public void onError(String message) { warning.setVisibility(View.VISIBLE); warning.setText(message); }
        });
    }

    private void openDialer(EmergencyDirectoryContact contact) {
        repository.recordCallAction(incidentId, contact, uid, new EmergencyDirectoryRepository.Callback() {
            @Override public void onSuccess() { startDialer(contact.getPhone()); }
            @Override public void onError(String message) {
                Toast.makeText(EmergencyDirectoryActivity.this, "The call action could not be audited: " + message, Toast.LENGTH_LONG).show();
                startDialer(contact.getPhone());
            }
        });
    }
    private void startDialer(String phone) { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone)))); }
    private String safe(String value) { return value == null ? "" : value.trim(); }
}
