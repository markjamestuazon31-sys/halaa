package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.adapters.AnnouncementAdapter;
import com.example.app.models.Announcement;
import com.example.app.repositories.AnnouncementRepository;
import com.example.app.utils.AnnouncementImageLoader;
import com.example.app.utils.AnnouncementSeenStore;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class AnnouncementActivity
        extends AppCompatActivity
        implements AnnouncementAdapter.Listener {

    private final List<Announcement> announcements =
            new ArrayList<>();
    private AnnouncementAdapter adapter;
    private ProgressBar progress;
    private TextView emptyState;
    private Query query;
    private ValueEventListener listener;
    private String requestedAnnouncementId;
    private boolean requestedAnnouncementOpened;

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);
        setContentView(
                R.layout.activity_announcements
        );

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        findViewById(
                R.id.announcementBackButton
        ).setOnClickListener(view -> finish());
        progress =
                findViewById(
                        R.id.announcementProgress
                );
        emptyState =
                findViewById(
                        R.id.announcementEmptyState
                );
        requestedAnnouncementId =
                getIntent().getStringExtra(
                        "announcementId"
                );

        RecyclerView list =
                findViewById(
                        R.id.announcementList
                );
        list.setLayoutManager(
                new LinearLayoutManager(this)
        );
        adapter =
                new AnnouncementAdapter(
                        announcements,
                        this
                );
        list.setAdapter(adapter);

        query =
                new AnnouncementRepository()
                        .getLatestAnnouncements();
        listen();
    }

    private void listen() {
        listener =
                new ValueEventListener() {
                    @Override
                    public void onDataChange(
                            @NonNull DataSnapshot snapshot
                    ) {
                        announcements.clear();
                        long now =
                                System.currentTimeMillis();
                        for (DataSnapshot child :
                                snapshot.getChildren()) {
                            Announcement announcement =
                                    child.getValue(
                                            Announcement.class
                                    );
                            if (announcement == null) {
                                continue;
                            }
                            announcement.setId(
                                    child.getKey()
                            );
                            if (announcement.isVisible(now)) {
                                announcements.add(
                                        announcement
                                );
                            }
                        }
                        announcements.sort(
                                Comparator.comparingLong(
                                        Announcement::getCreatedAt
                                ).reversed()
                        );
                        adapter.notifyDataSetChanged();
                        progress.setVisibility(
                                View.GONE
                        );
                        emptyState.setVisibility(
                                announcements.isEmpty()
                                        ? View.VISIBLE
                                        : View.GONE
                        );
                        openRequestedAnnouncement();
                    }

                    @Override
                    public void onCancelled(
                            @NonNull DatabaseError error
                    ) {
                        progress.setVisibility(
                                View.GONE
                        );
                        emptyState.setVisibility(
                                View.VISIBLE
                        );
                        Toast.makeText(
                                AnnouncementActivity.this,
                                "Unable to load announcements.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                };
        query.addValueEventListener(listener);
    }

    private void openRequestedAnnouncement() {
        if (requestedAnnouncementOpened
                || requestedAnnouncementId == null) {
            return;
        }
        for (Announcement announcement :
                announcements) {
            if (requestedAnnouncementId.equals(
                    announcement.getId()
            )) {
                requestedAnnouncementOpened = true;
                onSelected(announcement);
                return;
            }
        }
    }

    @Override
    public void onSelected(
            Announcement announcement
    ) {
        String category =
                safe(
                        announcement.getCategory(),
                        "Community update"
                );
        String published =
                announcement.getCreatedAt() > 0
                        ? DateFormat
                        .getDateTimeInstance()
                        .format(
                                new Date(
                                        announcement
                                                .getCreatedAt()
                                )
                        )
                        : "Recently";

        View detailView = getLayoutInflater().inflate(
                R.layout.dialog_announcement_details,
                null,
                false
        );
        ImageView detailImage = detailView.findViewById(
                R.id.announcementDialogImage
        );
        TextView detailCategory = detailView.findViewById(
                R.id.announcementDialogCategory
        );
        TextView detailPublished = detailView.findViewById(
                R.id.announcementDialogPublished
        );
        TextView detailContent = detailView.findViewById(
                R.id.announcementDialogContent
        );

        AnnouncementImageLoader.load(
                detailImage,
                announcement.getImageData()
        );
        detailCategory.setText(category);
        detailPublished.setText(published);
        detailContent.setText(
                safe(
                        announcement.getContent(),
                        "No additional information was provided."
                )
        );

        new MaterialAlertDialogBuilder(this)
                .setTitle(
                        safe(
                                announcement.getTitle(),
                                "HealthMate announcement"
                        )
                )
                .setView(detailView)
                .setPositiveButton("Close", null)
                .show();

        String userId =
                FirebaseAuth.getInstance().getUid();
        if (userId != null
                && announcement.getId() != null) {
            AnnouncementSeenStore.markSeen(
                    this,
                    userId,
                    announcement.getId()
            );
            com.google.firebase.database
                    .FirebaseDatabase.getInstance()
                    .getReference(
                            "announcementReads"
                    )
                    .child(userId)
                    .child(announcement.getId())
                    .setValue(
                            System.currentTimeMillis()
                    );
        }
    }

    private static String safe(
            String value,
            String fallback
    ) {
        return value == null
                || value.trim().isEmpty()
                ? fallback
                : value.trim();
    }

    @Override
    protected void onDestroy() {
        if (query != null && listener != null) {
            query.removeEventListener(listener);
        }
        super.onDestroy();
    }
}
