package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.adapters.NotificationAdapter;
import com.example.app.models.NotificationModel;
import com.example.app.notifications.NotificationCategory;
import com.example.app.notifications.NotificationChannelManager;
import com.example.app.notifications.NotificationPermissionHelper;
import com.example.app.notifications.TokenRegistrationManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class NotificationActivity
        extends AppCompatActivity
        implements NotificationAdapter.Listener {

    private final Map<String, NotificationModel> notificationById =
            new LinkedHashMap<>();

    private NotificationAdapter adapter;
    private ProgressBar progress;
    private RecyclerView recyclerView;
    private View caughtUpState;

    private LinearLayout tabAll;
    private LinearLayout tabAlerts;
    private LinearLayout tabCalls;
    private LinearLayout tabAccount;

    private TextView tabAllLabel;
    private TextView tabAlertsLabel;
    private TextView tabCallsLabel;
    private TextView tabAccountLabel;

    private TextView countAll;
    private TextView countAlerts;
    private TextView countCalls;
    private TextView countAccount;

    private DatabaseReference inboxReference;
    private Query inboxQuery;
    private ChildEventListener inboxListener;
    private boolean listening;

    @Nullable
    private NotificationCategory selectedCategory;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .setAppearanceLightStatusBars(true);

        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        NotificationChannelManager.ensureCreated(this);
        NotificationPermissionHelper.requestIfNeeded(this);
        TokenRegistrationManager.syncCurrentToken();

        bindViews();
        setupHeaderActions();
        setupRecyclerView();
        setupTabs();

        inboxReference = FirebaseDatabase.getInstance()
                .getReference("notifications")
                .child(uid);
        inboxQuery = inboxReference
                .orderByChild("createdAt")
                .limitToLast(100);
    }

    @Override
    protected void onStart() {
        super.onStart();
        startListening();
    }

    @Override
    protected void onStop() {
        stopListening();
        super.onStop();
    }

    private void bindViews() {
        progress = findViewById(R.id.notificationProgress);
        recyclerView = findViewById(R.id.notificationList);
        caughtUpState = findViewById(R.id.notificationCaughtUpState);

        tabAll = findViewById(R.id.notificationTabAll);
        tabAlerts = findViewById(R.id.notificationTabAlerts);
        tabCalls = findViewById(R.id.notificationTabCalls);
        tabAccount = findViewById(R.id.notificationTabAccount);

        tabAllLabel = findViewById(R.id.notificationTabAllLabel);
        tabAlertsLabel = findViewById(R.id.notificationTabAlertsLabel);
        tabCallsLabel = findViewById(R.id.notificationTabCallsLabel);
        tabAccountLabel = findViewById(R.id.notificationTabAccountLabel);

        countAll = findViewById(R.id.notificationCountAll);
        countAlerts = findViewById(R.id.notificationCountAlerts);
        countCalls = findViewById(R.id.notificationCountCalls);
        countAccount = findViewById(R.id.notificationCountAccount);
    }

    private void setupHeaderActions() {
        findViewById(R.id.notificationMenuButton).setOnClickListener(view -> finish());

        findViewById(R.id.notificationSettingsButton).setOnClickListener(view -> {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(intent);
        });

        findViewById(R.id.openAnnouncementsButton).setOnClickListener(view ->
                startActivity(new Intent(this, AnnouncementActivity.class))
        );
    }

    private void setupRecyclerView() {
        adapter = new NotificationAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        recyclerView.setNestedScrollingEnabled(false);
    }

    private void setupTabs() {
        tabAll.setOnClickListener(view -> selectCategory(null));
        tabAlerts.setOnClickListener(view -> selectCategory(NotificationCategory.ALERTS));
        tabCalls.setOnClickListener(view -> selectCategory(NotificationCategory.CALLS));
        tabAccount.setOnClickListener(view -> selectCategory(NotificationCategory.ACCOUNT));
        selectCategory(null);
    }

    private void selectCategory(@Nullable NotificationCategory category) {
        selectedCategory = category;
        setTabSelected(tabAll, tabAllLabel, countAll, category == null);
        setTabSelected(
                tabAlerts,
                tabAlertsLabel,
                countAlerts,
                category == NotificationCategory.ALERTS
        );
        setTabSelected(
                tabCalls,
                tabCallsLabel,
                countCalls,
                category == NotificationCategory.CALLS
        );
        setTabSelected(
                tabAccount,
                tabAccountLabel,
                countAccount,
                category == NotificationCategory.ACCOUNT
        );
        renderNotifications();
    }

    private void setTabSelected(
            @NonNull LinearLayout tab,
            @NonNull TextView label,
            @NonNull TextView count,
            boolean selected
    ) {
        tab.setBackgroundResource(
                selected
                        ? R.drawable.bg_notify_tab_selected
                        : android.R.color.transparent
        );
        label.setTextColor(
                ContextCompat.getColor(
                        this,
                        selected ? R.color.hm_notify_teal : R.color.hm_notify_navy
                )
        );
        count.setBackgroundResource(
                selected
                        ? R.drawable.bg_notify_count_active
                        : R.drawable.bg_notify_count_neutral
        );
        count.setTextColor(
                ContextCompat.getColor(
                        this,
                        selected
                                ? R.color.hm_notify_surface
                                : R.color.hm_notify_text_secondary
                )
        );
    }

    private void startListening() {
        if (listening || inboxQuery == null) {
            return;
        }

        listening = true;
        progress.setVisibility(View.VISIBLE);
        notificationById.clear();
        renderNotifications();

        inboxListener = new ChildEventListener() {
            @Override
            public void onChildAdded(
                    @NonNull DataSnapshot snapshot,
                    @Nullable String previousChildName
            ) {
                upsert(snapshot);
            }

            @Override
            public void onChildChanged(
                    @NonNull DataSnapshot snapshot,
                    @Nullable String previousChildName
            ) {
                upsert(snapshot);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                String key = snapshot.getKey();
                if (key != null) {
                    notificationById.remove(key);
                    renderNotifications();
                }
            }

            @Override
            public void onChildMoved(
                    @NonNull DataSnapshot snapshot,
                    @Nullable String previousChildName
            ) {
                upsert(snapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progress.setVisibility(View.GONE);
                Toast.makeText(
                        NotificationActivity.this,
                        error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        };

        inboxQuery.addChildEventListener(inboxListener);
        inboxQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    upsertWithoutRender(child);
                }
                progress.setVisibility(View.GONE);
                renderNotifications();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progress.setVisibility(View.GONE);
            }
        });
    }

    private void stopListening() {
        if (!listening) {
            return;
        }
        if (inboxQuery != null && inboxListener != null) {
            inboxQuery.removeEventListener(inboxListener);
        }
        inboxListener = null;
        listening = false;
    }

    private void upsert(@NonNull DataSnapshot snapshot) {
        upsertWithoutRender(snapshot);
        progress.setVisibility(View.GONE);
        renderNotifications();
    }

    private void upsertWithoutRender(@NonNull DataSnapshot snapshot) {
        String key = snapshot.getKey();
        NotificationModel notification =
                snapshot.getValue(NotificationModel.class);

        if (key == null || notification == null) {
            return;
        }

        notification.setId(key);
        notificationById.put(key, notification);
    }

    private void renderNotifications() {
        List<NotificationModel> all =
                new ArrayList<>(notificationById.values());
        all.sort(
                Comparator.comparingLong(NotificationModel::getDisplayTimestamp)
                        .reversed()
        );

        int alertCount = 0;
        int callCount = 0;
        int accountCount = 0;
        List<NotificationModel> filtered = new ArrayList<>();

        for (NotificationModel notification : all) {
            NotificationCategory category =
                    NotificationCategory.fromType(notification.getType());

            if (category == NotificationCategory.ALERTS) {
                alertCount++;
            } else if (category == NotificationCategory.CALLS) {
                callCount++;
            } else {
                accountCount++;
            }

            if (selectedCategory == null || selectedCategory == category) {
                filtered.add(notification);
            }
        }

        countAll.setText(String.valueOf(all.size()));
        countAlerts.setText(String.valueOf(alertCount));
        countCalls.setText(String.valueOf(callCount));
        countAccount.setText(String.valueOf(accountCount));

        adapter.submitList(new ArrayList<>(filtered));
        recyclerView.setVisibility(filtered.isEmpty() ? View.GONE : View.VISIBLE);
        caughtUpState.setVisibility(View.VISIBLE);
    }

    @Override
    public void onNotificationSelected(@NonNull NotificationModel notification) {
        if (notification.getId() != null && !notification.isRead()) {
            notification.setRead(true);
            notificationById.put(notification.getId(), notification);
            renderNotifications();

            inboxReference.child(notification.getId())
                    .child("read")
                    .setValue(true);
        }

        routeNotification(notification);
    }

    private void routeNotification(@NonNull NotificationModel notification) {
        String type = notification.getType();

        if ("announcement".equals(type)) {
            Intent intent = new Intent(this, AnnouncementActivity.class);
            intent.putExtra("announcementId", notification.getAnnouncementId());
            startActivity(intent);
            return;
        }

        if ("incoming_call".equals(type) && notification.getCallId() != null) {
            Intent intent = new Intent(this, CallActivity.class);
            intent.putExtra("callId", notification.getCallId());
            intent.putExtra("incoming", true);
            startActivity(intent);
            return;
        }

        if ("contact_request".equals(type) || "contact_accepted".equals(type)) {
            startActivity(new Intent(this, EmergencyContactsActivity.class));
            return;
        }

        if ("chat_message".equals(type) && notification.getCreatedBy() != null) {
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("receiverId", notification.getCreatedBy());
            startActivity(intent);
            return;
        }

        if (type != null
                && (type.startsWith("emergency")
                || "sos".equalsIgnoreCase(type))) {
            Intent intent = new Intent(this, FamilyTrackingMapActivity.class);
            String emergencyUserId = notification.getCreatedBy();
            if (emergencyUserId == null || emergencyUserId.trim().isEmpty()) {
                emergencyUserId = FirebaseAuth.getInstance().getUid();
            }
            String incidentId = notification.getIncidentId();
            if (incidentId == null || incidentId.trim().isEmpty()) {
                incidentId = notification.getEmergencyId();
            }
            intent.putExtra("userId", emergencyUserId);
            intent.putExtra("incidentId", incidentId);
            intent.putExtra("emergencyId", incidentId);
            intent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP
            );
            startActivity(intent);
        }
    }
}
