package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.auth.AccountAccess;
import com.example.app.navigation.RoleRouter;
import com.example.app.repositories.AuthRepository;
import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {
    private static final long DELAY_MILLIS = 700L;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Handler(Looper.getMainLooper()).postDelayed(this::resolveDestination, DELAY_MILLIS);
    }

    private void resolveDestination() {
        if (!HealthMateApplication.isFirebaseReady()) { openLogin(getString(R.string.home_firebase_missing_message)); return; }
        if (FirebaseAuth.getInstance().getCurrentUser() == null) { openLogin(null); return; }
        new AuthRepository().validateCurrentSessionWithAccess(new AuthRepository.AccessCallback() {
            @Override public void onSuccess(@NonNull AccountAccess access) {
                RoleRouter.openHome(SplashActivity.this, access, access.isOffline() ? "Offline cached access is active. Server-confirmed incident actions remain disabled until connectivity returns." : null);
            }
            @Override public void onError(String message) { openLogin(message); }
            @Override public void onTemporaryError(String message) { openLogin(message); }
        });
    }

    private void openLogin(String message) {
        Intent intent = new Intent(this, LoginActivity.class);
        if (message != null && !message.trim().isEmpty()) intent.putExtra(LoginActivity.EXTRA_AUTH_ERROR, message);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
