package com.example.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.content.ContextCompat;

import com.example.app.R;
import com.example.app.emergency.EmergencyOverlayPolicy;
import com.example.app.map.EmergencyMapOverlayRenderer;
import com.example.app.map.LocationFreshnessPolicy;
import com.example.app.map.MapConfiguration;
import com.example.app.map.MapLifecycleController;
import com.example.app.map.MapMarkerRenderer;
import com.example.app.models.ContactLocation;
import com.example.app.models.ContactPublicProfile;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.models.EmergencyMapOverlay;
import com.example.app.repositories.EmergencyMapOverlayRepository;
import com.example.app.repositories.LiveContactLocationRepository;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;


import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Full family/friend location map.
 *
 * The signed-in user's current device location is resolved locally and focused
 * automatically. Authorized family and explicitly granted friend locations
 * remain visible as separate profile-photo pins.
 */
public class FamilyTrackingMapActivity extends AppCompatActivity {
    private final LiveContactLocationRepository repository =
            new LiveContactLocationRepository();
    private final EmergencyMapOverlayRepository emergencyRepository =
            new EmergencyMapOverlayRepository();
    private final List<ContactLocation> repositoryLocations =
            new ArrayList<>();
    private final List<ContactLocation> latestLocations =
            new ArrayList<>();
    private final List<EmergencyMapOverlay> activeEmergencies =
            new ArrayList<>();

    private MapView mapView;
    private MapLifecycleController lifecycle;
    private MapLibreMap map;
    private MapMarkerRenderer renderer;
    private EmergencyMapOverlayRenderer emergencyRenderer;
    private FusedLocationProviderClient locationClient;
    private CancellationTokenSource locationToken;

    private TextView status;
    private TextView name;
    private TextView coordinates;
    private TextView updated;
    private TextView badge;
    private AppCompatImageButton recenter;
    private AppCompatImageButton backButton;
    private MaterialButton centerAction;
    private MaterialCardView emergencyBanner;
    private TextView emergencyTitle;
    private TextView emergencySubtitle;
    private MaterialButton emergencyOpenAction;

    private String currentUid = "";
    private String requestedIncidentId = "";
    private String selectedEmergencyId = "";
    private ContactPublicProfile selfProfile;
    private ContactLocation localSelfLocation;
    private int authorizedContactCount;
    private boolean styleReady;
    private boolean fallbackAttempted;
    private boolean automaticSelfFocusCompleted;
    private boolean automaticEmergencyFocusCompleted;

    private final ActivityResultLauncher<String[]>
            locationPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            result -> {
                boolean granted = Boolean.TRUE.equals(
                        result.get(Manifest.permission.ACCESS_FINE_LOCATION)
                ) || Boolean.TRUE.equals(
                        result.get(Manifest.permission.ACCESS_COARSE_LOCATION)
                );

                if (granted) {
                    loadMyCurrentLocation();
                } else {
                    renderSummary();
                    fitAllLocations(false);
                }
            }
    );

    private final MapView.OnDidFailLoadingMapListener mapFailureListener =
            errorMessage -> {
                if (!fallbackAttempted && map != null) {
                    fallbackAttempted = true;
                    status.setText(
                            "MapTiler unavailable. Loading OpenStreetMap fallback…"
                    );
                    loadStyle(MapConfiguration.offlineStyleUrl());
                    return;
                }

                status.setText(message(
                        errorMessage,
                        "Unable to load the map. Check the internet connection."
                ));
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MapLibre.getInstance(this);
        setContentView(R.layout.activity_family_map);

        currentUid = safe(FirebaseAuth.getInstance().getUid());
        requestedIncidentId = nonBlank(
                getIntent().getStringExtra("incidentId"),
                getIntent().getStringExtra("emergencyId")
        );
        if (currentUid.isEmpty()) {
            finish();
            return;
        }

        mapView = findViewById(R.id.familyMap);
        status = findViewById(R.id.mapStatus);
        name = findViewById(R.id.mapContactName);
        coordinates = findViewById(R.id.mapCoordinates);
        updated = findViewById(R.id.mapUpdated);
        badge = findViewById(R.id.mapLiveBadge);
        backButton = findViewById(R.id.mapBackButton);
        recenter = findViewById(R.id.mapRecenterButton);
        centerAction = findViewById(R.id.mapCenterAction);
        emergencyBanner = findViewById(R.id.mapEmergencyBanner);
        emergencyTitle = findViewById(R.id.mapEmergencyTitle);
        emergencySubtitle = findViewById(R.id.mapEmergencySubtitle);
        emergencyOpenAction = findViewById(R.id.mapEmergencyOpenAction);

        renderer = new MapMarkerRenderer(this);
        emergencyRenderer = new EmergencyMapOverlayRenderer(this);
        locationClient = LocationServices
                .getFusedLocationProviderClient(this);

        backButton.setOnClickListener(view -> finish());
        recenter.setOnClickListener(view -> focusPrimaryTarget(true));
        centerAction.setOnClickListener(view -> focusPrimaryTarget(true));
        emergencyOpenAction.setOnClickListener(
                view -> focusSelectedEmergency(true)
        );
        recenter.setEnabled(false);
        centerAction.setEnabled(false);

        lifecycle = new MapLifecycleController(mapView);
        lifecycle.onCreate(savedInstanceState);
        mapView.addOnDidFailLoadingMapListener(mapFailureListener);

        loadMap();
        listenForAuthorizedLocations();
        listenForEmergencyOverlays();
        loadSelfProfile();
        requestMyLocation();
    }

    private void loadMap() {
        status.setText(
                MapConfiguration.usesMapTiler()
                        ? "Loading MapTiler OpenStreetMap…"
                        : "Loading OpenStreetMap…"
        );

        mapView.getMapAsync(mapLibreMap -> {
            map = mapLibreMap;
            map.getUiSettings().setCompassEnabled(false);
            loadStyle(MapConfiguration.styleUrl());
        });
    }

    private void loadStyle(String styleUrl) {
        if (map == null) {
            return;
        }

        styleReady = false;
        map.setStyle(styleUrl, style -> {
            styleReady = true;
            renderer.attach(style);
            emergencyRenderer.attach(style);
            renderer.render(latestLocations);
            emergencyRenderer.render(activeEmergencies, findSelf());
            renderSummary();
            renderEmergencyBanner();

            if (!activeEmergencies.isEmpty()) {
                focusSelectedEmergency(false);
            } else if (localSelfLocation != null) {
                focusMyLocation(false);
            } else {
                fitAllLocations(false);
            }
        });
    }

    private void listenForAuthorizedLocations() {
        repository.listen(
                currentUid,
                new LiveContactLocationRepository.Listener() {
                    @Override
                    public void onChanged(
                            List<ContactLocation> locations
                    ) {
                        repositoryLocations.clear();
                        if (locations != null) {
                            repositoryLocations.addAll(locations);
                        }
                        rebuildAndRender();
                    }

                    @Override
                    public void onRelationshipCount(int count) {
                        authorizedContactCount = Math.max(0, count);
                        renderSummary();
                    }

                    @Override
                    public void onError(String message) {
                        status.setText(message(
                                message,
                                "Unable to load shared locations."
                        ));
                    }
                }
        );
    }

    private void listenForEmergencyOverlays() {
        emergencyRepository.listen(
                currentUid,
                new EmergencyMapOverlayRepository.Listener() {
                    @Override
                    public void onChanged(
                            @NonNull List<EmergencyMapOverlay> emergencies
                    ) {
                        activeEmergencies.clear();
                        activeEmergencies.addAll(emergencies);

                        List<String> orderedIds = new ArrayList<>();
                        for (EmergencyMapOverlay emergency : activeEmergencies) {
                            if (emergency != null
                                    && !safe(emergency.getIncidentId()).isEmpty()) {
                                orderedIds.add(emergency.getIncidentId());
                            }
                        }

                        String previousSelection = selectedEmergencyId;
                        selectedEmergencyId = safe(
                                EmergencyOverlayPolicy.selectPreferredIncident(
                                        requestedIncidentId,
                                        orderedIds
                                )
                        );

                        if (!safe(previousSelection).equals(selectedEmergencyId)) {
                            automaticEmergencyFocusCompleted = false;
                        }
                        if (activeEmergencies.isEmpty()) {
                            requestedIncidentId = "";
                            selectedEmergencyId = "";
                            automaticEmergencyFocusCompleted = false;
                        }

                        rebuildAndRender();
                        renderEmergencyBanner();
                    }

                    @Override
                    public void onError(@NonNull String message) {
                        if (activeEmergencies.isEmpty()) {
                            status.setText(nonBlank(
                                    message,
                                    "Unable to load active emergency overlays."
                            ));
                        }
                    }
                }
        );
    }

    private void loadSelfProfile() {
        FirebaseDatabase.getInstance()
                .getReference("publicProfiles")
                .child(currentUid)
                .get()
                .addOnSuccessListener(snapshot -> {
                    selfProfile = snapshot.getValue(
                            ContactPublicProfile.class
                    );
                    applySelfProfile();
                    rebuildAndRender();
                });
    }

    private void requestMyLocation() {
        if (hasLocationPermission()) {
            loadMyCurrentLocation();
            return;
        }

        locationPermissionLauncher.launch(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        });
    }

    private void loadMyCurrentLocation() {
        if (!hasLocationPermission()) {
            return;
        }

        if (locationToken != null) {
            locationToken.cancel();
        }
        locationToken = new CancellationTokenSource();

        locationClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                locationToken.getToken()
        ).addOnSuccessListener(location -> {
            if (location != null) {
                updateLocalSelfLocation(location);
                return;
            }

            locationClient.getLastLocation()
                    .addOnSuccessListener(lastLocation -> {
                        if (lastLocation != null) {
                            updateLocalSelfLocation(lastLocation);
                        } else {
                            renderSummary();
                            fitAllLocations(false);
                        }
                    });
        }).addOnFailureListener(error ->
                locationClient.getLastLocation()
                        .addOnSuccessListener(lastLocation -> {
                            if (lastLocation != null) {
                                updateLocalSelfLocation(lastLocation);
                            } else {
                                renderSummary();
                                fitAllLocations(false);
                            }
                        })
        );
    }

    private void updateLocalSelfLocation(Location location) {
        ContactLocation value = new ContactLocation();
        value.setUid(currentUid);
        value.setDisplayName("You");
        value.setRelationshipType("SELF");
        value.setLatitude(location.getLatitude());
        value.setLongitude(location.getLongitude());
        value.setAccuracy(location.getAccuracy());
        value.setBearing(location.getBearing());
        value.setSpeed(location.getSpeed());
        value.setUpdatedAt(
                location.getTime() > 0L
                        ? location.getTime()
                        : System.currentTimeMillis()
        );
        value.setSource("LOCAL");

        localSelfLocation = value;
        applySelfProfile();
        rebuildAndRender();

        if (styleReady && !activeEmergencies.isEmpty()) {
            focusSelectedEmergency(false);
        } else if (styleReady && !automaticSelfFocusCompleted) {
            focusMyLocation(false);
        }
    }

    private void applySelfProfile() {
        if (localSelfLocation == null || selfProfile == null) {
            return;
        }

        localSelfLocation.setDisplayName(nonBlank(
                selfProfile.getFullName(),
                "You"
        ));
        localSelfLocation.setProfileImage(
                safe(selfProfile.getProfileImage())
        );
    }

    private void rebuildAndRender() {
        Map<String, ContactLocation> deduplicated =
                new LinkedHashMap<>();

        for (ContactLocation location : repositoryLocations) {
            if (location == null || safe(location.getUid()).isEmpty()) {
                continue;
            }
            deduplicated.put(location.getUid(), location);
        }

        if (localSelfLocation != null) {
            ContactLocation storedSelf = deduplicated.get(currentUid);
            if (storedSelf == null
                    || localSelfLocation.getUpdatedAt()
                    >= storedSelf.getUpdatedAt()) {
                deduplicated.put(currentUid, localSelfLocation);
            }
        }

        latestLocations.clear();
        latestLocations.addAll(deduplicated.values());
        sortLocations(latestLocations);

        if (styleReady) {
            renderer.render(latestLocations);
            emergencyRenderer.render(activeEmergencies, findSelf());
        }

        renderSummary();
        renderEmergencyBanner();

        if (styleReady
                && !activeEmergencies.isEmpty()
                && !automaticEmergencyFocusCompleted) {
            focusSelectedEmergency(false);
        } else if (styleReady
                && localSelfLocation != null
                && !automaticSelfFocusCompleted) {
            focusMyLocation(false);
        } else if (styleReady
                && localSelfLocation == null
                && activeEmergencies.isEmpty()) {
            fitAllLocations(false);
        }
    }

    private void renderSummary() {
        int familyCount = 0;
        int friendCount = 0;
        long newest = 0L;
        int stale = 0;

        for (ContactLocation location : latestLocations) {
            if (location == null || location.isSelf()) {
                continue;
            }

            if ("FAMILY".equalsIgnoreCase(
                    location.getRelationshipType()
            )) {
                familyCount++;
            } else if ("FRIEND".equalsIgnoreCase(
                    location.getRelationshipType()
            )) {
                friendCount++;
            }

            newest = Math.max(newest, location.getUpdatedAt());
            if (LocationFreshnessPolicy.classify(
                    location.getUpdatedAt(),
                    System.currentTimeMillis()
            ) == LocationFreshnessPolicy.Freshness.STALE) {
                stale++;
            }
        }

        if (!styleReady) {
            status.setText("Loading map and authorized locations…");
        } else if (authorizedContactCount == 0) {
            status.setText(
                    "No accepted family or location-authorized friends yet."
            );
        } else if (familyCount + friendCount == 0) {
            status.setText(
                    "Contacts are paired, but no authorized live location is available."
            );
        } else if (stale > 0) {
            status.setText(
                    stale + " shared location"
                            + (stale == 1 ? " is" : "s are")
                            + " stale"
            );
        } else {
            status.setText(
                    (familyCount + friendCount)
                            + " authorized live location"
                            + (familyCount + friendCount == 1 ? "" : "s")
            );
        }

        if (localSelfLocation != null) {
            name.setText(
                    familyCount + " family • "
                            + friendCount + " friend"
                            + (friendCount == 1 ? "" : "s")
            );
            coordinates.setText(String.format(
                    java.util.Locale.US,
                    "My location: %.5f, %.5f",
                    localSelfLocation.getLatitude(),
                    localSelfLocation.getLongitude()
            ));
        } else {
            name.setText(
                    authorizedContactCount == 0
                            ? "My family map"
                            : authorizedContactCount
                            + " authorized contact"
                            + (authorizedContactCount == 1 ? "" : "s")
            );
            coordinates.setText(
                    hasLocationPermission()
                            ? "Locating this device…"
                            : "Location permission is needed to show your pin"
            );
        }

        long ownUpdated = localSelfLocation == null
                ? 0L
                : localSelfLocation.getUpdatedAt();
        newest = Math.max(newest, ownUpdated);

        updated.setText(
                newest <= 0L
                        ? "Waiting for a current location"
                        : "Updated " + DateUtils.getRelativeTimeSpanString(
                        newest,
                        System.currentTimeMillis(),
                        DateUtils.MINUTE_IN_MILLIS,
                        DateUtils.FORMAT_ABBREV_RELATIVE
                )
        );

        boolean hasAnyLocation = !latestLocations.isEmpty();
        recenter.setEnabled(hasAnyLocation);
        centerAction.setEnabled(hasAnyLocation);
        badge.setVisibility(hasAnyLocation ? View.VISIBLE : View.INVISIBLE);
        badge.setText(stale > 0 ? "MIXED" : "LIVE");

        EmergencyMapOverlay selected = findSelectedEmergency();
        if (selected != null) {
            String patient = nonBlank(
                    selected.getPatientName(),
                    "HealthMate contact"
            );
            status.setText("ACTIVE SOS • " + patient);
            badge.setVisibility(View.VISIBLE);
            badge.setText(getString(R.string.hm_map_sos_live));
            recenter.setEnabled(selected.hasValidLocation());
            centerAction.setEnabled(selected.hasValidLocation());
            centerAction.setText(R.string.hm_map_view_sos);
        } else {
            centerAction.setText(R.string.hm_map_center_location);
        }
    }

    private void renderEmergencyBanner() {
        EmergencyMapOverlay selected = findSelectedEmergency();
        if (selected == null) {
            emergencyBanner.setVisibility(View.GONE);
            return;
        }

        emergencyBanner.setVisibility(View.VISIBLE);
        String patient = nonBlank(
                selected.getPatientName(),
                "HealthMate contact"
        );
        emergencyTitle.setText("SOS • " + patient);

        String statusText = nonBlank(selected.getStatus(), "PENDING")
                .replace('_', ' ');
        String age = selected.getDisplayTimestamp() <= 0L
                ? "time unavailable"
                : String.valueOf(DateUtils.getRelativeTimeSpanString(
                selected.getDisplayTimestamp(),
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS,
                DateUtils.FORMAT_ABBREV_RELATIVE
        ));
        String locationState = selected.hasValidLocation()
                ? "live coordinates"
                : "waiting for coordinates";
        String countText = activeEmergencies.size() > 1
                ? " • " + activeEmergencies.size() + " active incidents"
                : "";
        emergencySubtitle.setText(
                statusText + " • " + locationState + " • " + age + countText
        );
        emergencyOpenAction.setEnabled(selected.hasValidLocation());
    }

    private void focusPrimaryTarget(boolean animated) {
        if (!activeEmergencies.isEmpty()) {
            focusSelectedEmergency(animated);
        } else {
            focusMyLocation(animated);
        }
    }

    private void focusSelectedEmergency(boolean animated) {
        if (map == null) {
            return;
        }

        EmergencyMapOverlay selected = findSelectedEmergency();
        if (selected == null || !selected.hasValidLocation()) {
            focusMyLocation(animated);
            return;
        }

        EmergencyLocationPoint location = selected.getPatientLocation();
        if (location == null) {
            return;
        }
        LatLng emergencyPoint = new LatLng(
                location.getLatitude(),
                location.getLongitude()
        );
        ContactLocation self = findSelf();

        if (valid(self)) {
            LatLng selfPoint = new LatLng(
                    self.getLatitude(),
                    self.getLongitude()
            );
            LatLngBounds bounds = new LatLngBounds.Builder()
                    .include(selfPoint)
                    .include(emergencyPoint)
                    .build();
            try {
                if (animated) {
                    map.animateCamera(
                            CameraUpdateFactory.newLatLngBounds(bounds, 150)
                    );
                } else {
                    map.moveCamera(
                            CameraUpdateFactory.newLatLngBounds(bounds, 150)
                    );
                }
            } catch (RuntimeException ignored) {
                moveToEmergencyPoint(emergencyPoint, animated);
            }
        } else {
            moveToEmergencyPoint(emergencyPoint, animated);
        }

        automaticEmergencyFocusCompleted = true;
    }

    private void moveToEmergencyPoint(
            @NonNull LatLng emergencyPoint,
            boolean animated
    ) {
        if (animated) {
            map.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(emergencyPoint, 16.0d)
            );
        } else {
            map.moveCamera(
                    CameraUpdateFactory.newLatLngZoom(emergencyPoint, 16.0d)
            );
        }
    }

    private EmergencyMapOverlay findSelectedEmergency() {
        if (activeEmergencies.isEmpty()) {
            return null;
        }
        for (EmergencyMapOverlay emergency : activeEmergencies) {
            if (emergency != null
                    && selectedEmergencyId.equals(
                    safe(emergency.getIncidentId())
            )) {
                return emergency;
            }
        }
        return activeEmergencies.get(0);
    }

    private void focusMyLocation(boolean animated) {
        if (map == null) {
            return;
        }

        ContactLocation self = findSelf();
        if (self == null || !valid(self)) {
            fitAllLocations(animated);
            return;
        }

        LatLng point = new LatLng(
                self.getLatitude(),
                self.getLongitude()
        );

        if (animated) {
            map.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(point, 16.2d)
            );
        } else {
            map.moveCamera(
                    CameraUpdateFactory.newLatLngZoom(point, 16.2d)
            );
        }

        automaticSelfFocusCompleted = true;
    }

    private void fitAllLocations(boolean animated) {
        if (map == null || latestLocations.isEmpty()) {
            return;
        }

        List<LatLng> points = new ArrayList<>();
        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        for (ContactLocation location : latestLocations) {
            if (!valid(location)) {
                continue;
            }

            LatLng point = new LatLng(
                    location.getLatitude(),
                    location.getLongitude()
            );
            points.add(point);
            builder.include(point);
        }

        if (points.isEmpty()) {
            return;
        }

        if (points.size() == 1) {
            if (animated) {
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(
                        points.get(0),
                        15.5d
                ));
            } else {
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                        points.get(0),
                        15.5d
                ));
            }
            return;
        }

        try {
            if (animated) {
                map.animateCamera(
                        CameraUpdateFactory.newLatLngBounds(
                                builder.build(),
                                120
                        )
                );
            } else {
                map.moveCamera(
                        CameraUpdateFactory.newLatLngBounds(
                                builder.build(),
                                120
                        )
                );
            }
        } catch (RuntimeException ignored) {
            // The next data or layout pass will retry camera positioning.
        }
    }

    private ContactLocation findSelf() {
        for (ContactLocation location : latestLocations) {
            if (location != null
                    && (location.isSelf()
                    || currentUid.equals(location.getUid()))) {
                return location;
            }
        }
        return null;
    }

    private void sortLocations(List<ContactLocation> locations) {
        Collections.sort(locations, new Comparator<ContactLocation>() {
            @Override
            public int compare(
                    ContactLocation left,
                    ContactLocation right
            ) {
                if (left.isSelf() && !right.isSelf()) {
                    return -1;
                }
                if (!left.isSelf() && right.isSelf()) {
                    return 1;
                }
                return safe(left.getDisplayName()).compareToIgnoreCase(
                        safe(right.getDisplayName())
                );
            }
        });
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean valid(ContactLocation location) {
        return location != null
                && Double.isFinite(location.getLatitude())
                && Double.isFinite(location.getLongitude())
                && location.getLatitude() >= -90d
                && location.getLatitude() <= 90d
                && location.getLongitude() >= -180d
                && location.getLongitude() <= 180d;
    }

    private String nonBlank(String value, String fallback) {
        return safe(value).isEmpty() ? fallback : value.trim();
    }

    private String message(String value, String fallback) {
        return safe(value).isEmpty() ? fallback : value.trim();
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        requestedIncidentId = nonBlank(
                intent.getStringExtra("incidentId"),
                intent.getStringExtra("emergencyId")
        );

        List<String> orderedIds = new ArrayList<>();
        for (EmergencyMapOverlay emergency : activeEmergencies) {
            if (emergency != null
                    && !safe(emergency.getIncidentId()).isEmpty()) {
                orderedIds.add(emergency.getIncidentId());
            }
        }
        selectedEmergencyId = safe(
                EmergencyOverlayPolicy.selectPreferredIncident(
                        requestedIncidentId,
                        orderedIds
                )
        );
        automaticEmergencyFocusCompleted = false;
        renderEmergencyBanner();
        if (styleReady) {
            focusSelectedEmergency(true);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (lifecycle != null) {
            lifecycle.onStart();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lifecycle != null) {
            lifecycle.onResume();
        }
    }

    @Override
    protected void onPause() {
        if (lifecycle != null) {
            lifecycle.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (lifecycle != null) {
            lifecycle.onStop();
        }
        super.onStop();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (lifecycle != null) {
            lifecycle.onLowMemory();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null) {
            mapView.onSaveInstanceState(outState);
        }
    }

    @Override
    protected void onDestroy() {
        repository.stop();
        emergencyRepository.stop();
        if (locationToken != null) {
            locationToken.cancel();
        }
        if (mapView != null) {
            mapView.removeOnDidFailLoadingMapListener(
                    mapFailureListener
            );
        }
        if (lifecycle != null) {
            lifecycle.onDestroy();
        }
        super.onDestroy();
    }
}
