package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app.R;
import com.example.app.adapters.ConversationAdapter;
import com.example.app.models.ConversationSummary;
import com.example.app.repositories.ConversationRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class ConversationInboxActivity extends AppCompatActivity implements ConversationAdapter.Listener{
    private final ConversationRepository repository=new ConversationRepository();private final List<ConversationSummary> all=new ArrayList<>();private ConversationAdapter adapter;private TextView empty;private EditText search;private String uid;private ValueEventListener listener;private int generation;
    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_conversation_inbox);uid=FirebaseAuth.getInstance().getUid();if(uid==null){finish();return;}findViewById(R.id.inboxBack).setOnClickListener(v->finish());findViewById(R.id.inboxContacts).setOnClickListener(v->startActivity(new Intent(this,RelationshipRequestsActivity.class)));search=findViewById(R.id.inboxSearch);empty=findViewById(R.id.inboxEmpty);RecyclerView recycler=findViewById(R.id.conversationRecycler);adapter=new ConversationAdapter(this);recycler.setLayoutManager(new LinearLayoutManager(this));recycler.setAdapter(adapter);search.addTextChangedListener(new TextWatcher(){@Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}@Override public void onTextChanged(CharSequence s,int start,int before,int count){applyFilter();}@Override public void afterTextChanged(Editable s){}});listen();}
    private void listen(){listener=new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot snapshot){int current=++generation;all.clear();for(DataSnapshot child:snapshot.getChildren()){ConversationSummary item=child.getValue(ConversationSummary.class);if(item==null||item.isArchived())continue;item.setConversationId(child.getKey());all.add(item);enrich(item,current);}all.sort(Comparator.comparingLong(ConversationSummary::getLastMessageAt).reversed());applyFilter();}@Override public void onCancelled(@NonNull DatabaseError error){empty.setVisibility(View.VISIBLE);empty.setText(error.getMessage());}};repository.listenInbox(uid,listener);}
    private void enrich(ConversationSummary item,int current){String other=item.getOtherParticipantUid();if(other==null)return;repository.loadPublicProfile(other,new ConversationRepository.ProfileCallback(){@Override public void onLoaded(DataSnapshot s){if(current!=generation)return;item.setDisplayName(s.child("fullName").getValue(String.class));item.setProfileImage(s.child("profileImage").getValue(String.class));applyFilter();}@Override public void onError(String message){}});repository.loadPresence(other,new ConversationRepository.ProfileCallback(){@Override public void onLoaded(DataSnapshot s){if(current!=generation)return;item.setPresenceState(s.child("state").getValue(String.class));Long at=s.child("lastSeenAt").getValue(Long.class);item.setLastSeenAt(at==null?0:at);applyFilter();}@Override public void onError(String message){}});FirebaseDatabase.getInstance().getReference("relationships").child(uid).child(other).child("relationshipType").get().addOnSuccessListener(s->{if(current==generation){item.setRelationshipType(s.getValue(String.class));applyFilter();}});}
    private void applyFilter(){String query=search==null?"":search.getText().toString().trim().toLowerCase(Locale.US);List<ConversationSummary> shown=new ArrayList<>();for(ConversationSummary item:all){String name=item.getDisplayName()==null?"":item.getDisplayName().toLowerCase(Locale.US);String text=item.getLastMessageText()==null?"":item.getLastMessageText().toLowerCase(Locale.US);if(query.isEmpty()||name.contains(query)||text.contains(query))shown.add(item);}shown.sort(Comparator.comparingLong(ConversationSummary::getLastMessageAt).reversed());adapter.submit(shown);empty.setVisibility(shown.isEmpty()?View.VISIBLE:View.GONE);}
    @Override public void onOpen(ConversationSummary item){Intent intent=new Intent(this,ChatActivity.class);intent.putExtra("conversationId",item.getConversationId());intent.putExtra("receiverId",item.getOtherParticipantUid());startActivity(intent);}
    @Override public void onOptions(ConversationSummary item,View anchor){PopupMenu menu=new PopupMenu(this,anchor);menu.getMenu().add(item.isMuted()?"Unmute":"Mute");menu.getMenu().add("Archive");menu.setOnMenuItemClickListener(option->{if(option.getTitle().toString().startsWith("Mute")||option.getTitle().toString().startsWith("Unmute")){repository.setMuted(uid,item.getConversationId(),!item.isMuted());}else repository.setArchived(uid,item.getConversationId(),true);return true;});menu.show();}
    @Override protected void onDestroy(){repository.stopInbox(uid,listener);super.onDestroy();}
}
