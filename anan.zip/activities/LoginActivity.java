package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.auth.AccountAccess;
import com.example.app.navigation.RoleRouter;
import com.example.app.repositories.AuthRepository;
import com.example.app.utils.ValidationUtils;

public class LoginActivity extends AppCompatActivity {
    public static final String EXTRA_AUTH_ERROR = "authError";
    private EditText email;
    private EditText password;
    private Button login;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = findViewById(R.id.email); password = findViewById(R.id.password); login = findViewById(R.id.loginBtn);
        TextView registerLink = findViewById(R.id.registerLink);
        String authError = getIntent().getStringExtra(EXTRA_AUTH_ERROR);
        if (!TextUtils.isEmpty(authError)) Toast.makeText(this, authError, Toast.LENGTH_LONG).show();
        login.setOnClickListener(view -> loginUser());
        registerLink.setOnClickListener(view -> startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void loginUser() {
        String userEmail = email.getText().toString().trim();
        String userPassword = password.getText().toString();
        if (!ValidationUtils.emailValid(userEmail)) { email.setError("Enter a valid email address"); email.requestFocus(); return; }
        if (TextUtils.isEmpty(userPassword)) { password.setError("Password is required"); password.requestFocus(); return; }
        setLoading(true);
        new AuthRepository().loginUserWithAccess(userEmail, userPassword, new AuthRepository.AccessCallback() {
            @Override public void onSuccess(@NonNull AccountAccess access) { RoleRouter.openHome(LoginActivity.this, access, null); }
            @Override public void onError(String message) { setLoading(false); Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show(); }
        });
    }

    private void setLoading(boolean loading) { login.setEnabled(!loading); login.setText(loading ? R.string.signing_in : R.string.sign_in); }
}
