package com.example.app.activities;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.models.RescueReport;
import com.example.app.repositories.RescueReportRepository;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RescueReportActivity extends AppCompatActivity {
    public static final String EXTRA_INCIDENT_ID = "incidentId";
    public static final String EXTRA_COORDINATOR = "coordinator";
    private static final String[] CLASSIFICATIONS = {
            "FALSE_ALARM", "NON_CRITICAL", "CRITICAL", "RESCUED_ON_SITE", "TRANSPORTED_TO_HOSPITAL",
            "REFERRED_TO_POLICE", "REFERRED_TO_FIRE_DEPARTMENT", "REFERRED_TO_BARANGAY", "USER_CANCELLED", "USER_NOT_FOUND"
    };

    private final RescueReportRepository repository = new RescueReportRepository();
    private String incidentId;
    private String uid;
    private boolean coordinator;
    private EditText observed, actions, agencies, transport, notes, finalSummary;
    private Spinner recommendation, finalClassification;
    private MaterialButton submitIndividual, submitFinal;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_rescue_report);
        if (getIntent().getBooleanExtra(MainActivity.EXTRA_OFFLINE_SESSION, false)) {
            Toast.makeText(this, "Reconnect before submitting rescue reports.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        incidentId = safe(getIntent().getStringExtra(EXTRA_INCIDENT_ID));
        uid = safe(FirebaseAuth.getInstance().getUid());
        coordinator = getIntent().getBooleanExtra(EXTRA_COORDINATOR, false);
        if (incidentId.isEmpty() || uid.isEmpty()) { finish(); return; }
        findViewById(R.id.reportBack).setOnClickListener(v -> finish());
        observed=findViewById(R.id.reportObserved); actions=findViewById(R.id.reportActions); agencies=findViewById(R.id.reportAgencies);
        transport=findViewById(R.id.reportTransport); notes=findViewById(R.id.reportNotes); finalSummary=findViewById(R.id.reportFinalSummary);
        recommendation=findViewById(R.id.reportRecommendation); finalClassification=findViewById(R.id.reportFinalClassification);
        submitIndividual=findViewById(R.id.reportSubmitIndividual); submitFinal=findViewById(R.id.reportSubmitFinal);
        ArrayAdapter<String> classifications=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CLASSIFICATIONS);
        recommendation.setAdapter(classifications); finalClassification.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CLASSIFICATIONS));
        submitFinal.setEnabled(coordinator);
        submitFinal.setText(coordinator ? "Submit final incident report" : "Final report — coordinator only");
        submitIndividual.setOnClickListener(v -> submitIndividual());
        submitFinal.setOnClickListener(v -> submitFinal());
        loadExisting();
    }

    private void loadExisting() {
        FirebaseDatabase.getInstance().getReference("rescueReports").child(incidentId).child("responders").child(uid).get().addOnSuccessListener(s -> {
            RescueReport r=s.getValue(RescueReport.class); if(r==null)return;
            observed.setText(r.getObservedCondition()); actions.setText(r.getActionsPerformed()); agencies.setText(r.getAgenciesContacted()); transport.setText(r.getTransportDestination()); notes.setText(r.getNotes());
            setSpinner(recommendation,r.getClassificationRecommendation());
        });
        if(coordinator) FirebaseDatabase.getInstance().getReference("rescueReports").child(incidentId).child("final").get().addOnSuccessListener(s->{RescueReport r=s.getValue(RescueReport.class);if(r!=null){finalSummary.setText(r.getSummary());setSpinner(finalClassification,r.getClassification());}});
    }

    private void submitIndividual() {
        RescueReport report=baseReport(); report.setClassificationRecommendation(String.valueOf(recommendation.getSelectedItem()));
        submitIndividual.setEnabled(false);
        repository.submitIndividual(incidentId,uid,report,new RescueReportRepository.Callback(){
            @Override public void onSuccess(){submitIndividual.setEnabled(true);toast("Individual rescue report submitted.");}
            @Override public void onError(String message){submitIndividual.setEnabled(true);toast(message);}
        });
    }
    private void submitFinal() {
        RescueReport report=baseReport(); report.setSummary(text(finalSummary)); report.setClassification(String.valueOf(finalClassification.getSelectedItem()));
        submitFinal.setEnabled(false);
        repository.submitFinal(incidentId,uid,report,new RescueReportRepository.Callback(){
            @Override public void onSuccess(){submitFinal.setEnabled(true);toast("Final incident report submitted for administrator review.");}
            @Override public void onError(String message){submitFinal.setEnabled(true);toast(message);}
        });
    }
    private RescueReport baseReport(){RescueReport r=new RescueReport();r.setObservedCondition(text(observed));r.setActionsPerformed(text(actions));r.setAgenciesContacted(text(agencies));r.setTransportDestination(text(transport));r.setNotes(text(notes));r.setArrivalAt(System.currentTimeMillis());r.setCompletedAt(System.currentTimeMillis());return r;}
    private void setSpinner(Spinner spinner,String value){if(value==null)return;for(int i=0;i<CLASSIFICATIONS.length;i++)if(CLASSIFICATIONS[i].equals(value)){spinner.setSelection(i);break;}}
    private String text(EditText e){return e.getText()==null?"":e.getText().toString().trim();}
    private void toast(String value){Toast.makeText(this,value==null?"Unable to submit report.":value,Toast.LENGTH_LONG).show();}
    private String safe(String value){return value==null?"":value.trim();}
}
