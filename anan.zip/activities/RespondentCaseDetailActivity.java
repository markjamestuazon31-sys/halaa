package com.example.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.emergency.IncidentTransitionPolicy;
import com.example.app.models.EmergencyIncident;
import com.example.app.models.EmergencyResponse;
import com.example.app.repositories.EmergencyResponseRepository;
import com.example.app.services.EmergencyLiveLocationService;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RespondentCaseDetailActivity extends AppCompatActivity {
    public static final String EXTRA_INCIDENT_ID = "incidentId";
    public static final String EXTRA_ACCEPTED_HINT = "acceptedHint";

    private final EmergencyResponseRepository responseRepository = new EmergencyResponseRepository();
    private String incidentId;
    private String uid;
    private String responderName = "HealthMate respondent";
    private EmergencyIncident incident;
    private EmergencyResponse ownResponse;
    private boolean accepted;
    private boolean coordinator;
    private boolean initializingStatus = true;
    private boolean offlineSession;
    private boolean acceptedListenersStarted;
    private boolean trackingRequested;

    private TextView patient, type, status, location, medical, team, authorization;
    private MaterialButton accept, map, directory, report, call, backup, withdraw;
    private Spinner responseStatus;
    private DatabaseReference incidentRef, responseRef, responsesRef, medicalRef, profileRef;
    private ValueEventListener incidentListener, responseListener, responsesListener, medicalListener, profileListener;

    private final ActivityResultLauncher<String[]> locationPermission = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean granted = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION)) || Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                if (granted) startResponderTracking();
                else Toast.makeText(this, "Location permission is required to share your response position.", Toast.LENGTH_LONG).show();
            }
    );

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_respondent_case_detail);
        offlineSession = getIntent().getBooleanExtra(MainActivity.EXTRA_OFFLINE_SESSION, false);
        incidentId = safe(getIntent().getStringExtra(EXTRA_INCIDENT_ID));
        uid = safe(FirebaseAuth.getInstance().getUid());
        if (incidentId.isEmpty() || uid.isEmpty()) { finish(); return; }
        bind(); configureStatus(); listen();
    }

    private void bind() {
        findViewById(R.id.caseDetailBack).setOnClickListener(v -> finish());
        patient=findViewById(R.id.casePatient); type=findViewById(R.id.caseType); status=findViewById(R.id.caseStatus);
        location=findViewById(R.id.caseLocation); medical=findViewById(R.id.caseMedical); team=findViewById(R.id.caseTeam); authorization=findViewById(R.id.caseAuthorization);
        accept=findViewById(R.id.caseAccept); map=findViewById(R.id.caseMap); directory=findViewById(R.id.caseDirectory); report=findViewById(R.id.caseReport);
        call=findViewById(R.id.caseCallPatient); backup=findViewById(R.id.caseBackup); withdraw=findViewById(R.id.caseWithdraw); responseStatus=findViewById(R.id.caseResponseStatus);
        accept.setOnClickListener(v -> accept());
        map.setOnClickListener(v -> openMap());
        directory.setOnClickListener(v -> startActivity(new Intent(this, EmergencyDirectoryActivity.class).putExtra(EmergencyDirectoryActivity.EXTRA_INCIDENT_ID, incidentId)));
        report.setOnClickListener(v -> { if(offlineSession){toast("Reconnect before submitting a rescue report.");return;} startActivity(new Intent(this, RescueReportActivity.class).putExtra(RescueReportActivity.EXTRA_INCIDENT_ID, incidentId).putExtra(RescueReportActivity.EXTRA_COORDINATOR, coordinator).putExtra(MainActivity.EXTRA_OFFLINE_SESSION,false)); });
        call.setOnClickListener(v -> {
            if(!accepted){toast("Accept this incident before contacting the patient.");return;}
            if(incident != null && !safe(incident.getPatientPhone()).isEmpty()) {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(incident.getPatientPhone()))));
            }
        });
        backup.setOnClickListener(v -> { if(offlineSession){toast("Reconnect before requesting backup.");return;} responseRepository.requestBackup(incidentId, uid, "Backup requested from respondent case screen.", callback("Backup request sent.")); });
        withdraw.setOnClickListener(v -> { if(offlineSession){toast("Reconnect before withdrawing from the response team.");return;} responseRepository.withdraw(incidentId, uid, callback("You withdrew from the response team.")); });
    }

    private void configureStatus() {
        String[] values={"ACCEPTED","RESPONDING","EN_ROUTE","ON_SCENE","AGENCY_CONTACTED","RESCUE_IN_PROGRESS"};
        responseStatus.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
        responseStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (initializingStatus || !accepted || offlineSession) return;
                String next=String.valueOf(parent.getItemAtPosition(position));
                if (ownResponse != null && next.equalsIgnoreCase(ownResponse.getResponseStatus())) return;
                responseRepository.updateOwnStatus(incidentId, uid, next, "", new EmergencyResponseRepository.Callback() {
                    @Override public void onSuccess(boolean ignored) {
                        if (coordinator && incident != null && IncidentTransitionPolicy.canTransition(incident.getStatus(), next)) {
                            responseRepository.updateIncidentStatusAsCoordinator(incidentId, uid, next, callback("Response status updated."));
                        } else Toast.makeText(RespondentCaseDetailActivity.this, "Response status updated.", Toast.LENGTH_SHORT).show();
                    }
                    @Override public void onError(String message) { Toast.makeText(RespondentCaseDetailActivity.this, message, Toast.LENGTH_LONG).show(); }
                });
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private void listen() {
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        incidentRef=db.getReference("emergencies").child(incidentId);
        incidentListener=incidentRef.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){ incident=s.getValue(EmergencyIncident.class); if(incident==null){finish();return;} incident.setId(incidentId); renderIncident(); }
            @Override public void onCancelled(@NonNull DatabaseError e){ toast(e.getMessage()); }
        });
        responseRef=db.getReference("emergencyResponses").child(incidentId).child(uid);
        responseListener=responseRef.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){
                ownResponse=s.getValue(EmergencyResponse.class);
                accepted=ownResponse!=null&&ownResponse.isActive();
                coordinator=accepted&&"COORDINATOR".equalsIgnoreCase(ownResponse.getTeamRole());
                if(accepted) ensureAcceptedListeners(); else stopAcceptedListeners();
                renderAuthorization();
            }
            @Override public void onCancelled(@NonNull DatabaseError e){ toast("Unable to verify your response-team membership. "+e.getMessage()); }
        });
        responsesRef=db.getReference("emergencyResponses").child(incidentId);
        medicalRef=db.getReference("emergencyMedicalSummaries").child(incidentId);
        team.setText("Response team unlocks after server-confirmed acceptance.");
        medical.setText("Medical summary unlocks after server-confirmed acceptance.");
        profileRef=db.getReference("respondents").child(uid);
        profileListener=profileRef.addValueEventListener(new ValueEventListener(){ @Override public void onDataChange(@NonNull DataSnapshot s){responderName=nonBlank(s.child("name").getValue(String.class),responderName);} @Override public void onCancelled(@NonNull DatabaseError e){} });
    }

    private void ensureAcceptedListeners() {
        if (acceptedListenersStarted) return;
        acceptedListenersStarted = true;

        responsesListener=responsesRef.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){
                List<String> names=new ArrayList<>();
                for(DataSnapshot c:s.getChildren()){
                    EmergencyResponse r=c.getValue(EmergencyResponse.class);
                    if(r!=null&&r.isActive()) names.add(nonBlank(r.getResponderName(),"Responder")+" — "+nonBlank(r.getTeamRole(),"SUPPORTING"));
                }
                team.setText(names.isEmpty()?"No respondent has joined yet.":join(names));
            }
            @Override public void onCancelled(@NonNull DatabaseError e){ team.setText("Response-team data is temporarily unavailable."); }
        });

        medicalListener=medicalRef.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){
                StringBuilder b=new StringBuilder();
                append(b,"Blood type",s.child("bloodType").getValue());
                append(b,"Allergies",s.child("allergies").getValue());
                append(b,"Conditions",s.child("conditions").getValue());
                append(b,"Medications",s.child("medications").getValue());
                append(b,"Emergency note",s.child("emergencyNote").getValue());
                medical.setText(b.length()==0?"No permitted medical summary was provided.":b.toString().trim());
            }
            @Override public void onCancelled(@NonNull DatabaseError e){ medical.setText("Medical summary is temporarily unavailable."); }
        });
    }

    private void stopAcceptedListeners() {
        if(responsesRef!=null&&responsesListener!=null) responsesRef.removeEventListener(responsesListener);
        if(medicalRef!=null&&medicalListener!=null) medicalRef.removeEventListener(medicalListener);
        responsesListener=null;
        medicalListener=null;
        acceptedListenersStarted=false;
        trackingRequested=false;
        if(team!=null) team.setText("Response team unlocks after server-confirmed acceptance.");
        if(medical!=null) medical.setText("Medical summary unlocks after server-confirmed acceptance.");
    }

    private void renderIncident() {
        patient.setText(nonBlank(incident.getPatientName(),"HealthMate patient"));
        type.setText(nonBlank(incident.getType(),"Emergency SOS"));
        status.setText("Incident status: "+nonBlank(incident.getStatus(),"PENDING").replace('_',' '));
        Object barangay=incident.getLocationSummary()==null?null:incident.getLocationSummary().get("barangayName");
        location.setText("Limited queue location: "+(barangay==null||String.valueOf(barangay).trim().isEmpty()?nonBlank(incident.getAssignedBarangayId(),"Barangay unavailable"):String.valueOf(barangay)));
        renderAuthorization();
    }

    private void renderAuthorization() {
        boolean own=incident!=null&&uid.equals(incident.getPatientUid());
        accept.setVisibility(accepted?View.GONE:View.VISIBLE); accept.setEnabled(!own&&incident!=null);
        authorization.setText(own?"This is your personal SOS. You cannot accept your own incident.":accepted?(coordinator?"Accepted — you are the response coordinator.":"Accepted — you are a supporting responder."):"Accept this incident to unlock live coordinates, permitted medical data, team actions, and reporting.");
        map.setEnabled(accepted); directory.setEnabled(accepted); report.setEnabled(accepted); call.setEnabled(accepted&&incident!=null&&!safe(incident.getPatientPhone()).isEmpty()); backup.setEnabled(accepted); withdraw.setEnabled(accepted); responseStatus.setEnabled(accepted);
        if (accepted && ownResponse != null) {
            String[] values={"ACCEPTED","RESPONDING","EN_ROUTE","ON_SCENE","AGENCY_CONTACTED","RESCUE_IN_PROGRESS"};
            int position=0; for(int i=0;i<values.length;i++)if(values[i].equalsIgnoreCase(ownResponse.getResponseStatus()))position=i;
            initializingStatus=true; responseStatus.setSelection(position,false); responseStatus.post(()->initializingStatus=false);
            if(!trackingRequested){
                trackingRequested=true;
                requestLocationAndStartTracking();
            }
        }
    }

    private void accept() {
        if (offlineSession) { toast("Reconnect before accepting this SOS incident."); return; }
        if (incident==null) return;
        accept.setEnabled(false);
        responseRepository.accept(incidentId,uid,responderName,new EmergencyResponseRepository.Callback(){
            @Override public void onSuccess(boolean isCoordinator){toast(isCoordinator?"SOS accepted. You are the coordinator.":"SOS accepted. You joined the response team.");}
            @Override public void onError(String message){accept.setEnabled(true);toast(message);}
        });
    }

    private void requestLocationAndStartTracking() {
        if (offlineSession) { toast("Reconnect before sharing response location."); return; }
        boolean fine=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        boolean coarse=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        if(fine||coarse) startResponderTracking(); else locationPermission.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION});
    }
    private void startResponderTracking(){ Intent i=new Intent(this, EmergencyLiveLocationService.class).setAction(EmergencyLiveLocationService.ACTION_START_RESPONDER).putExtra(EmergencyLiveLocationService.EXTRA_INCIDENT_ID,incidentId); ContextCompat.startForegroundService(this,i); }
    private void openMap(){ if(!accepted){toast("Accept this incident before opening exact live coordinates.");return;} startActivity(new Intent(this,EmergencyMapActivity.class).putExtra(EmergencyMapActivity.EXTRA_INCIDENT_ID,incidentId)); }
    private EmergencyResponseRepository.Callback callback(String success){ return new EmergencyResponseRepository.Callback(){@Override public void onSuccess(boolean c){toast(success);}@Override public void onError(String m){toast(m);}}; }
    private void append(StringBuilder b,String label,Object value){if(value!=null&&!String.valueOf(value).trim().isEmpty())b.append(label).append(": ").append(value).append('\n');}
    private String join(List<String> values){StringBuilder b=new StringBuilder();for(String v:values)b.append("• ").append(v).append('\n');return b.toString().trim();}
    private void toast(String value){Toast.makeText(this,value==null?"Operation failed.":value,Toast.LENGTH_LONG).show();}
    private String nonBlank(String value,String fallback){return value==null||value.trim().isEmpty()?fallback:value.trim();}
    private String safe(String value){return value==null?"":value.trim();}

    @Override protected void onDestroy(){
        if(incidentRef!=null&&incidentListener!=null)incidentRef.removeEventListener(incidentListener);
        if(responseRef!=null&&responseListener!=null)responseRef.removeEventListener(responseListener);
        stopAcceptedListeners();
        if(profileRef!=null&&profileListener!=null)profileRef.removeEventListener(profileListener);
        super.onDestroy();
    }
}
