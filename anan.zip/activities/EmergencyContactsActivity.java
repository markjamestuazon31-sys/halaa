package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/** Legacy route kept for compatibility. Contact scanning now lives only in Profile. */
public class EmergencyContactsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        startActivity(new Intent(this,RelationshipRequestsActivity.class));
        finish();
    }
}
