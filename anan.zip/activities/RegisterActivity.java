package com.example.app.activities;

import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.auth.AccountAccess;
import com.example.app.auth.AccountPolicy;
import com.example.app.models.User;
import com.example.app.navigation.RoleRouter;
import com.example.app.repositories.AuthRepository;
import com.example.app.utils.Base64Manager;
import com.example.app.utils.ValidationUtils;

public class RegisterActivity extends AppCompatActivity {

    private EditText name;
    private EditText email;
    private EditText phone;
    private EditText password;
    private EditText confirmPassword;
    private ImageView profileImage;
    private Button register;
    private String imageBase64 = "";

    private final ActivityResultLauncher<String> imagePicker =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    this::loadSelectedImage
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        profileImage = findViewById(R.id.profileImage);
        register = findViewById(R.id.registerBtn);
        TextView loginLink = findViewById(R.id.loginLink);

        profileImage.setOnClickListener(view -> imagePicker.launch("image/*"));
        register.setOnClickListener(view -> createAccount());
        loginLink.setOnClickListener(view -> finish());
    }

    private void loadSelectedImage(Uri uri) {
        if (uri == null) return;

        try {
            Bitmap bitmap;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                bitmap = ImageDecoder.decodeBitmap(
                        ImageDecoder.createSource(getContentResolver(), uri)
                );
            } else {
                //noinspection deprecation
                bitmap = MediaStore.Images.Media.getBitmap(
                        getContentResolver(),
                        uri
                );
            }

            profileImage.setImageBitmap(bitmap);
            imageBase64 = Base64Manager.bitmapToBase64(bitmap);
        } catch (Exception error) {
            Toast.makeText(
                    this,
                    "Unable to read the selected image.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void createAccount() {
        String fullName = name.getText().toString().trim();
        String userEmail = AccountPolicy.normalizeEmail(
                email.getText().toString()
        );
        String userPhone = phone.getText().toString().trim();
        String pass = password.getText().toString();
        String confirm = confirmPassword.getText().toString();

        if (fullName.length() < 2) {
            name.setError("Enter your full name");
            name.requestFocus();
            return;
        }
        if (!ValidationUtils.emailValid(userEmail)) {
            email.setError("Enter a valid email address");
            email.requestFocus();
            return;
        }
        if (userPhone.length() < 7) {
            phone.setError("Enter a valid phone number");
            phone.requestFocus();
            return;
        }
        if (!ValidationUtils.passwordValid(pass)) {
            password.setError(
                    "Use at least 8 characters, one capital letter, and one number"
            );
            password.requestFocus();
            return;
        }
        if (!pass.equals(confirm)) {
            confirmPassword.setError("Passwords do not match");
            confirmPassword.requestFocus();
            return;
        }

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(userEmail);
        user.setPhone(userPhone);
        user.setContactNumber(userPhone);
        user.setAssignedBarangayId("UNASSIGNED");
        user.setProfileImage(imageBase64);

        setLoading(true);
        AuthRepository authRepository = new AuthRepository();
        authRepository.registerUser(
                user,
                pass,
                new AuthRepository.AuthCallback() {
                    @Override
                    public void onSuccess() {
                        if (AccountPolicy.isReservedResponderEmail(userEmail)) {
                            Toast.makeText(
                                    RegisterActivity.this,
                                    "The administrator-authorized respondent account was created. Verify that respondent email before signing in.",
                                    Toast.LENGTH_LONG
                            ).show();
                            finish();
                            return;
                        }

                        /*
                         * A normal registration remains authenticated and routes
                         * directly to the user shell. No verification link is used.
                         */
                        authRepository.validateCurrentSessionWithAccess(
                                new AuthRepository.AccessCallback() {
                                    @Override
                                    public void onSuccess(@NonNull AccountAccess access) {
                                        Toast.makeText(
                                                RegisterActivity.this,
                                                "Your HealthMate user account is ready.",
                                                Toast.LENGTH_SHORT
                                        ).show();
                                        RoleRouter.openHome(
                                                RegisterActivity.this,
                                                access,
                                                null
                                        );
                                    }

                                    @Override
                                    public void onError(String message) {
                                        setLoading(false);
                                        Toast.makeText(
                                                RegisterActivity.this,
                                                message,
                                                Toast.LENGTH_LONG
                                        ).show();
                                    }

                                    @Override
                                    public void onTemporaryError(String message) {
                                        setLoading(false);
                                        Toast.makeText(
                                                RegisterActivity.this,
                                                message,
                                                Toast.LENGTH_LONG
                                        ).show();
                                    }
                                }
                        );
                    }

                    @Override
                    public void onError(String message) {
                        setLoading(false);
                        Toast.makeText(
                                RegisterActivity.this,
                                message,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );
    }

    private void setLoading(boolean loading) {
        register.setEnabled(!loading);
        register.setText(
                loading
                        ? R.string.creating_account
                        : R.string.create_account
        );
    }
}
