package com.example.app.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.models.MedicalQR;
import com.example.app.repositories.MedicalQRRepository;
import com.example.app.utils.MedicalTokenGenerator;
import com.example.app.utils.QRManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MedicalQRActivity extends AppCompatActivity {

    private ImageView qrImage;
    private MedicalQRRepository repository;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_qr);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        userId = currentUser.getUid();
        qrImage = findViewById(R.id.medicalQR);
        repository = new MedicalQRRepository();
        loadOrCreateMedicalQR();
    }

    private void loadOrCreateMedicalQR() {
        repository.getMedicalQR(userId).get()
                .addOnSuccessListener(snapshot -> {
                    MedicalQR existing = snapshot.getValue(MedicalQR.class);
                    if (existing != null && existing.isQrEnabled()
                            && existing.getMedicalToken() != null && !existing.getMedicalToken().trim().isEmpty()) {
                        render(existing.getMedicalToken());
                    } else {
                        createMedicalQR();
                    }
                })
                .addOnFailureListener(error -> Toast.makeText(this, "Unable to load the medical QR code.", Toast.LENGTH_LONG).show());
    }

    private void createMedicalQR() {
        String token = MedicalTokenGenerator.generate();
        MedicalQR medicalQr = new MedicalQR(token, true, System.currentTimeMillis());
        repository.createQR(userId, medicalQr).addOnCompleteListener(task -> {
            if (task.isSuccessful()) render(token);
            else Toast.makeText(this, "Unable to save the medical QR code.", Toast.LENGTH_LONG).show();
        });
    }

    private void render(String token) {
        Bitmap bitmap = QRManager.generateQR(MedicalScannerActivity.MEDICAL_QR_PREFIX + token);
        if (bitmap == null) {
            Toast.makeText(this, "Unable to generate the medical QR code.", Toast.LENGTH_LONG).show();
            return;
        }
        qrImage.setImageBitmap(bitmap);
    }
}
