package com.example.app.activities;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.calls.CallSignalingGate;
import com.example.app.models.CallDescription;
import com.example.app.models.CallIceCandidate;
import com.example.app.models.CallSession;
import com.example.app.repositories.CallRepository;
import com.example.app.services.CallService;
import com.example.app.webrtc.WebRTCManager;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import org.webrtc.IceCandidate;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceViewRenderer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CallActivity extends AppCompatActivity
        implements WebRTCManager.Callback {

    private static final String TAG = "CallActivity";

    private final CallRepository repository = new CallRepository();
    private final CallSignalingGate signalingGate = new CallSignalingGate();
    private final Set<String> consumedCandidateKeys = new HashSet<>();
    private final List<IceCandidate> pendingRemoteCandidates = new ArrayList<>();

    private TextView statusView;
    private TextView subtitleView;
    private TextView videoConnectionStatus;
    private LinearLayout incomingControls;
    private LinearLayout activeControls;
    private MaterialButton answerButton;
    private MaterialButton declineButton;
    private MaterialButton endButton;
    private MaterialButton muteButton;
    private MaterialButton speakerButton;
    private MaterialButton switchCameraButton;
    private SurfaceViewRenderer localVideo;
    private SurfaceViewRenderer remoteVideo;
    private View localVideoContainer;
    private View remoteVideoWaiting;
    private View audioPlaceholder;

    private AudioManager audioManager;
    private WebRTCManager webRTCManager;
    private ValueEventListener callListener;
    private DataSnapshot latestCallSnapshot;
    private Runnable permissionGrantedAction;

    private String currentUserId;
    private String callId;
    private String callerId;
    private String receiverId;
    private String callType = "audio";
    private String localCandidateRole;
    private String remoteCandidateRole;

    private boolean incoming;
    private boolean webRtcStarted;
    private boolean offerPublished;
    private boolean answerPublished;
    private boolean connectedPublished;
    private boolean muted;
    private boolean speakerEnabled;
    private boolean endedLocally;
    private boolean closedByRemote;

    private final ActivityResultLauncher<String[]> mediaPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestMultiplePermissions(),
                    this::onMediaPermissionResult
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);

        if (!HealthMateApplication.isFirebaseReady()) {
            Toast.makeText(
                    this,
                    "Firebase is not configured for this build.",
                    Toast.LENGTH_LONG
            ).show();
            finish();
            return;
        }

        currentUserId = FirebaseAuth.getInstance().getUid();
        if (currentUserId == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        callId = getIntent().getStringExtra("callId");
        receiverId = getIntent().getStringExtra("receiverId");
        callType = normalizeType(getIntent().getStringExtra("callType"));
        incoming = getIntent().getBooleanExtra("incoming", false);

        bindViews();
        configureAudio();
        cancelIncomingCallNotification();

        answerButton.setOnClickListener(view -> acceptIncomingCall());
        declineButton.setOnClickListener(view -> declineIncomingCall());
        endButton.setOnClickListener(view -> endCall("ended"));
        muteButton.setOnClickListener(view -> toggleMute());
        speakerButton.setOnClickListener(view -> toggleSpeaker());
        switchCameraButton.setOnClickListener(view -> {
            if (webRTCManager != null) {
                webRTCManager.switchCamera();
            }
        });

        if (!isBlank(callId)) {
            loadExistingCall();
        } else if (!isBlank(receiverId)) {
            incoming = false;
            callerId = currentUserId;
            prepareUiForActiveCall();
            ensureMediaPermissions(this::startOutgoingCall);
        } else {
            showFatalError("A contact or existing call session is required.");
        }
    }

    private void bindViews() {
        statusView = findViewById(R.id.callStatus);
        subtitleView = findViewById(R.id.callSubtitle);
        videoConnectionStatus = findViewById(R.id.videoConnectionStatus);
        incomingControls = findViewById(R.id.incomingCallControls);
        activeControls = findViewById(R.id.activeCallControls);
        answerButton = findViewById(R.id.answerCall);
        declineButton = findViewById(R.id.declineCall);
        endButton = findViewById(R.id.endCall);
        muteButton = findViewById(R.id.muteCall);
        speakerButton = findViewById(R.id.speakerCall);
        switchCameraButton = findViewById(R.id.switchCamera);
        localVideo = findViewById(R.id.localVideo);
        remoteVideo = findViewById(R.id.remoteVideo);
        localVideoContainer = findViewById(R.id.localVideoContainer);
        remoteVideoWaiting = findViewById(R.id.remoteVideoWaiting);
        audioPlaceholder = findViewById(R.id.audioCallPlaceholder);
    }

    private void configureAudio() {
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        speakerEnabled = "video".equals(callType);

        if (audioManager != null) {
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.setMicrophoneMute(false);
            audioManager.setSpeakerphoneOn(speakerEnabled);
        }

        speakerButton.setText(
                speakerEnabled
                        ? R.string.earpiece
                        : R.string.speaker
        );
    }

    private void cancelIncomingCallNotification() {
        if (isBlank(callId)) {
            return;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.cancel(callId.hashCode());
        }
    }

    private void loadExistingCall() {
        setCallStatus("Loading call…");
        repository.getCall(callId, new CallRepository.CallSnapshotCallback() {
            @Override
            public void onSuccess(DataSnapshot snapshot) {
                latestCallSnapshot = snapshot;
                CallSession call = snapshot.getValue(CallSession.class);
                if (call == null) {
                    showFatalError("This call no longer exists.");
                    return;
                }

                callerId = call.getCallerId();
                receiverId = call.getReceiverId();
                callType = normalizeType(call.getType());

                if (!currentUserId.equals(callerId)
                        && !currentUserId.equals(receiverId)) {
                    showFatalError("You are not a participant in this call.");
                    return;
                }

                if (isTerminalStatus(call.getStatus())) {
                    showFatalError("This call has already ended.");
                    return;
                }

                incoming = currentUserId.equals(receiverId)
                        && "ringing".equalsIgnoreCase(call.getStatus());

                configureAudio();
                attachCallListener();

                if (incoming) {
                    prepareUiForIncomingCall();
                } else {
                    prepareUiForActiveCall();
                    boolean caller = currentUserId.equals(callerId);
                    ensureMediaPermissions(() -> startWebRtc(caller));
                }
            }

            @Override
            public void onError(String message) {
                showFatalError(
                        isBlank(message)
                                ? "Unable to load the call."
                                : message
                );
            }
        });
    }

    private void startOutgoingCall() {
        setCallStatus("Calling…");

        CallRepository.CreateCallCallback callback =
                new CallRepository.CreateCallCallback() {
                    @Override
                    public void onSuccess(String id) {
                        callId = id;
                        localCandidateRole = "caller";
                        remoteCandidateRole = "receiver";
                        attachCallListener();
                        startWebRtc(true);
                    }

                    @Override
                    public void onError(String message) {
                        showFatalError(
                                isBlank(message)
                                        ? "Unable to start the call."
                                        : message
                        );
                    }
                };

        CallService service = new CallService();
        if ("video".equals(callType)) {
            service.startVideoCall(currentUserId, receiverId, callback);
        } else {
            service.startVoiceCall(currentUserId, receiverId, callback);
        }
    }

    private void prepareUiForIncomingCall() {
        setCallStatus(
                "Incoming "
                        + ("video".equals(callType) ? "video" : "voice")
                        + " call"
        );
        subtitleView.setText("Answer only if you recognize this contact");
        incomingControls.setVisibility(View.VISIBLE);
        activeControls.setVisibility(View.GONE);
        endButton.setVisibility(View.GONE);
        localVideoContainer.setVisibility(View.GONE);
        remoteVideo.setVisibility(View.GONE);
        remoteVideoWaiting.setVisibility(View.GONE);
        audioPlaceholder.setVisibility(View.VISIBLE);
    }

    private void prepareUiForActiveCall() {
        boolean video = "video".equals(callType);

        incomingControls.setVisibility(View.GONE);
        activeControls.setVisibility(View.VISIBLE);
        endButton.setVisibility(View.VISIBLE);
        switchCameraButton.setVisibility(video ? View.VISIBLE : View.GONE);

        localVideoContainer.setVisibility(video ? View.VISIBLE : View.GONE);
        localVideo.setVisibility(video ? View.VISIBLE : View.GONE);
        remoteVideo.setVisibility(video ? View.VISIBLE : View.GONE);
        remoteVideoWaiting.setVisibility(video ? View.VISIBLE : View.GONE);
        audioPlaceholder.setVisibility(video ? View.GONE : View.VISIBLE);

        setCallStatus(incoming ? "Connecting…" : "Calling…");
        subtitleView.setText(
                video
                        ? "HealthMate secure video call"
                        : "HealthMate secure voice call"
        );
    }

    private void acceptIncomingCall() {
        answerButton.setEnabled(false);
        setCallStatus("Preparing secure media…");

        /*
         * Permission must be granted before the call is marked accepted.
         * Otherwise Firebase can deliver the offer while WebRTC is not ready,
         * leaving the caller permanently on "Offer created".
         */
        ensureMediaPermissions(() -> {
            prepareUiForActiveCall();
            startWebRtc(false);
            repository.updateStatus(
                    callId,
                    "accepted",
                    new SimpleCompletion("Connecting…")
            );
        });
    }

    private void declineIncomingCall() {
        endedLocally = true;
        repository.updateStatus(callId, "rejected");
        finish();
    }

    private void ensureMediaPermissions(Runnable onGranted) {
        permissionGrantedAction = onGranted;
        List<String> required = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
        ) != PackageManager.PERMISSION_GRANTED) {
            required.add(Manifest.permission.RECORD_AUDIO);
        }

        if ("video".equals(callType)
                && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
        ) != PackageManager.PERMISSION_GRANTED) {
            required.add(Manifest.permission.CAMERA);
        }

        if (required.isEmpty()) {
            permissionGrantedAction = null;
            onGranted.run();
        } else {
            mediaPermissionLauncher.launch(required.toArray(new String[0]));
        }
    }

    private void onMediaPermissionResult(Map<String, Boolean> result) {
        boolean audioGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED;

        boolean cameraGranted = !"video".equals(callType)
                || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED;

        Runnable action = permissionGrantedAction;
        permissionGrantedAction = null;

        if (audioGranted && cameraGranted && action != null) {
            action.run();
        } else {
            answerButton.setEnabled(true);
            showCallError(
                    "Microphone permission is required, and camera permission "
                            + "is required for video calls."
            );
        }
    }

    private void startWebRtc(boolean caller) {
        if (webRtcStarted) {
            processLatestSignalingState();
            return;
        }

        webRtcStarted = true;
        localCandidateRole = caller ? "caller" : "receiver";
        remoteCandidateRole = caller ? "receiver" : "caller";

        webRTCManager = new WebRTCManager(this, this);
        webRTCManager.start(
                "video".equals(callType),
                localVideo,
                remoteVideo
        );
        signalingGate.markPeerReady();

        if (caller) {
            createAndPublishOffer();
        }

        /*
         * Re-process the last Firebase snapshot because it may have arrived
         * while a permission dialog was still open and webRtcStarted was false.
         */
        processLatestSignalingState();
        refreshSignalingStateFromDatabase();
    }

    private void createAndPublishOffer() {
        if (offerPublished || webRTCManager == null) {
            return;
        }
        offerPublished = true;

        webRTCManager.createOffer(new WebRTCManager.DescriptionCallback() {
            @Override
            public void onSuccess(SessionDescription description) {
                repository.setOffer(
                        callId,
                        description,
                        new CallRepository.CompletionCallback() {
                            @Override
                            public void onSuccess() {
                                runOnUiThread(
                                        () -> setCallStatus(
                                                "Waiting for answer…"
                                        )
                                );
                            }

                            @Override
                            public void onError(String message) {
                                offerPublished = false;
                                runOnUiThread(
                                        () -> showCallError(message)
                                );
                            }
                        }
                );
            }

            @Override
            public void onError(String message) {
                offerPublished = false;
                runOnUiThread(() -> showCallError(message));
            }
        });
    }

    private void createAndPublishAnswer() {
        if (answerPublished || webRTCManager == null) {
            return;
        }
        answerPublished = true;

        webRTCManager.createAnswer(new WebRTCManager.DescriptionCallback() {
            @Override
            public void onSuccess(SessionDescription description) {
                repository.setAnswer(
                        callId,
                        description,
                        new CallRepository.CompletionCallback() {
                            @Override
                            public void onSuccess() {
                                runOnUiThread(
                                        () -> setCallStatus("Connecting…")
                                );
                            }

                            @Override
                            public void onError(String message) {
                                answerPublished = false;
                                runOnUiThread(
                                        () -> showCallError(message)
                                );
                            }
                        }
                );
            }

            @Override
            public void onError(String message) {
                answerPublished = false;
                runOnUiThread(() -> showCallError(message));
            }
        });
    }

    private void attachCallListener() {
        if (callListener != null || isBlank(callId)) {
            return;
        }

        callListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                latestCallSnapshot = snapshot;

                if (!snapshot.exists()) {
                    closedByRemote = true;
                    showFatalError("This call was removed.");
                    return;
                }

                String callStatus = snapshot.child("status").getValue(String.class);
                if (isTerminalStatus(callStatus)) {
                    if (!endedLocally) {
                        closedByRemote = true;
                        Toast.makeText(
                                CallActivity.this,
                                "The call has ended.",
                                Toast.LENGTH_SHORT
                        ).show();
                        finish();
                    }
                    return;
                }

                if ("connected".equalsIgnoreCase(callStatus)) {
                    setCallStatus("Connected");
                } else if ("accepted".equalsIgnoreCase(callStatus)) {
                    setCallStatus("Connecting…");
                }

                processSignalingSnapshot(snapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                showCallError(error.getMessage());
            }
        };

        repository.listenCall(callId, callListener);
    }

    private void processLatestSignalingState() {
        if (latestCallSnapshot != null) {
            processSignalingSnapshot(latestCallSnapshot);
        }
    }

    private void refreshSignalingStateFromDatabase() {
        if (isBlank(callId)) {
            return;
        }

        repository.getCall(callId, new CallRepository.CallSnapshotCallback() {
            @Override
            public void onSuccess(DataSnapshot snapshot) {
                latestCallSnapshot = snapshot;
                processSignalingSnapshot(snapshot);
            }

            @Override
            public void onError(String message) {
                Log.w(TAG, "Unable to refresh signaling state: " + message);
            }
        });
    }

    private void processSignalingSnapshot(DataSnapshot snapshot) {
        if (!webRtcStarted
                || webRTCManager == null
                || snapshot == null
                || isBlank(remoteCandidateRole)) {
            return;
        }

        boolean receiver = currentUserId.equals(receiverId);
        CallDescription remoteDescription = snapshot
                .child(receiver ? "offer" : "answer")
                .getValue(CallDescription.class);

        boolean descriptionAvailable = remoteDescription != null
                && !isBlank(remoteDescription.getType())
                && !isBlank(remoteDescription.getSdp());

        if (signalingGate.shouldStartRemoteDescription(descriptionAvailable)) {
            signalingGate.markRemoteDescriptionPending();
            setRemoteDescription(remoteDescription, receiver);
        }

        consumeRemoteCandidates(
                snapshot.child("iceCandidates").child(remoteCandidateRole)
        );
    }

    private void setRemoteDescription(
            CallDescription value,
            boolean createAnswerAfter
    ) {
        if (webRTCManager == null
                || value == null
                || isBlank(value.getSdp())
                || isBlank(value.getType())) {
            signalingGate.markRemoteDescriptionFailed();
            return;
        }

        SessionDescription.Type type;
        try {
            type = SessionDescription.Type.fromCanonicalForm(value.getType());
        } catch (IllegalArgumentException error) {
            signalingGate.markRemoteDescriptionFailed();
            showCallError("The remote call description is invalid.");
            return;
        }

        webRTCManager.setRemoteDescription(
                new SessionDescription(type, value.getSdp()),
                new WebRTCManager.OperationCallback() {
                    @Override
                    public void onSuccess() {
                        runOnUiThread(() -> {
                            signalingGate.markRemoteDescriptionSet();

                            List<IceCandidate> candidatesToApply =
                                    new ArrayList<>(pendingRemoteCandidates);
                            pendingRemoteCandidates.clear();

                            for (IceCandidate candidate : candidatesToApply) {
                                if (webRTCManager != null) {
                                    webRTCManager.addRemoteIceCandidate(
                                            candidate
                                    );
                                }
                            }

                            if (createAnswerAfter) {
                                createAndPublishAnswer();
                            }
                        });
                    }

                    @Override
                    public void onError(String message) {
                        runOnUiThread(() -> {
                            signalingGate.markRemoteDescriptionFailed();
                            showCallError(message);
                        });
                    }
                }
        );
    }

    private void consumeRemoteCandidates(DataSnapshot candidatesSnapshot) {
        if (candidatesSnapshot == null) {
            return;
        }

        for (DataSnapshot child : candidatesSnapshot.getChildren()) {
            String key = child.getKey();
            String candidateIdentity = remoteCandidateRole + ":" + key;

            if (key == null || !consumedCandidateKeys.add(candidateIdentity)) {
                continue;
            }

            CallIceCandidate value = child.getValue(CallIceCandidate.class);
            if (value == null || isBlank(value.getSdp())) {
                continue;
            }

            IceCandidate candidate = new IceCandidate(
                    value.getSdpMid(),
                    value.getSdpMLineIndex(),
                    value.getSdp()
            );

            if (signalingGate.canApplyRemoteCandidates()
                    && webRTCManager != null) {
                webRTCManager.addRemoteIceCandidate(candidate);
            } else {
                pendingRemoteCandidates.add(candidate);
            }
        }
    }

    private void toggleMute() {
        muted = !muted;
        if (webRTCManager != null) {
            webRTCManager.setMuted(muted);
        }
        muteButton.setText(muted ? R.string.unmute : R.string.mute);
    }

    private void toggleSpeaker() {
        speakerEnabled = !speakerEnabled;
        if (audioManager != null) {
            audioManager.setSpeakerphoneOn(speakerEnabled);
        }
        speakerButton.setText(
                speakerEnabled
                        ? R.string.earpiece
                        : R.string.speaker
        );
    }

    private void endCall(String finalStatus) {
        if (endedLocally) {
            return;
        }
        endedLocally = true;
        if (!isBlank(callId)) {
            repository.updateStatus(callId, finalStatus);
        }
        finish();
    }

    private void showFatalError(String message) {
        setCallStatus(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        endButton.setVisibility(View.VISIBLE);
        endButton.setText(R.string.end_call);
        endButton.setOnClickListener(view -> finish());
    }

    private void showCallError(String message) {
        String safeMessage = isBlank(message)
                ? "The call encountered an error."
                : message;
        setCallStatus("Connection problem");
        Toast.makeText(this, safeMessage, Toast.LENGTH_LONG).show();
    }

    private void setCallStatus(String status) {
        if (statusView != null) {
            statusView.setText(status);
        }
        if (videoConnectionStatus != null) {
            videoConnectionStatus.setText(status);
        }
    }

    private String normalizeType(String value) {
        return "video".equalsIgnoreCase(value) ? "video" : "audio";
    }

    private boolean isTerminalStatus(String status) {
        return "ended".equalsIgnoreCase(status)
                || "rejected".equalsIgnoreCase(status)
                || "missed".equalsIgnoreCase(status);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    @Override
    public void onLocalIceCandidate(IceCandidate candidate) {
        repository.addIceCandidate(
                callId,
                localCandidateRole,
                candidate,
                new CallRepository.CompletionCallback() {
                    @Override
                    public void onSuccess() {
                        // Candidate published successfully.
                    }

                    @Override
                    public void onError(String message) {
                        Log.e(TAG, "Unable to publish ICE candidate: " + message);
                    }
                }
        );
    }

    @Override
    public void onConnectionStateChanged(String state) {
        runOnUiThread(() -> {
            if ("CONNECTED".equals(state) || "COMPLETED".equals(state)) {
                setCallStatus("Connected");
                if (!connectedPublished && !isBlank(callId)) {
                    connectedPublished = true;
                    repository.updateStatus(callId, "connected");
                }
            } else if ("CHECKING".equals(state)
                    || "CONNECTING".equals(state)) {
                setCallStatus("Securing connection…");
            } else if ("DISCONNECTED".equals(state)) {
                setCallStatus("Reconnecting…");
            } else if ("FAILED".equals(state)) {
                setCallStatus("Unable to connect");
                Toast.makeText(
                        this,
                        "The peer connection failed. Verify both devices have "
                                + "internet access and configure a TURN server "
                                + "for calls across restricted networks.",
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    @Override
    public void onRemoteVideoAvailable() {
        runOnUiThread(() -> {
            if (!"video".equals(callType)) {
                return;
            }
            remoteVideoWaiting.setVisibility(View.GONE);
            remoteVideo.setVisibility(View.VISIBLE);
            setCallStatus("Connected");
        });
    }

    @Override
    public void onError(String message) {
        runOnUiThread(() -> showCallError(message));
    }

    @Override
    protected void onDestroy() {
        if (!isBlank(callId) && callListener != null) {
            repository.stopListening(callId, callListener);
        }

        if (webRTCManager != null) {
            webRTCManager.close();
            webRTCManager = null;
        }

        if (audioManager != null) {
            audioManager.setSpeakerphoneOn(false);
            audioManager.setMicrophoneMute(false);
            audioManager.setMode(AudioManager.MODE_NORMAL);
        }

        if (!isChangingConfigurations()
                && !isBlank(callId)
                && !endedLocally
                && !closedByRemote) {
            repository.updateStatus(callId, "ended");
        }

        super.onDestroy();
    }

    private final class SimpleCompletion
            implements CallRepository.CompletionCallback {

        private final String successStatus;

        private SimpleCompletion(String successStatus) {
            this.successStatus = successStatus;
        }

        @Override
        public void onSuccess() {
            runOnUiThread(() -> setCallStatus(successStatus));
        }

        @Override
        public void onError(String message) {
            runOnUiThread(() -> showCallError(message));
        }
    }
}
