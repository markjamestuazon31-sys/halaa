package com.example.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.adapters.EmergencyIncidentAdapter;
import com.example.app.emergency.ResponderAvailability;
import com.example.app.models.EmergencyIncident;
import com.example.app.repositories.EmergencyIncidentRepository;
import com.example.app.repositories.EmergencyResponseRepository;
import com.example.app.repositories.ResponderPresenceRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Respondent-only active SOS queue and availability workspace. */
public class RespondentCasesActivity extends AppCompatActivity {
    private final EmergencyIncidentRepository incidentRepository = new EmergencyIncidentRepository();
    private final EmergencyResponseRepository responseRepository = new EmergencyResponseRepository();
    private final ResponderPresenceRepository presenceRepository = new ResponderPresenceRepository();
    private final List<EmergencyIncident> incidents = new ArrayList<>();
    private final Set<String> acceptedIds = new HashSet<>();

    private EmergencyIncidentAdapter adapter;
    private TextView activeCount;
    private TextView acceptedCount;
    private TextView empty;
    private Spinner availability;
    private String uid;
    private String respondentName = "HealthMate respondent";
    private DatabaseReference responseReference;
    private DatabaseReference profileReference;
    private ValueEventListener responseListener;
    private ValueEventListener profileListener;
    private boolean initializingAvailability = true;
    private boolean offlineSession;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_respondent_cases);
        offlineSession = getIntent().getBooleanExtra(MainActivity.EXTRA_OFFLINE_SESSION, false);
        uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        findViewById(R.id.respondentCasesBack).setOnClickListener(v -> finish());
        activeCount = findViewById(R.id.respondentActiveCount);
        acceptedCount = findViewById(R.id.respondentAcceptedCount);
        empty = findViewById(R.id.respondentCasesEmpty);
        availability = findViewById(R.id.respondentAvailability);
        RecyclerView list = findViewById(R.id.respondentCasesList);
        adapter = new EmergencyIncidentAdapter(new EmergencyIncidentAdapter.Listener() {
            @Override public void onAccept(EmergencyIncident incident) { acceptIncident(incident); }
            @Override public void onOpen(EmergencyIncident incident, boolean accepted) { openIncident(incident, accepted); }
        });
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        configureAvailability();
        availability.setEnabled(!offlineSession);
        listenProfile();
        listenResponses();
        listenIncidents();
    }

    private void configureAvailability() {
        String[] values = {"AVAILABLE", "BUSY", "OFF_DUTY"};
        availability.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
        availability.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (initializingAvailability) return;
                ResponderAvailability value = ResponderAvailability.valueOf(String.valueOf(parent.getItemAtPosition(position)));
                presenceRepository.setAvailability(uid, value, new ResponderPresenceRepository.Callback() {
                    @Override public void onSuccess() { Toast.makeText(RespondentCasesActivity.this, "Availability updated.", Toast.LENGTH_SHORT).show(); }
                    @Override public void onError(String message) { Toast.makeText(RespondentCasesActivity.this, message, Toast.LENGTH_LONG).show(); }
                });
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private void listenProfile() {
        profileReference = FirebaseDatabase.getInstance().getReference("respondents").child(uid);
        profileListener = profileReference.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name = snapshot.child("name").getValue(String.class);
                if (name != null && !name.trim().isEmpty()) respondentName = name.trim();
                String value = snapshot.child("availability").getValue(String.class);
                if (value == null || value.trim().isEmpty()) value = "AVAILABLE";
                int selected = "BUSY".equals(value) ? 1 : "OFF_DUTY".equals(value) ? 2 : 0;
                initializingAvailability = true;
                availability.setSelection(selected, false);
                availability.post(() -> initializingAvailability = false);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { initializingAvailability = false; }
        });
    }

    private void listenResponses() {
        responseReference = FirebaseDatabase.getInstance().getReference("emergencyResponses");
        responseListener = responseReference.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                acceptedIds.clear();
                for (DataSnapshot incident : snapshot.getChildren()) {
                    Boolean active = incident.child(uid).child("active").getValue(Boolean.class);
                    if (Boolean.TRUE.equals(active) && incident.getKey() != null) acceptedIds.add(incident.getKey());
                }
                render();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void listenIncidents() {
        incidentRepository.listenActiveIncidents(new EmergencyIncidentRepository.IncidentListener() {
            @Override public void onChanged(List<EmergencyIncident> values) {
                incidents.clear(); incidents.addAll(values); render();
            }
            @Override public void onError(String message) {
                empty.setVisibility(View.VISIBLE); empty.setText(message == null ? "Unable to load SOS cases." : message);
            }
        });
    }

    private void render() {
        activeCount.setText(String.valueOf(incidents.size()));
        acceptedCount.setText(String.valueOf(acceptedIds.size()));
        empty.setVisibility(incidents.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.submit(incidents, acceptedIds, uid);
    }

    private void acceptIncident(EmergencyIncident incident) {
        if (offlineSession) { Toast.makeText(this, "Reconnect before accepting an SOS incident.", Toast.LENGTH_LONG).show(); return; }
        if (incident == null || incident.getId() == null) return;
        adapter.setBusy(incident.getId());
        responseRepository.accept(incident.getId(), uid, respondentName, new EmergencyResponseRepository.Callback() {
            @Override public void onSuccess(boolean coordinator) {
                adapter.setBusy("");
                Toast.makeText(RespondentCasesActivity.this, coordinator ? "SOS accepted. You are the response coordinator." : "SOS accepted. You joined the response team.", Toast.LENGTH_LONG).show();
                openIncident(incident, true);
            }
            @Override public void onError(String message) { adapter.setBusy(""); Toast.makeText(RespondentCasesActivity.this, message, Toast.LENGTH_LONG).show(); }
        });
    }

    private void openIncident(EmergencyIncident incident, boolean accepted) {
        Intent intent = new Intent(this, RespondentCaseDetailActivity.class);
        intent.putExtra(RespondentCaseDetailActivity.EXTRA_INCIDENT_ID, incident.getId());
        intent.putExtra(RespondentCaseDetailActivity.EXTRA_ACCEPTED_HINT, accepted);
        intent.putExtra(MainActivity.EXTRA_OFFLINE_SESSION, offlineSession);
        startActivity(intent);
    }

    @Override protected void onDestroy() {
        incidentRepository.stopListening();
        if (responseReference != null && responseListener != null) responseReference.removeEventListener(responseListener);
        if (profileReference != null && profileListener != null) profileReference.removeEventListener(profileListener);
        super.onDestroy();
    }
}
