package com.example.app.contacts;

import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public final class ContactQrPayloadCodec {
    public static final int VERSION = 1;
    private static final String SCHEME = "healthmate";
    private static final String HOST = "contact";

    private ContactQrPayloadCodec() { }

    public static String encode(String uid, String token) {
        require(uid, "UID");
        require(token, "token");
        return SCHEME + "://" + HOST + "?v=" + VERSION
                + "&uid=" + url(uid.trim())
                + "&token=" + url(token.trim());
    }

    public static Payload decode(String raw) {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("QR code is empty.");
        try {
            URI uri = URI.create(raw.trim());
            if (!SCHEME.equalsIgnoreCase(uri.getScheme()) || !HOST.equalsIgnoreCase(uri.getHost())) {
                throw new IllegalArgumentException("This is not a HealthMate contact QR code.");
            }
            Map<String, String> values = parseQuery(uri.getRawQuery());
            int version = Integer.parseInt(values.getOrDefault("v", "0"));
            if (version != VERSION) throw new IllegalArgumentException("This HealthMate QR version is not supported.");
            String uid = values.get("uid");
            String token = values.get("token");
            require(uid, "UID");
            require(token, "token");
            return new Payload(version, uid.trim(), token.trim());
        } catch (IllegalArgumentException error) {
            throw error;
        } catch (RuntimeException error) {
            throw new IllegalArgumentException("The QR code is malformed.", error);
        }
    }

    private static Map<String, String> parseQuery(String raw) {
        Map<String, String> out = new HashMap<>();
        if (raw == null) return out;
        for (String item : raw.split("&")) {
            int split = item.indexOf('=');
            if (split <= 0) continue;
            out.put(decodeValue(item.substring(0, split)), decodeValue(item.substring(split + 1)));
        }
        return out;
    }

    private static String url(String value) { return URLEncoder.encode(value, StandardCharsets.UTF_8); }
    private static String decodeValue(String value) { return URLDecoder.decode(value, StandardCharsets.UTF_8); }
    private static void require(String value, String label) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Contact " + label + " is missing.");
    }

    public static final class Payload {
        private final int version;
        private final String uid;
        private final String token;
        public Payload(int version, String uid, String token) { this.version = version; this.uid = uid; this.token = token; }
        public int getVersion() { return version; }
        public String getUid() { return uid; }
        public String getToken() { return token; }
    }
}
