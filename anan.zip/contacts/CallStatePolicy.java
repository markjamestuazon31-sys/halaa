package com.example.app.contacts;

import java.util.Set;

public final class CallStatePolicy {
    private static final Set<String> TERMINAL = Set.of("DECLINED", "MISSED", "ENDED");
    private CallStatePolicy() { }
    public static boolean isExpired(long createdAt, long expiresAt, long now) {
        long deadline = expiresAt > 0 ? expiresAt : createdAt + 45_000L;
        return deadline > 0 && now >= deadline;
    }
    public static boolean isTerminal(String status) { return TERMINAL.contains(normalize(status)); }
    public static boolean canTransition(String from, String to) {
        String a = normalize(from), b = normalize(to);
        if (a.equals(b)) return true;
        if ("RINGING".equals(a)) return Set.of("ACCEPTED", "DECLINED", "MISSED", "ENDED").contains(b);
        if ("ACCEPTED".equals(a)) return "ENDED".equals(b);
        return false;
    }
    public static String normalize(String value) { return value == null ? "" : value.trim().toUpperCase(); }
}
