package com.example.app.contacts;

public final class LocationAuthorizationPolicy {
    private LocationAuthorizationPolicy() { }

    public static boolean effectiveFamilySharing(boolean savedPreference, boolean activeSos) {
        return activeSos || savedPreference;
    }

    public static boolean canView(
            String relationshipType,
            String relationshipStatus,
            boolean savedFamilyPreference,
            boolean activeSos,
            boolean explicitFriendGrant
    ) {
        if (!RelationshipPolicy.ACCEPTED.equals(RelationshipPolicy.normalize(relationshipStatus))) return false;
        String type = RelationshipPolicy.normalize(relationshipType);
        if (RelationshipPolicy.FAMILY.equals(type)) return effectiveFamilySharing(savedFamilyPreference, activeSos);
        return RelationshipPolicy.FRIEND.equals(type) && explicitFriendGrant;
    }
}
