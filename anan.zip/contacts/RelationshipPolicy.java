package com.example.app.contacts;

public final class RelationshipPolicy {
    public static final String FAMILY = "FAMILY";
    public static final String FRIEND = "FRIEND";
    public static final String PENDING = "PENDING";
    public static final String ACCEPTED = "ACCEPTED";
    public static final String REJECTED = "REJECTED";
    public static final String CANCELLED = "CANCELLED";
    public static final String BLOCKED = "BLOCKED";
    public static final String REMOVED = "REMOVED";

    private RelationshipPolicy() { }

    public static boolean validType(String type) { return FAMILY.equals(normalize(type)) || FRIEND.equals(normalize(type)); }
    public static boolean canAccept(String status) { return PENDING.equals(normalize(status)); }
    public static boolean canMessage(String status, boolean canMessage) { return ACCEPTED.equals(normalize(status)) && canMessage; }
    public static boolean canCall(String status, boolean canCall) { return ACCEPTED.equals(normalize(status)) && canCall; }
    public static String normalize(String value) { return value == null ? "" : value.trim().toUpperCase(); }
}
