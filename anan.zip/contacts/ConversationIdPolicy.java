package com.example.app.contacts;

public final class ConversationIdPolicy {
    private ConversationIdPolicy() { }
    public static String between(String first, String second) {
        if (blank(first) || blank(second) || first.trim().equals(second.trim())) {
            throw new IllegalArgumentException("Two different participant UIDs are required.");
        }
        String a = first.trim(); String b = second.trim();
        return a.compareTo(b) < 0 ? a + "_" + b : b + "_" + a;
    }
    private static boolean blank(String value) { return value == null || value.trim().isEmpty(); }
}
