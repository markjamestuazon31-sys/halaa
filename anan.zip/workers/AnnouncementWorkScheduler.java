package com.example.app.workers;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class AnnouncementWorkScheduler {

    private static final String PERIODIC_WORK =
            "healthmate_announcement_periodic_sync";
    private static final String IMMEDIATE_WORK =
            "healthmate_announcement_immediate_sync";

    private AnnouncementWorkScheduler() {
    }

    public static void schedule(Context context) {
        Constraints constraints =
                new Constraints.Builder()
                        .setRequiredNetworkType(
                                NetworkType.CONNECTED
                        )
                        .build();

        PeriodicWorkRequest periodicRequest =
                new PeriodicWorkRequest.Builder(
                        AnnouncementSyncWorker.class,
                        15,
                        TimeUnit.MINUTES
                )
                        .setConstraints(constraints)
                        .build();

        OneTimeWorkRequest immediateRequest =
                new OneTimeWorkRequest.Builder(
                        AnnouncementSyncWorker.class
                )
                        .setConstraints(constraints)
                        .build();

        WorkManager manager =
                WorkManager.getInstance(context);
        manager.enqueueUniquePeriodicWork(
                PERIODIC_WORK,
                ExistingPeriodicWorkPolicy.UPDATE,
                periodicRequest
        );
        manager.enqueueUniqueWork(
                IMMEDIATE_WORK,
                ExistingWorkPolicy.REPLACE,
                immediateRequest
        );
    }
}
