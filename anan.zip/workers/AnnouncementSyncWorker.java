package com.example.app.workers;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.app.models.Announcement;
import com.example.app.services.AnnouncementDelivery;
import com.example.app.utils.AnnouncementSeenStore;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.concurrent.TimeUnit;

public class AnnouncementSyncWorker extends Worker {

    public AnnouncementSyncWorker(
            @NonNull Context appContext,
            @NonNull WorkerParameters workerParams
    ) {
        super(appContext, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        String userId =
                FirebaseAuth.getInstance().getUid();
        if (userId == null
                || userId.trim().isEmpty()) {
            return Result.success();
        }

        long cutoff =
                AnnouncementSeenStore.getOrCreateCutoff(
                        getApplicationContext(),
                        userId
                );
        Query query =
                FirebaseDatabase.getInstance()
                        .getReference("announcements")
                        .orderByChild("createdAt")
                        .startAt((double) cutoff)
                        .limitToLast(100);

        try {
            DataSnapshot snapshot =
                    Tasks.await(
                            query.get(),
                            25,
                            TimeUnit.SECONDS
                    );
            for (DataSnapshot child :
                    snapshot.getChildren()) {
                Announcement announcement =
                        child.getValue(
                                Announcement.class
                        );
                if (announcement == null) continue;
                announcement.setId(child.getKey());
                AnnouncementDelivery.deliver(
                        getApplicationContext(),
                        userId,
                        announcement
                );
            }
            return Result.success();
        } catch (Exception exception) {
            return Result.retry();
        }
    }
}
