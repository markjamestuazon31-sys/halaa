package com.example.app.navigation;

import android.app.Activity;
import android.content.Intent;

import com.example.app.MainActivity;
import com.example.app.auth.AccountAccess;
import com.example.app.repositories.ContactQrRepository;

/** Routes a server-verified persistent Firebase session to the role-aware Android shell. */
public final class RoleRouter {
    private RoleRouter() { }

    public static void openHome(Activity activity, AccountAccess access, String warning) {
        if (access != null && access.getProfile() != null) new ContactQrRepository().syncPublicProfile(access.getProfile());
        Intent intent = new Intent(activity, MainActivity.class);
        intent.putExtra(MainActivity.EXTRA_ROLE, access.getRole());
        intent.putExtra(MainActivity.EXTRA_OFFLINE_SESSION, access.isOffline());
        if (warning != null && !warning.trim().isEmpty()) intent.putExtra(MainActivity.EXTRA_SESSION_WARNING, warning);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        activity.startActivity(intent);
        activity.finish();
    }
}
