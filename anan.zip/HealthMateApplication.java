package com.example.app;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.util.Log;

import com.example.app.services.AnnouncementNotificationHelper;
import com.example.app.services.AnnouncementRealtimeManager;
import com.example.app.services.FcmTokenRegistrar;
import com.example.app.services.MedicationReminderService;
import com.example.app.notifications.NotificationChannelManager;
import com.example.app.utils.MedicationAlarmScheduler;
import com.example.app.workers.AnnouncementWorkScheduler;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.FirebaseDatabase;

import org.maplibre.android.MapLibre;

public class HealthMateApplication extends Application {

    public static final String EMERGENCY_CHANNEL_ID = NotificationChannelManager.CHANNEL_URGENT;
    public static final String GENERAL_CHANNEL_ID = "healthmate_general";
    public static final String CALL_CHANNEL_ID = "healthmate_calls";
    public static final String MEDICATION_CHANNEL_ID = "healthmate_medication_reminders";
    public static final String ANNOUNCEMENT_CHANNEL_ID = "healthmate_announcements";
    public static final String ACTIVE_CHANNEL_ID = "healthmate_active_service";
    public static final String MESSAGE_CHANNEL_ID = "healthmate_messages";

    private static final String TAG = "HealthMateApplication";
    private static HealthMateApplication instance;
    private static boolean firebaseReady;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        firebaseReady = initializeFirebase();
        NotificationChannelManager.ensureCreated(this);
        createNotificationChannels();
        MedicationReminderService.createChannel(this);
        AnnouncementNotificationHelper.createChannel(this);
        MapLibre.getInstance(this);

        if (firebaseReady) {
            FcmTokenRegistrar.registerCurrentToken(this);
            AnnouncementRealtimeManager.start(this);
            AnnouncementWorkScheduler.schedule(this);
            FirebaseAuth.getInstance().addAuthStateListener(auth -> {
                String userId = auth.getUid();
                if (userId != null && !userId.trim().isEmpty()) {
                    FcmTokenRegistrar.registerCurrentToken(this);
                    MedicationAlarmScheduler.rescheduleStoredReminders(this, userId);
                    configureUserScopedSync(FirebaseDatabase.getInstance(), userId);
                }
            });
        }
    }

    private boolean initializeFirebase() {
        try {
            FirebaseApp app = FirebaseApp.getApps(this).isEmpty()
                    ? FirebaseApp.initializeApp(this)
                    : FirebaseApp.getInstance();
            if (app == null) {
                Log.e(TAG, "Firebase initialization returned no default app. Check app/google-services.json.");
                return false;
            }
            configureRealtimeDatabase();
            return true;
        } catch (RuntimeException error) {
            Log.e(TAG, "Firebase initialization failed. Check app/google-services.json.", error);
            return false;
        }
    }

    private void configureRealtimeDatabase() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        try {
            database.setPersistenceEnabled(true);
        } catch (DatabaseException error) {
            Log.w(TAG, "Realtime Database persistence was already configured.", error);
        }

        keepSynced(database, "announcements");
        keepSynced(database, "emergencies");
        keepSynced(database, "emergencyResponses");
        keepSynced(database, "barangays");
        keepSynced(database, "globalEmergencyContacts");
    }

    private void configureUserScopedSync(FirebaseDatabase database, String userId) {
        keepSynced(database, "locationSharingPreferences/" + userId);
        keepSynced(database, "userPresence/" + userId);
        keepSynced(database, "incomingCalls/" + userId);
        keepSynced(database, "userConversations/" + userId);
        keepSynced(database, "relationshipRequests/" + userId);
        keepSynced(database, "relationships/" + userId);
        keepSynced(database, "contactQrTokens/" + userId);
        keepSynced(database, "liveLocations/" + userId);
        keepSynced(database, "notifications/" + userId);
        keepSynced(database, "emergencyRecipientIndex/" + userId);
    }

    private void keepSynced(FirebaseDatabase database, String path) {
        try {
            database.getReference(path).keepSynced(true);
        } catch (DatabaseException error) {
            Log.w(TAG, "Unable to keep " + path + " synchronized.", error);
        }
    }

    private void createNotificationChannels() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;

        NotificationChannel general = new NotificationChannel(
                GENERAL_CHANNEL_ID,
                "HealthMate notifications",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        general.setDescription("Messages, reminders, and account updates");

        NotificationChannel calls = new NotificationChannel(
                CALL_CHANNEL_ID,
                "Incoming calls",
                NotificationManager.IMPORTANCE_HIGH
        );
        calls.setDescription("Incoming HealthMate voice and video calls");
        calls.enableVibration(true);

        NotificationChannel active = new NotificationChannel(
                ACTIVE_CHANNEL_ID,
                "HealthMate active service",
                NotificationManager.IMPORTANCE_LOW
        );
        active.setDescription("Keeps Realtime Database message, call, and location listeners active");
        active.setShowBadge(false);

        NotificationChannel messages = new NotificationChannel(
                MESSAGE_CHANNEL_ID,
                "Messages and relationship requests",
                NotificationManager.IMPORTANCE_HIGH
        );
        messages.setDescription("HealthMate family, friend, and conversation notifications");
        messages.enableVibration(true);

        manager.createNotificationChannel(general);
        manager.createNotificationChannel(calls);
        manager.createNotificationChannel(active);
        manager.createNotificationChannel(messages);
    }

    public static HealthMateApplication getInstance() {
        return instance;
    }

    public static boolean isFirebaseReady() {
        return firebaseReady;
    }
}
