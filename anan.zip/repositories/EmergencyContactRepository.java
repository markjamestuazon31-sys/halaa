package com.example.app.repositories;


import com.example.app.firebase.FirebaseDatabaseManager;
import com.example.app.models.EmergencyContact;


import com.google.firebase.database.DatabaseReference;



public class EmergencyContactRepository {


    private final DatabaseReference database;



    public EmergencyContactRepository(){


        database =
                FirebaseDatabaseManager
                        .getInstance()
                        .getDatabase();


    }




    public void sendRequest(
            String senderUID,
            String receiverUID
    ){


        database
                .child("contactRequests")
                .child(receiverUID)
                .child(senderUID)
                .setValue(
                        new EmergencyContact(
                                senderUID,
                                "",
                                "",
                                "pending",
                                false
                        ));


    }





    public void addContact(
            String userUID,
            EmergencyContact contact
    ){


        database
                .child("emergencyContacts")
                .child(userUID)
                .child(contact.getUid())
                .setValue(contact);


    }



}