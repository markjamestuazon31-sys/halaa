package com.example.app.repositories;

import com.example.app.models.Medication;
import com.example.app.models.MedicationHistory;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class MedicationRepository {

    private final DatabaseReference medicationsReference;
    private final DatabaseReference historyReference;

    public MedicationRepository() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        medicationsReference = database.getReference("medications");
        historyReference = database.getReference("medicationHistory");
    }

    public Task<Void> addMedication(String userId, Medication medication) {
        Task<Void> validation = validate(userId, medication);
        if (validation != null) return validation;

        String medicationId = medicationsReference.child(userId).push().getKey();
        if (medicationId == null) {
            return Tasks.forException(new IllegalStateException("Unable to create a medication record."));
        }

        long now = System.currentTimeMillis();
        medication.setId(medicationId);
        medication.setCreatedAt(now);
        medication.setUpdatedAt(now);
        return medicationsReference.child(userId).child(medicationId).setValue(medication);
    }

    public Task<Void> updateMedication(String userId, Medication medication) {
        Task<Void> validation = validate(userId, medication);
        if (validation != null) return validation;
        if (medication.getId() == null || medication.getId().trim().isEmpty()) {
            return Tasks.forException(new IllegalArgumentException("Medication ID is required."));
        }

        medication.setUpdatedAt(System.currentTimeMillis());
        return medicationsReference.child(userId).child(medication.getId()).setValue(medication);
    }

    public Task<Void> setReminderEnabled(String userId, String medicationId, boolean enabled) {
        if (isBlank(userId) || isBlank(medicationId)) {
            return Tasks.forException(new IllegalArgumentException("Medication and user IDs are required."));
        }
        Map<String, Object> updates = new HashMap<>();
        updates.put("active", enabled);
        updates.put("reminderEnabled", enabled);
        updates.put("updatedAt", System.currentTimeMillis());
        return medicationsReference.child(userId).child(medicationId).updateChildren(updates);
    }

    public Task<Void> deleteMedication(String userId, String medicationId) {
        if (isBlank(userId) || isBlank(medicationId)) {
            return Tasks.forException(new IllegalArgumentException("Medication and user IDs are required."));
        }
        return medicationsReference.child(userId).child(medicationId).removeValue();
    }

    public Task<Void> addHistory(String userId, MedicationHistory history) {
        if (isBlank(userId) || history == null) {
            return Tasks.forException(new IllegalArgumentException("Medication history details are required."));
        }
        String historyId = historyReference.child(userId).push().getKey();
        if (historyId == null) {
            return Tasks.forException(new IllegalStateException("Unable to create medication history."));
        }
        history.setId(historyId);
        history.setUserId(userId);
        return historyReference.child(userId).child(historyId).setValue(history);
    }

    public DatabaseReference getMedicationList(String userId) {
        return medicationsReference.child(userId);
    }

    private Task<Void> validate(String userId, Medication medication) {
        if (isBlank(userId)) {
            return Tasks.forException(new IllegalArgumentException("A signed-in user is required."));
        }
        if (medication == null) {
            return Tasks.forException(new IllegalArgumentException("Medication details are required."));
        }
        if (isBlank(medication.getName())) {
            return Tasks.forException(new IllegalArgumentException("Medicine name is required."));
        }
        if (isBlank(medication.getDosage())) {
            return Tasks.forException(new IllegalArgumentException("Dosage is required."));
        }
        if (medication.isReminderEnabled() && !medication.hasValidReminderTime()) {
            return Tasks.forException(new IllegalArgumentException("A valid reminder time is required."));
        }
        return null;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
