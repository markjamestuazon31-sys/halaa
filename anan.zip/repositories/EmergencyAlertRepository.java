package com.example.app.repositories;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.app.models.EmergencyAlert;
import com.example.app.utils.EmergencyRecipientPolicy;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class EmergencyAlertRepository {

    private static final String EMERGENCIES_PATH = "emergencies";
    private final DatabaseReference root;

    public EmergencyAlertRepository() {
        root = FirebaseDatabase.getInstance().getReference();
    }

    public void createAlert(EmergencyAlert alert, AlertCallback callback) {
        if (alert == null || alert.getClientRequestId() == null || alert.getClientRequestId().trim().isEmpty()) {
            callback.onError("A valid emergency request ID is required.");
            return;
        }
        if (alert.getUserId() == null || alert.getUserId().trim().isEmpty()) {
            callback.onError("A signed-in user is required.");
            return;
        }

        String userId = alert.getUserId().trim();
        Task<DataSnapshot> friendsTask = root.child("friends").child(userId).get();
        Task<DataSnapshot> contactsTask = root.child("emergencyContacts").child(userId).get();
        Task<DataSnapshot> adminsTask = root.child("admins").get();
        Task<DataSnapshot> respondersTask = root.child("responders").get();

        Tasks.whenAllComplete(friendsTask, contactsTask, adminsTask, respondersTask)
                .addOnCompleteListener(ignored -> writeAlertAndNotifications(
                        alert,
                        resultOrNull(friendsTask),
                        resultOrNull(contactsTask),
                        resultOrNull(adminsTask),
                        resultOrNull(respondersTask),
                        callback
                ));
    }

    @Nullable
    private DataSnapshot resultOrNull(Task<DataSnapshot> task) {
        return task.isSuccessful() ? task.getResult() : null;
    }

    private void writeAlertAndNotifications(
            EmergencyAlert alert,
            @Nullable DataSnapshot friendsSnapshot,
            @Nullable DataSnapshot contactsSnapshot,
            @Nullable DataSnapshot adminsSnapshot,
            @Nullable DataSnapshot respondersSnapshot,
            AlertCallback callback
    ) {
        String id = alert.getClientRequestId().trim();
        alert.setId(id);

        Set<String> recipients = new LinkedHashSet<>();
        addAcceptedFriends(recipients, alert.getUserId(), friendsSnapshot);
        addAcceptedEmergencyContacts(recipients, alert.getUserId(), contactsSnapshot);
        addAdministrators(recipients, alert.getUserId(), adminsSnapshot);
        addResponders(recipients, alert.getUserId(), respondersSnapshot);
        recipients.remove(alert.getUserId());

        Map<String, Object> updates = new HashMap<>();
        updates.put(EMERGENCIES_PATH + "/" + id, alert);
        updates.put("userEmergencyIndex/" + alert.getUserId() + "/" + id, alert.getCreatedAt());

        for (String recipientId : recipients) {
            String notificationId = root.child("notificationRequests").push().getKey();
            if (notificationId == null) continue;

            Map<String, Object> request = new HashMap<>();
            request.put("targetUserId", recipientId);
            request.put("title", "Emergency SOS from " + safeName(alert.getUserName()));
            request.put(
                    "message",
                    safeName(alert.getUserName())
                            + " sent an SOS alert. Open HealthMate to review the current location and emergency details."
            );
            request.put("type", "emergency_sos");
            request.put("emergencyId", id);
            request.put("createdBy", alert.getUserId());
            request.put("status", "queued");
            request.put("createdAt", alert.getCreatedAt());
            updates.put("notificationRequests/" + notificationId, request);

            Map<String, Object> inboxNotification = new HashMap<>();
            inboxNotification.put("title", request.get("title"));
            inboxNotification.put("message", request.get("message"));
            inboxNotification.put("type", request.get("type"));
            inboxNotification.put("emergencyId", id);
            inboxNotification.put("createdBy", alert.getUserId());
            inboxNotification.put("createdAt", alert.getCreatedAt());
            inboxNotification.put("read", false);
            updates.put("notifications/" + recipientId + "/" + notificationId, inboxNotification);
            updates.put("emergencyRecipientIndex/" + recipientId + "/" + id, alert.getCreatedAt());
        }

        root.updateChildren(updates, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError error, @NonNull DatabaseReference reference) {
                if (error == null) callback.onSuccess(id);
                else callback.onError(
                        error.getMessage() == null
                                ? "Unable to send the emergency alert."
                                : error.getMessage()
                );
            }
        });
    }

    private void addAcceptedFriends(
            Set<String> recipients,
            String senderId,
            @Nullable DataSnapshot snapshot
    ) {
        if (snapshot == null) return;
        for (DataSnapshot friendSnapshot : snapshot.getChildren()) {
            String friendId = friendSnapshot.getKey();
            String status = friendSnapshot.child("status").getValue(String.class);
            if (friendId == null || friendId.equals(senderId)) continue;
            if (EmergencyRecipientPolicy.isAcceptedStatus(status)) recipients.add(friendId);
        }
    }

    private void addAcceptedEmergencyContacts(
            Set<String> recipients,
            String senderId,
            @Nullable DataSnapshot snapshot
    ) {
        if (snapshot == null) return;
        for (DataSnapshot contactSnapshot : snapshot.getChildren()) {
            String contactId = contactSnapshot.child("uid").getValue(String.class);
            if (contactId == null || contactId.trim().isEmpty()) contactId = contactSnapshot.getKey();
            if (contactId == null || contactId.equals(senderId)) continue;

            Boolean acceptedValue = contactSnapshot.child("accepted").getValue(Boolean.class);
            String status = contactSnapshot.child("status").getValue(String.class);
            if (EmergencyRecipientPolicy.isAcceptedEmergencyContact(
                    Boolean.TRUE.equals(acceptedValue),
                    status
            )) {
                recipients.add(contactId);
            }
        }
    }

    private void addAdministrators(
            Set<String> recipients,
            String senderId,
            @Nullable DataSnapshot snapshot
    ) {
        if (snapshot == null) return;
        for (DataSnapshot adminSnapshot : snapshot.getChildren()) {
            String adminId = adminSnapshot.getKey();
            String role = adminSnapshot.child("role").getValue(String.class);
            if (adminId == null || adminId.equals(senderId)) continue;
            if (EmergencyRecipientPolicy.isAdministratorRole(role)) recipients.add(adminId);
        }
    }

    private void addResponders(
            Set<String> recipients,
            String senderId,
            @Nullable DataSnapshot snapshot
    ) {
        if (snapshot == null) return;
        for (DataSnapshot responderSnapshot : snapshot.getChildren()) {
            String responderId = responderSnapshot.child("authUid").getValue(String.class);
            if (responderId == null || responderId.trim().isEmpty()) responderId = responderSnapshot.getKey();
            String status = responderSnapshot.child("status").getValue(String.class);
            String accountStatus = responderSnapshot.child("accountStatus").getValue(String.class);
            if (responderId == null || responderId.equals(senderId)) continue;
            if (EmergencyRecipientPolicy.isNotifiableResponder(status, accountStatus)) recipients.add(responderId);
        }
    }

    private String safeName(String value) {
        return value == null || value.trim().isEmpty() ? "a HealthMate contact" : value.trim();
    }

    public void createAlert(EmergencyAlert alert) {
        createAlert(alert, new AlertCallback() {
            @Override public void onSuccess(String alertId) { }
            @Override public void onError(String message) { }
        });
    }

    public void updateStatus(String id, String status, AlertCallback callback) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", status);
        updates.put("updatedAt", System.currentTimeMillis());
        root.child(EMERGENCIES_PATH).child(id).updateChildren(updates, (error, reference) -> {
            if (error == null) callback.onSuccess(id);
            else callback.onError(
                    error.getMessage() == null
                            ? "Unable to update the emergency."
                            : error.getMessage()
            );
        });
    }

    public interface AlertCallback {
        void onSuccess(String alertId);
        void onError(String message);
    }
}
