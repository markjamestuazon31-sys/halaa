package com.example.app.repositories;

import com.example.app.contacts.ConversationIdPolicy;
import com.example.app.models.CallDescription;
import com.example.app.models.CallIceCandidate;
import com.example.app.models.CallSession;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.webrtc.IceCandidate;
import org.webrtc.SessionDescription;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CallRepository {

    private final DatabaseReference database =
            FirebaseDatabase.getInstance().getReference();

    public void createCall(
            String caller,
            String receiver,
            String type,
            CreateCallCallback callback
    ) {
        if (blank(caller) || blank(receiver) || caller.equals(receiver)) {
            callback.onError("Two different accepted contacts are required.");
            return;
        }

        database.child("relationships")
                .child(caller)
                .child(receiver)
                .get()
                .addOnSuccessListener(relationship -> {
                    boolean accepted = "ACCEPTED".equalsIgnoreCase(
                            string(relationship, "status")
                    );
                    boolean canCall = Boolean.TRUE.equals(
                            relationship.child("canCall").getValue(Boolean.class)
                    );

                    if (!accepted || !canCall) {
                        callback.onError(
                                "Calling is available only for accepted "
                                        + "HealthMate contacts."
                        );
                        return;
                    }

                    String id = database.child("calls").push().getKey();
                    if (id == null) {
                        callback.onError("Unable to allocate the call session.");
                        return;
                    }

                    long now = System.currentTimeMillis();
                    String normalized = normalizeType(type);
                    CallSession call = new CallSession(
                            id,
                            caller,
                            receiver,
                            normalized,
                            "ringing",
                            now
                    );

                    Map<String, Object> incoming = new HashMap<>();
                    incoming.put("callId", id);
                    incoming.put(
                            "conversationId",
                            ConversationIdPolicy.between(caller, receiver)
                    );
                    incoming.put("callerUid", caller);
                    incoming.put("targetUid", receiver);
                    incoming.put(
                            "callType",
                            "video".equals(normalized) ? "VIDEO" : "AUDIO"
                    );
                    incoming.put("status", "RINGING");
                    incoming.put("createdAt", now);
                    incoming.put("expiresAt", now + 45_000L);

                    Map<String, Object> updates = new HashMap<>();
                    updates.put("calls/" + id, call);
                    updates.put(
                            "incomingCalls/" + receiver + "/" + id,
                            incoming
                    );

                    database.updateChildren(
                            updates,
                            (error, reference) -> {
                                if (error == null) {
                                    callback.onSuccess(id);
                                } else {
                                    callback.onError(
                                            message(
                                                    error.getMessage(),
                                                    "Unable to start the call."
                                            )
                                    );
                                }
                            }
                    );
                })
                .addOnFailureListener(error -> callback.onError(
                        message(
                                error.getMessage(),
                                "Unable to verify call permission."
                        )
                ));
    }

    public void setOffer(
            String callId,
            SessionDescription description,
            CompletionCallback callback
    ) {
        setDescription(callId, "offer", description, callback);
    }

    public void setAnswer(
            String callId,
            SessionDescription description,
            CompletionCallback callback
    ) {
        setDescription(callId, "answer", description, callback);
    }

    private void setDescription(
            String callId,
            String child,
            SessionDescription description,
            CompletionCallback callback
    ) {
        if (blank(callId) || description == null) {
            callback.onError("Call description is unavailable.");
            return;
        }

        CallDescription value = new CallDescription(
                description.type.canonicalForm(),
                description.description,
                System.currentTimeMillis()
        );

        database.child("calls")
                .child(callId)
                .child(child)
                .setValue(value)
                .addOnSuccessListener(unused -> callback.onSuccess())
                .addOnFailureListener(
                        error -> callback.onError(
                                message(
                                        error.getMessage(),
                                        "Unable to publish the call description."
                                )
                        )
                );
    }

    public void addIceCandidate(
            String callId,
            String role,
            IceCandidate candidate
    ) {
        addIceCandidate(
                callId,
                role,
                candidate,
                new CompletionCallback() {
                    @Override
                    public void onSuccess() {
                        // Optional callback omitted by caller.
                    }

                    @Override
                    public void onError(String message) {
                        // Optional callback omitted by caller.
                    }
                }
        );
    }

    public void addIceCandidate(
            String callId,
            String role,
            IceCandidate candidate,
            CompletionCallback callback
    ) {
        if (blank(callId) || blank(role) || candidate == null) {
            callback.onError("The network candidate is unavailable.");
            return;
        }

        String candidateId = database
                .child("calls")
                .child(callId)
                .child("iceCandidates")
                .child(role)
                .push()
                .getKey();

        if (candidateId == null) {
            callback.onError("Unable to allocate the network candidate.");
            return;
        }

        CallIceCandidate value = new CallIceCandidate(
                candidate.sdpMid,
                candidate.sdpMLineIndex,
                candidate.sdp,
                System.currentTimeMillis()
        );

        database.child("calls")
                .child(callId)
                .child("iceCandidates")
                .child(role)
                .child(candidateId)
                .setValue(value)
                .addOnSuccessListener(unused -> callback.onSuccess())
                .addOnFailureListener(
                        error -> callback.onError(
                                message(
                                        error.getMessage(),
                                        "Unable to publish the network candidate."
                                )
                        )
                );
    }

    public ValueEventListener listenCall(
            String callId,
            ValueEventListener listener
    ) {
        database.child("calls")
                .child(callId)
                .addValueEventListener(listener);
        return listener;
    }

    public void stopListening(
            String callId,
            ValueEventListener listener
    ) {
        if (!blank(callId) && listener != null) {
            database.child("calls")
                    .child(callId)
                    .removeEventListener(listener);
        }
    }

    public Query incomingCalls(String userId) {
        return database.child("incomingCalls")
                .child(userId)
                .orderByChild("createdAt");
    }

    public void updateStatus(String callId, String status) {
        updateStatus(
                callId,
                status,
                new CompletionCallback() {
                    @Override
                    public void onSuccess() {
                        // Optional callback omitted by caller.
                    }

                    @Override
                    public void onError(String message) {
                        // Optional callback omitted by caller.
                    }
                }
        );
    }

    public void updateStatus(
            String callId,
            String status,
            CompletionCallback callback
    ) {
        if (blank(callId)) {
            callback.onError("Call ID is required.");
            return;
        }

        database.child("calls")
                .child(callId)
                .get()
                .addOnSuccessListener(snapshot -> {
                    CallSession call = snapshot.getValue(CallSession.class);
                    if (call == null) {
                        callback.onError("This call no longer exists.");
                        return;
                    }

                    long now = System.currentTimeMillis();
                    String lower = status == null
                            ? "ended"
                            : status.trim().toLowerCase(Locale.US);
                    String upper = normalizeIndexStatus(lower);

                    Map<String, Object> updates = new HashMap<>();
                    updates.put("calls/" + callId + "/status", lower);
                    updates.put("calls/" + callId + "/updatedAt", now);
                    updates.put(
                            "incomingCalls/"
                                    + call.getReceiverId()
                                    + "/"
                                    + callId
                                    + "/status",
                            upper
                    );
                    updates.put(
                            "incomingCalls/"
                                    + call.getReceiverId()
                                    + "/"
                                    + callId
                                    + "/updatedAt",
                            now
                    );

                    if ("ended".equals(lower)
                            || "rejected".equals(lower)
                            || "missed".equals(lower)) {
                        updates.put("calls/" + callId + "/endedAt", now);
                        updates.put(
                                "incomingCalls/"
                                        + call.getReceiverId()
                                        + "/"
                                        + callId
                                        + "/endedAt",
                                now
                        );
                    }

                    database.updateChildren(
                            updates,
                            (error, reference) -> {
                                if (error == null) {
                                    callback.onSuccess();
                                } else {
                                    callback.onError(
                                            message(
                                                    error.getMessage(),
                                                    "Unable to update the call status."
                                            )
                                    );
                                }
                            }
                    );
                })
                .addOnFailureListener(error -> callback.onError(
                        message(
                                error.getMessage(),
                                "Unable to read the call session."
                        )
                ));
    }

    public void getCall(
            String callId,
            CallSnapshotCallback callback
    ) {
        database.child("calls")
                .child(callId)
                .get()
                .addOnSuccessListener(callback::onSuccess)
                .addOnFailureListener(
                        error -> callback.onError(
                                message(
                                        error.getMessage(),
                                        "Unable to read the call session."
                                )
                        )
                );
    }

    private String normalizeType(String type) {
        return "video".equalsIgnoreCase(type) ? "video" : "audio";
    }

    private String normalizeIndexStatus(String status) {
        if ("rejected".equals(status)) {
            return "DECLINED";
        }
        return status.toUpperCase(Locale.US);
    }

    private String string(DataSnapshot snapshot, String child) {
        String value = snapshot.child(child).getValue(String.class);
        return value == null ? "" : value.trim();
    }

    private boolean blank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String message(String value, String fallback) {
        return blank(value) ? fallback : value;
    }

    public interface CreateCallCallback {
        void onSuccess(String callId);

        void onError(String message);
    }

    public interface CompletionCallback {
        void onSuccess();

        void onError(String message);
    }

    public interface CallSnapshotCallback {
        void onSuccess(DataSnapshot snapshot);

        void onError(String message);
    }
}
