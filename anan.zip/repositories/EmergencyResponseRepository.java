package com.example.app.repositories;

import androidx.annotation.NonNull;
import com.example.app.auth.AccountPolicy;
import com.example.app.emergency.IncidentStatus;
import com.example.app.emergency.IncidentTransitionPolicy;
import com.example.app.emergency.ResponderResponseTransitionPolicy;
import com.example.app.models.EmergencyIncident;
import com.example.app.models.EmergencyResponse;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public class EmergencyResponseRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

    public void accept(String incidentId, String respondentUid, String respondentName, Callback callback) {
        if (blank(incidentId) || blank(respondentUid)) { callback.onError("Incident and respondent IDs are required."); return; }
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(snapshot -> {
            EmergencyIncident incident = snapshot.getValue(EmergencyIncident.class);
            if (incident == null) { callback.onError("The SOS incident no longer exists."); return; }
            if (respondentUid.equals(incident.getPatientUid())) { callback.onError("You cannot accept your own SOS incident as a respondent."); return; }
            if (IncidentStatus.from(incident.getStatus()).isTerminal()) { callback.onError("This incident is already closed or cancelled."); return; }
            verifyActiveRespondent(incidentId, respondentUid, respondentName, incident, callback);
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    private void verifyActiveRespondent(
            final String incidentId,
            final String responderUid,
            final String responderName,
            final EmergencyIncident incident,
            final Callback callback
    ) {
        root.child("respondents")
                .child(responderUid)
                .get()
                .addOnSuccessListener(responderSnapshot -> {

                    if (!responderSnapshot.exists()) {
                        callback.onError(
                                "Your respondent authorization does not exist."
                        );
                        return;
                    }

                    String accountStatus =
                            string(responderSnapshot, "accountStatus");

                    if (!AccountPolicy.isActiveAccountStatus(accountStatus)) {
                        callback.onError(
                                "Your respondent authorization is not active."
                        );
                        return;
                    }

                    final String resolvedResponderName = nonBlank(
                            responderName,
                            string(responderSnapshot, "name")
                    );

                    final DatabaseReference responseReference =
                            root.child("emergencyResponses")
                                    .child(incidentId)
                                    .child(responderUid);

                    final AtomicReference<String> rejectionReason =
                            new AtomicReference<>(
                                    "This incident has already been accepted by your account."
                            );

                    responseReference.runTransaction(
                            new Transaction.Handler() {
                                @NonNull
                                @Override
                                public Transaction.Result doTransaction(
                                        @NonNull MutableData currentData
                                ) {
                                    if (currentData.getValue() != null) {
                                        rejectionReason.set(
                                                "You already joined this response team."
                                        );
                                        return Transaction.abort();
                                    }

                                    long now = System.currentTimeMillis();

                                    Map<String, Object> responseValue =
                                            new HashMap<>();

                                    responseValue.put(
                                            "responderUid",
                                            responderUid
                                    );

                                    responseValue.put(
                                            "responderName",
                                            resolvedResponderName
                                    );

                                    responseValue.put(
                                            "teamRole",
                                            "SUPPORTING"
                                    );

                                    responseValue.put(
                                            "responseStatus",
                                            "ACCEPTED"
                                    );

                                    responseValue.put(
                                            "acceptedAt",
                                            now
                                    );

                                    responseValue.put(
                                            "updatedAt",
                                            now
                                    );

                                    responseValue.put(
                                            "active",
                                            true
                                    );

                                    currentData.setValue(responseValue);

                                    return Transaction.success(currentData);
                                }

                                @Override
                                public void onComplete(
                                        DatabaseError error,
                                        boolean committed,
                                        DataSnapshot currentData
                                ) {
                                    if (error != null) {
                                        callback.onError(error.getMessage());
                                        return;
                                    }

                                    if (!committed) {
                                        callback.onError(
                                                rejectionReason.get()
                                        );
                                        return;
                                    }

                                    electCoordinatorAndFinalize(
                                            incidentId,
                                            responderUid,
                                            incident,
                                            callback
                                    );
                                }
                            },
                            false
                    );
                })
                .addOnFailureListener(error ->
                        callback.onError(
                                error.getMessage() == null
                                        ? "Unable to verify respondent authorization."
                                        : error.getMessage()
                        )
                );
    }

    private void electCoordinatorAndFinalize(String incidentId, String uid, EmergencyIncident incident, Callback callback) {
        DatabaseReference incidentRef = root.child("emergencies").child(incidentId);
        AtomicReference<String> existingCoordinator = new AtomicReference<>("");

        incidentRef.runTransaction(new Transaction.Handler() {
            @NonNull
            @Override
            public Transaction.Result doTransaction(@NonNull MutableData data) {
                if (data.getValue() == null) return Transaction.abort();

                String currentStatus = data.child("status").getValue(String.class);
                if (IncidentStatus.from(currentStatus).isTerminal()) return Transaction.abort();

                String coordinator = data.child("coordinatorResponderId").getValue(String.class);
                if (!blank(coordinator)) {
                    existingCoordinator.set(coordinator.trim());
                    return Transaction.abort();
                }

                data.child("coordinatorResponderId").setValue(uid);
                if (IncidentStatus.from(currentStatus) == IncidentStatus.PENDING) {
                    data.child("status").setValue("ACCEPTED");
                }
                data.child("updatedAt").setValue(System.currentTimeMillis());
                return Transaction.success(data);
            }

            @Override
            public void onComplete(DatabaseError error, boolean committed, DataSnapshot currentData) {
                if (error != null) {
                    callback.onError(error.getMessage());
                    return;
                }

                String coordinator = committed
                        ? string(currentData, "coordinatorResponderId")
                        : existingCoordinator.get();

                if (blank(coordinator)) {
                    callback.onError("The incident can no longer be accepted.");
                    return;
                }

                finalizeAcceptedResponse(incidentId, uid, coordinator, incident, callback);
            }
        }, false);
    }

    private void finalizeAcceptedResponse(
            String incidentId,
            String uid,
            String coordinator,
            EmergencyIncident incident,
            Callback callback
    ) {
        long now = System.currentTimeMillis();
        Map<String, Object> updates = new HashMap<>();
        updates.put(
                "emergencyResponses/" + incidentId + "/" + uid + "/teamRole",
                uid.equals(coordinator) ? "COORDINATOR" : "SUPPORTING"
        );
        updates.put("emergencyResponses/" + incidentId + "/" + uid + "/updatedAt", now);
        updates.put("respondentPresence/" + uid + "/availability", "BUSY");
        updates.put("respondentPresence/" + uid + "/updatedAt", now);
        updates.put("respondents/" + uid + "/availability", "BUSY");
        updates.put("respondents/" + uid + "/updatedAt", now);
        updates.put("emergencyDispatchRecipients/responders/" + uid + "/active", true);
        updates.put("emergencyDispatchRecipients/responders/" + uid + "/availability", "BUSY");
        updates.put("emergencyDispatchRecipients/responders/" + uid + "/updatedAt", now);
        updates.put("respondentResponseIndex/" + uid + "/" + incidentId + "/active", true);
        updates.put("respondentResponseIndex/" + uid + "/" + incidentId + "/updatedAt", now);
        queueTeamUpdate(updates, incident.getPatientUid(), incidentId, uid, now);

        root.updateChildren(updates, (updateError, reference) -> {
            if (updateError != null) {
                callback.onError(updateError.getMessage());
                return;
            }
            notifyIncidentRecipients(
                    incidentId,
                    incident,
                    uid,
                    now,
                    () -> callback.onSuccess(uid.equals(coordinator))
            );
        });
    }

    public void updateOwnStatus(String incidentId, String uid, String nextStatus, String notes, Callback callback) {
        root.child("emergencyResponses").child(incidentId).child(uid).get().addOnSuccessListener(snapshot -> {
            EmergencyResponse response = snapshot.getValue(EmergencyResponse.class);
            if (response == null || !response.isActive()) { callback.onError("You have not accepted this incident."); return; }
            if (!ResponderResponseTransitionPolicy.canTransition(response.getResponseStatus(), nextStatus)) {
                callback.onError("That respondent status transition is not allowed.");
                return;
            }
            long now = System.currentTimeMillis(); Map<String, Object> updates = new HashMap<>();
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/responseStatus", nextStatus);
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/notes", safe(notes));
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/updatedAt", now);
            root.updateChildren(updates, (error, reference) -> {
                if (error != null) { callback.onError(error.getMessage()); return; }
                notifyRecipients(incidentId, uid, "Responder status updated", "A response-team member is now " + display(nextStatus) + ".", "emergency_responder_status", now,
                        () -> callback.onSuccess("COORDINATOR".equals(response.getTeamRole())));
            });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    public void updateIncidentStatusAsCoordinator(String incidentId, String uid, String nextStatus, Callback callback) {
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(snapshot -> {
            EmergencyIncident incident = snapshot.getValue(EmergencyIncident.class);
            if (incident == null || !uid.equals(incident.getCoordinatorResponderId())) { callback.onError("Only the response coordinator can update the incident-wide status."); return; }
            if (!IncidentTransitionPolicy.canTransition(incident.getStatus(), nextStatus)) { callback.onError("That incident status transition is not allowed."); return; }
            long now = System.currentTimeMillis(); Map<String, Object> updates = new HashMap<>();
            updates.put("emergencies/" + incidentId + "/status", nextStatus);
            updates.put("emergencies/" + incidentId + "/updatedAt", now);
            if (IncidentStatus.from(nextStatus).isTerminal()) {
                updates.put("locationSharingPreferences/" + incident.getPatientUid() + "/sosActive", false);
                updates.put("locationSharingPreferences/" + incident.getPatientUid() + "/activeIncidentId", null);
                updates.put("locationSharingPreferences/" + incident.getPatientUid() + "/updatedAt", now);

                // Remove incident-scoped coordinates as soon as the incident closes.
                // This immediately clears the red SOS marker/line for every authorized viewer
                // and prevents stale emergency coordinates from remaining readable.
                updates.put("emergencyLocations/" + incidentId, null);
            }
            root.updateChildren(updates, (error, reference) -> {
                if (error != null) { callback.onError(error.getMessage()); return; }
                notifyRecipients(incidentId, uid, "Emergency incident updated", "Incident status: " + display(nextStatus) + ".", "emergency_update", now,
                        () -> callback.onSuccess(true));
            });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    public void requestBackup(String incidentId, String uid, String notes, Callback callback) {
        root.child("emergencyResponses").child(incidentId).child(uid).get().addOnSuccessListener(responseSnapshot -> {
            if (!Boolean.TRUE.equals(responseSnapshot.child("active").getValue(Boolean.class))) {
                callback.onError("Only an accepted active respondent can request backup.");
                return;
            }
            long now = System.currentTimeMillis(); Map<String, Object> updates = new HashMap<>();
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/backupRequested", true);
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/notes", safe(notes));
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/updatedAt", now);
            root.updateChildren(updates, (error, reference) -> {
                if (error != null) { callback.onError(error.getMessage()); return; }
                notifyAvailableBackupResponders(incidentId, uid, now, () -> callback.onSuccess(false));
            });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    public void withdraw(String incidentId, String uid, Callback callback) {
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(incidentSnapshot -> {
            EmergencyIncident incident = incidentSnapshot.getValue(EmergencyIncident.class);
            long now = System.currentTimeMillis(); Map<String, Object> updates = new HashMap<>();
            updates.put("emergencyResponses/" + incidentId + "/" + uid + "/responseStatus", "WITHDRAWN"); updates.put("emergencyResponses/" + incidentId + "/" + uid + "/active", false); updates.put("emergencyResponses/" + incidentId + "/" + uid + "/updatedAt", now);
            updates.put("emergencyLocations/" + incidentId + "/responders/" + uid, null);
            updates.put("respondentPresence/" + uid + "/availability", "AVAILABLE");
            updates.put("respondentPresence/" + uid + "/updatedAt", now);
            updates.put("respondents/" + uid + "/availability", "AVAILABLE");
            updates.put("respondents/" + uid + "/updatedAt", now);
            updates.put("emergencyDispatchRecipients/responders/" + uid + "/active", true);
            updates.put("emergencyDispatchRecipients/responders/" + uid + "/availability", "AVAILABLE");
            updates.put("emergencyDispatchRecipients/responders/" + uid + "/updatedAt", now);
            updates.put("respondentResponseIndex/" + uid + "/" + incidentId + "/active", false);
            updates.put("respondentResponseIndex/" + uid + "/" + incidentId + "/updatedAt", now);
            root.updateChildren(updates, (error, reference) -> {
                if (error != null) { callback.onError(error.getMessage()); return; }
                if (incident != null && uid.equals(incident.getCoordinatorResponderId())) electReplacement(incidentId, callback); else callback.onSuccess(false);
            });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    private void electReplacement(String incidentId, Callback callback) {
        root.child("emergencyResponses").child(incidentId).get().addOnSuccessListener(snapshot -> {
            String selected = null; long earliest = Long.MAX_VALUE;
            for (DataSnapshot child : snapshot.getChildren()) { Boolean active = child.child("active").getValue(Boolean.class); String status = string(child, "responseStatus"); Long acceptedAt = child.child("acceptedAt").getValue(Long.class); if (Boolean.TRUE.equals(active) && !"WITHDRAWN".equals(status) && acceptedAt != null && acceptedAt < earliest) { selected = child.getKey(); earliest = acceptedAt; } }
            final String replacement = selected; Map<String, Object> updates = new HashMap<>(); updates.put("emergencies/" + incidentId + "/coordinatorResponderId", replacement);
            if (replacement != null) updates.put("emergencyResponses/" + incidentId + "/" + replacement + "/teamRole", "COORDINATOR");
            root.updateChildren(updates, (error, reference) -> { if (error == null) callback.onSuccess(false); else callback.onError(error.getMessage()); });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }


    private void notifyAvailableBackupResponders(String incidentId, String actorUid, long now, Runnable completed) {
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(incidentSnapshot ->
                root.child("emergencyDispatchRecipients").child("responders").get()
                        .addOnSuccessListener(dispatchSnapshot ->
                                root.child("emergencyIncidentRecipients").child(incidentId).get()
                                        .addOnCompleteListener(recipientTask -> {
                                            String patientUid = string(incidentSnapshot, "patientUid");
                                            DataSnapshot recipients = recipientTask.isSuccessful()
                                                    ? recipientTask.getResult() : null;
                                            Map<String, Object> updates = new HashMap<>();

                                            for (DataSnapshot responder : dispatchSnapshot.getChildren()) {
                                                String targetUid = responder.getKey();
                                                if (blank(targetUid)
                                                        || targetUid.equals(actorUid)
                                                        || targetUid.equals(patientUid)) {
                                                    continue;
                                                }
                                                if (!Boolean.TRUE.equals(responder.child("active").getValue(Boolean.class))) {
                                                    continue;
                                                }
                                                if (!"AVAILABLE".equalsIgnoreCase(string(responder, "availability"))) {
                                                    continue;
                                                }
                                                if (recipients == null
                                                        || !Boolean.TRUE.equals(recipients.child(targetUid).getValue(Boolean.class))) {
                                                    continue;
                                                }
                                                queueNotification(
                                                        updates,
                                                        targetUid,
                                                        incidentId,
                                                        actorUid,
                                                        "Backup requested",
                                                        "An active HealthMate response team requested additional available responders.",
                                                        "emergency_backup",
                                                        "HIGH",
                                                        now
                                                );
                                            }

                                            if (updates.isEmpty()) {
                                                completed.run();
                                                return;
                                            }
                                            root.updateChildren(updates, (error, reference) -> completed.run());
                                        })
                        ).addOnFailureListener(error -> completed.run())
        ).addOnFailureListener(error -> completed.run());
    }

    private void notifyRecipients(String incidentId, String actorUid, String title, String message, String type, long now, Runnable completed) {
        root.child("emergencyIncidentRecipients").child(incidentId).get().addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null) { completed.run(); return; }
            Map<String, Object> updates = new HashMap<>();
            for (DataSnapshot recipient : task.getResult().getChildren()) {
                String targetUid = recipient.getKey();
                if (blank(targetUid) || targetUid.equals(actorUid) || !Boolean.TRUE.equals(recipient.getValue(Boolean.class))) continue;
                queueNotification(updates, targetUid, incidentId, actorUid, title, message, type, "NORMAL", now);
            }
            if (updates.isEmpty()) { completed.run(); return; }
            root.updateChildren(updates, (error, reference) -> completed.run());
        });
    }

    private void queueNotification(Map<String, Object> updates, String targetUid, String incidentId, String actorUid,
                                   String title, String message, String type, String priority, long now) {
        String id = root.child("notificationRequests").push().getKey();
        if (id == null) return;
        Map<String, Object> request = new HashMap<>();
        request.put("targetUserId", targetUid); request.put("title", title); request.put("message", message);
        request.put("type", type); request.put("priority", priority); request.put("incidentId", incidentId);
        request.put("emergencyId", incidentId); request.put("createdBy", actorUid); request.put("status", "queued"); request.put("createdAt", now);
        updates.put("notificationRequests/" + id, request);
        Map<String, Object> inbox = new HashMap<>(request); inbox.remove("targetUserId"); inbox.remove("status"); inbox.put("read", false);
        updates.put("notifications/" + targetUid + "/" + id, inbox);
    }

    private String display(String status) { return safe(status).toLowerCase().replace('_', ' '); }

    private void notifyIncidentRecipients(String incidentId, EmergencyIncident incident, String respondentUid, long now, Runnable completed) {
        root.child("emergencyIncidentRecipients").child(incidentId).get().addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null) { completed.run(); return; }
            Map<String, Object> notifications = new HashMap<>();
            for (DataSnapshot recipient : task.getResult().getChildren()) {
                String targetUid = recipient.getKey();
                if (blank(targetUid) || targetUid.equals(incident.getPatientUid())) continue;
                String notificationId = root.child("notifications").child(targetUid).push().getKey();
                if (notificationId == null) continue;
                Map<String, Object> note = new HashMap<>();
                note.put("title", "SOS response team updated");
                note.put("message", "A respondent joined the response team for " + nonBlank(incident.getPatientName(), "a HealthMate incident") + ".");
                note.put("type", "emergency_team_update"); note.put("emergencyId", incidentId); note.put("incidentId", incidentId);
                note.put("createdBy", respondentUid); note.put("createdAt", now); note.put("read", false);
                notifications.put("notifications/" + targetUid + "/" + notificationId, note);
            }
            if (notifications.isEmpty()) completed.run();
            else root.updateChildren(notifications, (error, reference) -> completed.run());
        });
    }

    private void queueTeamUpdate(Map<String, Object> updates, String patientUid, String incidentId, String respondentUid, long now) { if (blank(patientUid)) return; String id = root.child("notifications").child(patientUid).push().getKey(); if (id == null) return; Map<String, Object> note = new HashMap<>(); note.put("title", "A respondent joined your SOS response"); note.put("message", "A HealthMate respondent accepted your incident. The response team can now view the live incident location."); note.put("type", "emergency_team_update"); note.put("emergencyId", incidentId); note.put("incidentId", incidentId); note.put("createdBy", respondentUid); note.put("createdAt", now); note.put("read", false); updates.put("notifications/" + patientUid + "/" + id, note); }
    private String string(DataSnapshot snapshot, String child) { String value = snapshot.child(child).getValue(String.class); return value == null ? "" : value.trim(); }
    private String nonBlank(String value, String fallback) { return blank(value) ? (fallback == null ? "HealthMate respondent" : fallback) : value.trim(); }
    private String safe(String value) { return value == null ? "" : value.trim(); }
    private boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    public interface Callback { void onSuccess(boolean coordinator); void onError(String message); }
}
