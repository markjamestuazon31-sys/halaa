package com.example.app.repositories;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.app.emergency.IncidentStatus;
import com.example.app.models.EmergencyIncident;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.utils.EmergencyRecipientPolicy;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Creates normalized SOS incidents and fans them out through sanitized dispatch indexes. */
public class EmergencyIncidentRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference listeningReference;
    private ValueEventListener listener;

    public void createIncident(EmergencyIncident incident, EmergencyLocationPoint location, Callback callback) {
        if (incident == null || blank(incident.getId()) || blank(incident.getPatientUid())) {
            callback.onError("A valid SOS incident is required.");
            return;
        }
        if (location == null) {
            callback.onError("A current location is required.");
            return;
        }

        String patientUid = incident.getPatientUid();
        Task<DataSnapshot> adminDispatch = root.child("emergencyDispatchRecipients").child("admins").get();
        Task<DataSnapshot> responderDispatch = root.child("emergencyDispatchRecipients").child("responders").get();
        Task<DataSnapshot> friends = root.child("relationships").child(patientUid).get();
        Task<DataSnapshot> contacts = root.child("emergencyContacts").child(patientUid).get();
        Task<DataSnapshot> barangayContacts = root.child("barangays")
                .child(safe(incident.getAssignedBarangayId())).child("emergencyContacts").get();
        Task<DataSnapshot> medical = root.child("medicalProfiles").child(patientUid).get();

        Tasks.whenAllComplete(adminDispatch, responderDispatch, friends, contacts, barangayContacts, medical)
                .addOnCompleteListener(ignored -> writeIncident(
                        incident,
                        location,
                        result(adminDispatch),
                        result(responderDispatch),
                        result(friends),
                        result(contacts),
                        result(barangayContacts),
                        result(medical),
                        callback
                ));
    }

    private void writeIncident(
            EmergencyIncident incident,
            EmergencyLocationPoint location,
            @Nullable DataSnapshot adminDispatch,
            @Nullable DataSnapshot responderDispatch,
            @Nullable DataSnapshot friends,
            @Nullable DataSnapshot contacts,
            @Nullable DataSnapshot barangayContacts,
            @Nullable DataSnapshot medical,
            Callback callback
    ) {
        long now = incident.getCreatedAt() > 0 ? incident.getCreatedAt() : System.currentTimeMillis();
        Map<String, String> recipients = new LinkedHashMap<>();
        putPriority(recipients, incident.getPatientUid(), "NORMAL");
        addDispatchAdmins(recipients, adminDispatch);
        addDispatchResponders(recipients, responderDispatch, incident.getPatientUid());
        addConnections(recipients, friends, incident.getPatientUid());
        addConnections(recipients, contacts, incident.getPatientUid());

        root.child("emergencies").child(incident.getId()).setValue(incident, (incidentError, incidentReference) -> {
            if (incidentError != null) {
                callback.onError(nonBlank(incidentError.getMessage(), "Unable to create the SOS incident."));
                return;
            }

            Map<String, Object> authorizationUpdates = new HashMap<>();
            authorizationUpdates.put("emergencyLocations/" + incident.getId() + "/patient", location);
            authorizationUpdates.put("userEmergencyIndex/" + incident.getPatientUid() + "/" + incident.getId(), now);
            authorizationUpdates.put("locationSharingPreferences/" + incident.getPatientUid() + "/sosActive", true);
            authorizationUpdates.put("locationSharingPreferences/" + incident.getPatientUid() + "/activeIncidentId", incident.getId());
            authorizationUpdates.put("locationSharingPreferences/" + incident.getPatientUid() + "/updatedAt", now);
            if (medical != null && medical.exists()) {
                authorizationUpdates.put("emergencyMedicalSummaries/" + incident.getId(), permittedMedicalSummary(medical, now));
            }
            for (String recipient : recipients.keySet()) {
                authorizationUpdates.put("emergencyRecipientIndex/" + recipient + "/" + incident.getId(), now);
                authorizationUpdates.put("emergencyIncidentRecipients/" + incident.getId() + "/" + recipient, true);
            }

            root.updateChildren(authorizationUpdates, (authorizationError, reference) -> {
                if (authorizationError != null) {
                    root.child("emergencies").child(incident.getId()).removeValue();
                    callback.onError(nonBlank(
                            authorizationError.getMessage(),
                            "Unable to authorize SOS recipients. The incomplete incident was rolled back."
                    ));
                    return;
                }
                deliverNotifications(
                        incident,
                        recipients,
                        adminDispatch,
                        barangayContacts == null || !hasActiveContact(barangayContacts),
                        now,
                        callback
                );
            });
        });
    }

    /**
     * Notifications are deliberately written after recipient authorization. Realtime Database
     * rules can then validate each target against the already committed recipient index.
     */
    private void deliverNotifications(
            EmergencyIncident incident,
            Map<String, String> recipients,
            @Nullable DataSnapshot adminDispatch,
            boolean barangayDirectoryMissing,
            long now,
            Callback callback
    ) {
        Map<String, Object> updates = new HashMap<>();
        for (Map.Entry<String, String> recipient : recipients.entrySet()) {
            queueNotification(updates, recipient.getKey(), incident, recipient.getValue(), now);
        }
        if (barangayDirectoryMissing && adminDispatch != null) {
            for (DataSnapshot admin : adminDispatch.getChildren()) {
                if (isActiveDispatchRecipient(admin) && admin.getKey() != null) {
                    queueDirectoryWarning(updates, admin.getKey(), incident, now);
                }
            }
        }
        if (updates.isEmpty()) {
            callback.onSuccess(incident.getId());
            return;
        }
        root.updateChildren(updates, (error, reference) -> {
            if (error == null) callback.onSuccess(incident.getId());
            else callback.onWarning(
                    incident.getId(),
                    "The SOS is active, but notification delivery could not be fully confirmed. Authorized participants can still see the incident in HealthMate."
            );
        });
    }

    public void listenActiveIncidents(IncidentListener callback) {
        stopListening();
        listeningReference = root.child("emergencies");
        listener = listeningReference.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<EmergencyIncident> items = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    EmergencyIncident item = child.getValue(EmergencyIncident.class);
                    if (item == null || IncidentStatus.from(item.getStatus()).isTerminal()) continue;
                    item.setId(child.getKey());
                    items.add(item);
                }
                items.sort(Comparator.comparingLong(EmergencyIncident::getCreatedAt).reversed());
                callback.onChanged(items);
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.getMessage());
            }
        });
    }

    public void cancelPatientIncident(String incidentId, String patientUid, Callback callback) {
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(snapshot -> {
            EmergencyIncident incident = snapshot.getValue(EmergencyIncident.class);
            if (incident == null || !patientUid.equals(incident.getPatientUid())) {
                callback.onError("You cannot cancel this incident.");
                return;
            }
            if (IncidentStatus.from(incident.getStatus()).isTerminal()) {
                callback.onError("This incident is already closed.");
                return;
            }
            long now = System.currentTimeMillis();
            Map<String, Object> updates = new HashMap<>();
            updates.put("emergencies/" + incidentId + "/status", "CANCELLED");
            updates.put("emergencies/" + incidentId + "/cancelledAt", now);
            updates.put("emergencies/" + incidentId + "/updatedAt", now);
            updates.put("emergencyLocations/" + incidentId, null);
            updates.put("locationSharingPreferences/" + patientUid + "/sosActive", false);
            updates.put("locationSharingPreferences/" + patientUid + "/activeIncidentId", null);
            updates.put("locationSharingPreferences/" + patientUid + "/updatedAt", now);
            root.updateChildren(updates, (error, reference) -> {
                if (error == null) callback.onSuccess(incidentId);
                else callback.onError(error.getMessage());
            });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    public void stopListening() {
        if (listeningReference != null && listener != null) {
            listeningReference.removeEventListener(listener);
        }
        listeningReference = null;
        listener = null;
    }

    @Nullable private DataSnapshot result(Task<DataSnapshot> task) {
        return task.isSuccessful() ? task.getResult() : null;
    }

    private void addDispatchAdmins(Map<String, String> out, DataSnapshot snapshot) {
        if (snapshot == null) return;
        for (DataSnapshot item : snapshot.getChildren()) {
            if (item.getKey() != null && isActiveDispatchRecipient(item)) {
                putPriority(out, item.getKey(), "HIGH");
            }
        }
    }

    private void addDispatchResponders(Map<String, String> out, DataSnapshot snapshot, String patientUid) {
        if (snapshot == null) return;
        for (DataSnapshot item : snapshot.getChildren()) {
            String uid = item.getKey();
            if (uid == null || uid.equals(patientUid) || !isActiveDispatchRecipient(item)) continue;
            putPriority(out, uid, "HIGH");
        }
    }

    private void addConnections(Map<String, String> out, DataSnapshot snapshot, String patientUid) {
        if (snapshot == null) return;
        for (DataSnapshot item : snapshot.getChildren()) {
            String uid = nonBlank(string(item, "contactUid"), nonBlank(string(item, "uid"), nonBlank(string(item, "friendId"), item.getKey())));
            String status = string(item, "status");
            Boolean accepted = item.child("accepted").getValue(Boolean.class);
            if (uid != null && !uid.equals(patientUid)
                    && EmergencyRecipientPolicy.isAcceptedEmergencyContact(
                            Boolean.TRUE.equals(accepted),
                            status
                    )) {
                putPriority(out, uid, "HIGH");
            }
        }
    }

    private void putPriority(Map<String, String> recipients, String uid, String priority) {
        if (blank(uid)) return;
        String existing = recipients.get(uid);
        if (existing == null || "HIGH".equals(priority)) recipients.put(uid, priority);
    }

    private boolean isActiveDispatchRecipient(DataSnapshot item) {
        return Boolean.TRUE.equals(item.child("active").getValue(Boolean.class));
    }

    private boolean hasActiveContact(DataSnapshot snapshot) {
        for (DataSnapshot item : snapshot.getChildren()) {
            Boolean active = item.child("active").getValue(Boolean.class);
            if (!Boolean.FALSE.equals(active)) return true;
        }
        return false;
    }

    private Map<String, Object> permittedMedicalSummary(DataSnapshot medical, long now) {
        Map<String, Object> map = new HashMap<>();
        copy(medical, map, "bloodType");
        copy(medical, map, "allergies");
        copy(medical, map, "conditions");
        copy(medical, map, "medications");
        copy(medical, map, "emergencyNote");
        map.put("updatedAt", now);
        return map;
    }

    private void copy(DataSnapshot source, Map<String, Object> target, String key) {
        Object value = source.child(key).getValue();
        if (value != null) target.put(key, value);
    }

    private void queueNotification(
            Map<String, Object> updates,
            String target,
            EmergencyIncident incident,
            String priority,
            long now
    ) {
        if (blank(target)) return;
        String id = root.child("notifications").child(target).push().getKey();
        if (id == null) return;
        Map<String, Object> common = new HashMap<>();
        common.put("title", "Emergency SOS from " + nonBlank(incident.getPatientName(), "HealthMate user"));
        common.put("message", "Immediate assistance requested. Open the live emergency map to view the red SOS location and route line.");
        common.put("type", "emergency_sos");
        common.put(
                "priority",
                "HIGH".equalsIgnoreCase(safe(priority))
                        ? "HIGH"
                        : "NORMAL"
        );
        common.put("userId", incident.getPatientUid());
        common.put("emergencyId", incident.getId());
        common.put("incidentId", incident.getId());
        common.put("createdBy", incident.getPatientUid());
        common.put("createdAt", now);

        Map<String, Object> inbox = new HashMap<>(common);
        inbox.put("read", false);
        updates.put("notifications/" + target + "/" + id, inbox);

        // The patient receives an in-app confirmation but never targets themselves through
        // the outbound notification queue.
        if (!target.equals(incident.getPatientUid())) {
            Map<String, Object> request = new HashMap<>(common);
            request.put("targetUserId", target);
            request.put("status", "queued");
            updates.put("notificationRequests/" + id, request);
        }
    }

    private void queueDirectoryWarning(
            Map<String, Object> updates,
            String adminUid,
            EmergencyIncident incident,
            long now
    ) {
        if (blank(adminUid)) return;
        String id = root.child("notifications").child(adminUid).push().getKey();
        if (id == null) return;
        Map<String, Object> note = new HashMap<>();
        note.put("title", "Barangay directory incomplete");
        note.put("message", "No active barangay emergency contacts were found for incident "
                + incident.getId() + ". General hotlines remain available.");
        note.put("type", "directory_warning");
        note.put("emergencyId", incident.getId());
        note.put("incidentId", incident.getId());
        note.put("createdBy", incident.getPatientUid());
        note.put("createdAt", now);
        note.put("read", false);
        updates.put("notifications/" + adminUid + "/" + id, note);
    }

    private String string(DataSnapshot snapshot, String child) {
        if (snapshot == null) return "";
        String value = snapshot.child(child).getValue(String.class);
        return value == null ? "" : value.trim();
    }

    private String nonBlank(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private boolean blank(String value) {
        return value == null || value.trim().isEmpty();
    }

    public interface Callback {
        void onSuccess(String incidentId);
        default void onWarning(String incidentId, String message) { onSuccess(incidentId); }
        void onError(String message);
    }

    public interface IncidentListener {
        void onChanged(List<EmergencyIncident> incidents);
        void onError(String message);
    }
}
