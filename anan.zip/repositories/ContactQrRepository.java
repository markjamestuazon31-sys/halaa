package com.example.app.repositories;

import com.example.app.models.ContactPublicProfile;
import com.example.app.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

public class ContactQrRepository {
    private static final char[] TOKEN_ALPHABET =
            "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
                    .toCharArray();

    private final DatabaseReference root =
            FirebaseDatabase.getInstance().getReference();
    private final SecureRandom random = new SecureRandom();

    public void ensureCurrentToken(Callback callback) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (blank(uid)) {
            callback.onError("Please sign in again.");
            return;
        }

        root.child("users").child(uid).get()
                .addOnSuccessListener(userSnapshot -> {
                    User user = userSnapshot.getValue(User.class);
                    if (user == null) {
                        callback.onError(
                                "Your HealthMate profile was not found."
                        );
                        return;
                    }

                    user.setUid(uid);
                    root.child("contactQrTokens")
                            .child(uid)
                            .get()
                            .addOnSuccessListener(tokenSnapshot -> {
                                String currentToken = string(
                                        tokenSnapshot,
                                        "token"
                                );
                                String token = blank(currentToken)
                                        ? newToken()
                                        : currentToken;
                                saveTokenAndPublicProfile(
                                        user,
                                        token,
                                        currentToken,
                                        callback
                                );
                            })
                            .addOnFailureListener(error -> callback.onError(
                                    message(
                                            error.getMessage(),
                                            "Unable to load your contact QR token."
                                    )
                            ));
                })
                .addOnFailureListener(error -> callback.onError(
                        message(
                                error.getMessage(),
                                "Unable to load your profile."
                        )
                ));
    }

    public void rotateCurrentToken(Callback callback) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (blank(uid)) {
            callback.onError("Please sign in again.");
            return;
        }

        root.child("users").child(uid).get()
                .addOnSuccessListener(userSnapshot -> {
                    User user = userSnapshot.getValue(User.class);
                    if (user == null) {
                        callback.onError(
                                "Your HealthMate profile was not found."
                        );
                        return;
                    }

                    user.setUid(uid);
                    root.child("contactQrTokens")
                            .child(uid)
                            .child("token")
                            .get()
                            .addOnSuccessListener(tokenSnapshot ->
                                    saveTokenAndPublicProfile(
                                            user,
                                            newToken(),
                                            safe(tokenSnapshot.getValue(String.class)),
                                            callback
                                    )
                            )
                            .addOnFailureListener(error -> callback.onError(
                                    message(
                                            error.getMessage(),
                                            "Unable to rotate the contact QR."
                                    )
                            ));
                })
                .addOnFailureListener(error -> callback.onError(
                        message(
                                error.getMessage(),
                                "Unable to rotate the contact QR."
                        )
                ));
    }

    public void syncPublicProfile(User user) {
        if (user == null || blank(user.getUid())) return;
        root.child("publicProfiles")
                .child(user.getUid())
                .setValue(publicProfile(user));
    }

    public void resolve(
            String targetUid,
            String suppliedToken,
            ResolveCallback callback
    ) {
        if (blank(targetUid) || blank(suppliedToken)) {
            callback.onError("The scanned contact QR is incomplete.");
            return;
        }

        String currentUid = FirebaseAuth.getInstance().getUid();
        if (targetUid.equals(currentUid)) {
            callback.onError("You cannot add your own QR code.");
            return;
        }

        String token = suppliedToken.trim();
        root.child("contactQrLookups")
                .child(token)
                .child(targetUid)
                .get()
                .addOnSuccessListener(lookupSnapshot -> {
                    if (!Boolean.TRUE.equals(
                            lookupSnapshot.getValue(Boolean.class)
                    )) {
                        callback.onError(
                                "This contact QR has expired. Ask the user to show a new QR code."
                        );
                        return;
                    }

                    root.child("publicProfiles")
                            .child(targetUid)
                            .get()
                            .addOnSuccessListener(profileSnapshot -> {
                                ContactPublicProfile profile =
                                        profileSnapshot.getValue(
                                                ContactPublicProfile.class
                                        );
                                if (profile == null) {
                                    callback.onError(
                                            "This contact has not published a HealthMate profile yet."
                                    );
                                    return;
                                }

                                profile.setUid(targetUid);
                                callback.onResolved(profile);
                            })
                            .addOnFailureListener(error -> callback.onError(
                                    message(
                                            error.getMessage(),
                                            "Unable to resolve the scanned profile."
                                    )
                            ));
                })
                .addOnFailureListener(error -> callback.onError(
                        message(
                                error.getMessage(),
                                "Unable to validate the scanned QR code."
                        )
                ));
    }

    private void saveTokenAndPublicProfile(
            User user,
            String token,
            String previousToken,
            Callback callback
    ) {
        long now = System.currentTimeMillis();

        Map<String, Object> tokenValue = new HashMap<>();
        tokenValue.put("token", token);
        tokenValue.put("updatedAt", now);

        Map<String, Object> updates = new HashMap<>();
        updates.put(
                "contactQrTokens/" + user.getUid(),
                tokenValue
        );
        updates.put(
                "contactQrLookups/" + token + "/" + user.getUid(),
                true
        );
        updates.put(
                "publicProfiles/" + user.getUid(),
                publicProfile(user)
        );

        if (!blank(previousToken) && !previousToken.equals(token)) {
            updates.put(
                    "contactQrLookups/"
                            + previousToken
                            + "/"
                            + user.getUid(),
                    null
            );
        }

        root.updateChildren(updates, (error, reference) -> {
            if (error == null) {
                callback.onReady(token, publicProfile(user));
            } else {
                callback.onError(message(
                        error.getMessage(),
                        "Unable to prepare your contact QR."
                ));
            }
        });
    }

    private ContactPublicProfile publicProfile(User user) {
        return new ContactPublicProfile(
                user.getUid(),
                safe(user.getFullName()),
                safe(user.getProfileImage()),
                safe(user.getRole()),
                System.currentTimeMillis()
        );
    }

    private String newToken() {
        StringBuilder out = new StringBuilder(32);
        for (int index = 0; index < 32; index++) {
            out.append(TOKEN_ALPHABET[
                    random.nextInt(TOKEN_ALPHABET.length)
            ]);
        }
        return out.toString();
    }

    private String string(DataSnapshot snapshot, String child) {
        String value = snapshot.child(child).getValue(String.class);
        return safe(value);
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private boolean blank(String value) {
        return safe(value).isEmpty();
    }

    private String message(String value, String fallback) {
        return blank(value) ? fallback : value;
    }

    public interface Callback {
        void onReady(String token, ContactPublicProfile profile);
        void onError(String message);
    }

    public interface ResolveCallback {
        void onResolved(ContactPublicProfile profile);
        void onError(String message);
    }
}
