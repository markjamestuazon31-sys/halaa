package com.example.app.repositories;

import androidx.annotation.NonNull;

import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.ContactLocation;
import com.example.app.models.ContactPublicProfile;
import com.example.app.models.Relationship;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads only live locations authorized by an accepted relationship.
 *
 * Family locations are included when Firebase rules permit the viewer to read
 * them. Friends are included only when the relationship contains an explicit
 * location grant. The public profile is listened to separately so marker names
 * and profile photographs update without reopening the map.
 */
public class LiveContactLocationRepository {
    private final DatabaseReference root =
            FirebaseDatabase.getInstance().getReference();

    private final Map<String, DatabaseReference> locationReferences =
            new HashMap<>();
    private final Map<String, ValueEventListener> locationListeners =
            new HashMap<>();
    private final Map<String, DatabaseReference> profileReferences =
            new HashMap<>();
    private final Map<String, ValueEventListener> profileListeners =
            new HashMap<>();

    private final Map<String, ContactLocation> rawLocations =
            new HashMap<>();
    private final Map<String, ContactPublicProfile> profiles =
            new HashMap<>();
    private final Map<String, String> relationshipTypes =
            new HashMap<>();

    private DatabaseReference relationshipReference;
    private ValueEventListener relationshipListener;
    private Listener callback;
    private String viewerUid = "";
    private boolean familyOnly;

    /** Full map: self, accepted family, and explicitly authorized friends. */
    public void listen(String viewerUid, Listener listener) {
        listenInternal(viewerUid, false, listener);
    }

    /** Home preview: self and accepted family only. */
    public void listenFamily(String viewerUid, Listener listener) {
        listenInternal(viewerUid, true, listener);
    }

    private void listenInternal(
            String viewerUid,
            boolean familyOnly,
            Listener listener
    ) {
        stop();

        this.viewerUid = safe(viewerUid);
        this.familyOnly = familyOnly;
        this.callback = listener;

        if (this.viewerUid.isEmpty()) {
            listener.onError("Please sign in again.");
            return;
        }

        relationshipReference = root
                .child("relationships")
                .child(this.viewerUid);

        relationshipListener = relationshipReference.addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        rebuildAuthorizedListeners(snapshot);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        listener.onError(message(
                                error.getMessage(),
                                "Unable to load paired contacts."
                        ));
                    }
                }
        );
    }

    private void rebuildAuthorizedListeners(DataSnapshot snapshot) {
        clearContactListeners();

        int selectedRelationshipCount = 0;

        for (DataSnapshot child : snapshot.getChildren()) {
            Relationship relationship = child.getValue(Relationship.class);
            String contactUid = safe(child.getKey());

            if (relationship == null
                    || contactUid.isEmpty()
                    || !RelationshipPolicy.ACCEPTED.equals(
                    RelationshipPolicy.normalize(relationship.getStatus())
            )) {
                continue;
            }

            String type = RelationshipPolicy.normalize(
                    relationship.getRelationshipType()
            );

            boolean acceptedFamily =
                    RelationshipPolicy.FAMILY.equals(type);

            boolean authorizedFriend =
                    RelationshipPolicy.FRIEND.equals(type)
                            && relationship.isExplicitLocationGrant();

            if (familyOnly && !acceptedFamily) {
                continue;
            }

            if (!acceptedFamily && !authorizedFriend) {
                continue;
            }

            selectedRelationshipCount++;
            attachContact(contactUid, type);
        }

        // The signed-in user's local/RTDB position is always part of the map.
        attachContact(viewerUid, "SELF");

        if (callback != null) {
            callback.onRelationshipCount(selectedRelationshipCount);
        }

        emit();
    }

    private void attachContact(String uid, String relationshipType) {
        if (uid.isEmpty() || locationListeners.containsKey(uid)) {
            return;
        }

        relationshipTypes.put(uid, safe(relationshipType));

        DatabaseReference profileReference = root
                .child("publicProfiles")
                .child(uid);

        ValueEventListener profileListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ContactPublicProfile profile =
                        snapshot.getValue(ContactPublicProfile.class);

                if (profile == null) {
                    profile = new ContactPublicProfile();
                    profile.setUid(uid);
                    profile.setFullName(
                            uid.equals(viewerUid)
                                    ? "You"
                                    : "HealthMate family"
                    );
                }

                profile.setUid(uid);
                profiles.put(uid, profile);
                emit();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Keep the location marker with a safe fallback identity.
                emit();
            }
        };

        profileReference.addValueEventListener(profileListener);
        profileReferences.put(uid, profileReference);
        profileListeners.put(uid, profileListener);

        DatabaseReference locationReference = root
                .child("liveLocations")
                .child(uid);

        ValueEventListener locationListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    rawLocations.remove(uid);
                    emit();
                    return;
                }

                ContactLocation location =
                        snapshot.getValue(ContactLocation.class);

                if (location == null) {
                    rawLocations.remove(uid);
                    emit();
                    return;
                }

                location.setUid(uid);
                location.setRelationshipType(
                        relationshipTypes.get(uid)
                );

                rawLocations.put(uid, location);
                emit();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Permission is intentionally denied when the owner has not
                // enabled sharing. The marker is omitted without failing the
                // remaining family map.
                rawLocations.remove(uid);
                emit();
            }
        };

        locationReference.addValueEventListener(locationListener);
        locationReferences.put(uid, locationReference);
        locationListeners.put(uid, locationListener);
    }

    private void emit() {
        if (callback == null) {
            return;
        }

        List<ContactLocation> result = new ArrayList<>();

        for (Map.Entry<String, ContactLocation> entry
                : rawLocations.entrySet()) {
            String uid = entry.getKey();
            ContactLocation source = entry.getValue();

            if (source == null) {
                continue;
            }

            ContactPublicProfile profile = profiles.get(uid);
            ContactLocation enriched = copy(source);

            enriched.setUid(uid);
            enriched.setRelationshipType(
                    relationshipTypes.get(uid)
            );

            String fallbackName = uid.equals(viewerUid)
                    ? "You"
                    : "HealthMate family";

            if (profile != null) {
                enriched.setDisplayName(nonBlank(
                        profile.getFullName(),
                        fallbackName
                ));
                enriched.setProfileImage(safe(
                        profile.getProfileImage()
                ));
            } else {
                enriched.setDisplayName(fallbackName);
            }

            result.add(enriched);
        }

        Collections.sort(result, new Comparator<ContactLocation>() {
            @Override
            public int compare(
                    ContactLocation left,
                    ContactLocation right
            ) {
                if (left.isSelf() && !right.isSelf()) {
                    return -1;
                }
                if (!left.isSelf() && right.isSelf()) {
                    return 1;
                }
                return safe(left.getDisplayName()).compareToIgnoreCase(
                        safe(right.getDisplayName())
                );
            }
        });

        callback.onChanged(result);
    }

    private ContactLocation copy(ContactLocation source) {
        ContactLocation result = new ContactLocation();
        result.setUid(source.getUid());
        result.setDisplayName(source.getDisplayName());
        result.setProfileImage(source.getProfileImage());
        result.setRelationshipType(source.getRelationshipType());
        result.setLatitude(source.getLatitude());
        result.setLongitude(source.getLongitude());
        result.setAccuracy(source.getAccuracy());
        result.setBearing(source.getBearing());
        result.setSpeed(source.getSpeed());
        result.setUpdatedAt(source.getUpdatedAt());
        result.setSource(source.getSource());
        return result;
    }

    private void clearContactListeners() {
        for (Map.Entry<String, ValueEventListener> item
                : locationListeners.entrySet()) {
            DatabaseReference reference =
                    locationReferences.get(item.getKey());
            if (reference != null) {
                reference.removeEventListener(item.getValue());
            }
        }

        for (Map.Entry<String, ValueEventListener> item
                : profileListeners.entrySet()) {
            DatabaseReference reference =
                    profileReferences.get(item.getKey());
            if (reference != null) {
                reference.removeEventListener(item.getValue());
            }
        }

        locationReferences.clear();
        locationListeners.clear();
        profileReferences.clear();
        profileListeners.clear();
        rawLocations.clear();
        profiles.clear();
        relationshipTypes.clear();
    }

    public void stop() {
        if (relationshipReference != null
                && relationshipListener != null) {
            relationshipReference.removeEventListener(
                    relationshipListener
            );
        }

        relationshipReference = null;
        relationshipListener = null;
        clearContactListeners();
        callback = null;
        viewerUid = "";
    }

    private String nonBlank(String value, String fallback) {
        return safe(value).isEmpty() ? fallback : value.trim();
    }

    private String message(String value, String fallback) {
        return safe(value).isEmpty() ? fallback : value.trim();
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    public interface Listener {
        void onChanged(List<ContactLocation> locations);

        default void onRelationshipCount(int count) {
            // Optional for screens that only need the visible locations.
        }

        void onError(String message);
    }
}
