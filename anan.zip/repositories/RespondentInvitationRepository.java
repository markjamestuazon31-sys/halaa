package com.example.app.repositories;

import com.example.app.auth.AccountPolicy;
import com.example.app.auth.EmailKeyEncoder;
import com.example.app.models.RespondentInvitation;
import com.example.app.models.User;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class RespondentInvitationRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

    public void preflight(String email, PreflightCallback callback) {
        String normalized = AccountPolicy.normalizeEmail(email);
        if (!AccountPolicy.isReservedResponderEmail(normalized)) { callback.onResult(false, null); return; }
        String key = EmailKeyEncoder.encode(normalized);
        root.child("respondentSignupEligibility").child(key).get().addOnSuccessListener(snapshot -> {
            Boolean eligible = snapshot.child("eligible").getValue(Boolean.class);
            callback.onResult(Boolean.TRUE.equals(eligible), key);
        }).addOnFailureListener(error -> callback.onError(message(error, "Unable to verify respondent invitation eligibility.")));
    }

    public void claim(FirebaseUser firebaseUser, User input, String invitationKey, ClaimCallback callback) {
        if (firebaseUser == null || invitationKey == null || invitationKey.trim().isEmpty()) { callback.onError("Invalid respondent registration claim."); return; }
        root.child("respondentInvitations").child(invitationKey).get().addOnSuccessListener(snapshot -> {
            RespondentInvitation invitation = snapshot.getValue(RespondentInvitation.class);
            String authEmail = AccountPolicy.normalizeEmail(firebaseUser.getEmail());
            if (invitation == null || !AccountPolicy.isInvitedInvitationStatus(invitation.getStatus()) || !AccountPolicy.emailMatches(authEmail, invitation.getNormalizedEmail())) {
                callback.onError("This respondent email is not actively invited or the invitation was changed."); return;
            }
            long now = System.currentTimeMillis();
            User profile = new User();
            profile.setUid(firebaseUser.getUid()); profile.setFullName(nonBlank(invitation.getFullName(), input.getFullName()));
            profile.setEmail(authEmail); profile.setPhone(nonBlank(invitation.getPhone(), input.getPhone())); profile.setContactNumber(profile.getPhone());
            profile.setProfileImage(input.getProfileImage()); profile.setRole(AccountPolicy.ROLE_RESPONDER); profile.setStatus("active"); profile.setAccountStatus("active");
            profile.setAssignedBarangayId(invitation.getAssignedBarangayId()); profile.setRespondentInvitationKey(invitationKey); profile.setCreatedAt(now); profile.setUpdatedAt(now);

            Map<String, Object> respondent = new HashMap<>();
            respondent.put("authUid", firebaseUser.getUid()); respondent.put("role", "responder"); respondent.put("accountStatus", "active");
            respondent.put("name", profile.getFullName()); respondent.put("email", authEmail); respondent.put("contact", profile.getPhone());
            respondent.put("position", nonBlank(invitation.getPosition(), "Emergency Respondent")); respondent.put("assignedBarangayId", invitation.getAssignedBarangayId());
            respondent.put("serviceArea", invitation.getServiceArea()); respondent.put("respondentInvitationKey", invitationKey); respondent.put("availability", "OFF_DUTY"); respondent.put("createdBy", invitation.getCreatedBy());
            respondent.put("createdAt", now); respondent.put("updatedAt", now);

            Map<String, Object> updates = new HashMap<>();
            updates.put("users/" + firebaseUser.getUid(), profile);
            updates.put("respondents/" + firebaseUser.getUid(), respondent);
            updates.put("respondentInvitations/" + invitationKey + "/status", "REGISTERED");
            updates.put("respondentInvitations/" + invitationKey + "/registeredUid", firebaseUser.getUid());
            updates.put("respondentInvitations/" + invitationKey + "/updatedAt", now);
            updates.put("respondentSignupEligibility/" + invitationKey, eligibility(false, now));
            String auditId = root.child("auditLogs").push().getKey();
            if (auditId != null) updates.put("auditLogs/" + auditId, audit("Respondent invitation claimed", firebaseUser.getUid(), authEmail, now));
            root.updateChildren(updates, (error, reference) -> { if (error == null) callback.onClaimed(profile); else callback.onError(error.getMessage()); });
        }).addOnFailureListener(error -> callback.onError(message(error, "Unable to load the respondent invitation.")));
    }

    public void rollbackClaim(FirebaseUser user, String invitationKey, ClaimCallback callback) {
        if (user == null) { callback.onError("No respondent account to roll back."); return; }
        long now = System.currentTimeMillis();
        Map<String, Object> updates = new HashMap<>();
        updates.put("users/" + user.getUid(), null); updates.put("respondents/" + user.getUid(), null);
        if (invitationKey != null && !invitationKey.isEmpty()) {
            updates.put("respondentInvitations/" + invitationKey + "/status", "INVITED");
            updates.put("respondentInvitations/" + invitationKey + "/registeredUid", null);
            updates.put("respondentInvitations/" + invitationKey + "/updatedAt", now);
            updates.put("respondentSignupEligibility/" + invitationKey, eligibility(true, now));
        }
        root.updateChildren(updates, (error, reference) -> { if (error == null) callback.onClaimed(null); else callback.onError(error.getMessage()); });
    }

    private Map<String, Object> eligibility(boolean eligible, long now) { Map<String, Object> map = new HashMap<>(); map.put("eligible", eligible); map.put("updatedAt", now); return map; }
    private Map<String, Object> audit(String action, String uid, String details, long now) { Map<String, Object> map = new HashMap<>(); map.put("action", action); map.put("performedBy", uid); map.put("userId", uid); map.put("details", details); map.put("timestamp", now); return map; }
    private String nonBlank(String preferred, String fallback) { return preferred == null || preferred.trim().isEmpty() ? fallback : preferred.trim(); }
    private String message(Exception error, String fallback) { return error != null && error.getMessage() != null ? error.getMessage() : fallback; }

    public interface PreflightCallback { void onResult(boolean eligible, String invitationKey); void onError(String message); }
    public interface ClaimCallback { void onClaimed(User profile); void onError(String message); }
}
