package com.example.app.repositories;

import com.example.app.emergency.RescueReportValidator;
import com.example.app.models.RescueReport;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class RescueReportRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    public void submitIndividual(String incidentId, String uid, RescueReport report, Callback callback) {
        String validation = RescueReportValidator.validateIndividual(report); if (validation != null) { callback.onError(validation); return; }
        root.child("emergencyResponses").child(incidentId).child(uid).get().addOnSuccessListener(response -> {
            if (!response.exists() || !Boolean.TRUE.equals(response.child("active").getValue(Boolean.class))) { callback.onError("Only an accepted active respondent can submit a report."); return; }
            long now = System.currentTimeMillis(); report.setIncidentId(incidentId); report.setResponderUid(uid); report.setTeamRole(string(response, "teamRole")); report.setSubmittedAt(now); report.setUpdatedAt(now);
            root.child("rescueReports").child(incidentId).child("responders").child(uid).setValue(report, (error, reference) -> { if (error == null) callback.onSuccess(); else callback.onError(error.getMessage()); });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }
    public void submitFinal(String incidentId, String uid, RescueReport report, Callback callback) {
        String validation = RescueReportValidator.validateFinal(report); if (validation != null) { callback.onError(validation); return; }
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(incident -> {
            if (!uid.equals(string(incident, "coordinatorResponderId"))) { callback.onError("Only the response coordinator can submit the final report."); return; }
            long now = System.currentTimeMillis(); report.setIncidentId(incidentId); report.setCoordinatorUid(uid); report.setReviewStatus("PENDING_REVIEW"); report.setSubmittedAt(now); report.setUpdatedAt(now);
            Map<String, Object> updates = new HashMap<>(); updates.put("rescueReports/" + incidentId + "/final", report); updates.put("emergencies/" + incidentId + "/status", "REPORT_SUBMITTED"); updates.put("emergencies/" + incidentId + "/updatedAt", now);
            String auditId = root.child("auditLogs").push().getKey(); if (auditId != null) { Map<String, Object> audit = new HashMap<>(); audit.put("action", "Final rescue report submitted"); audit.put("performedBy", uid); audit.put("incidentId", incidentId); audit.put("timestamp", now); updates.put("auditLogs/" + auditId, audit); }
            root.updateChildren(updates, (error, reference) -> { if (error == null) callback.onSuccess(); else callback.onError(error.getMessage()); });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }
    private String string(com.google.firebase.database.DataSnapshot snapshot, String child) { String value = snapshot.child(child).getValue(String.class); return value == null ? "" : value.trim(); }
    public interface Callback { void onSuccess(); void onError(String message); }
}
