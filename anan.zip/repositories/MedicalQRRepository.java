package com.example.app.repositories;

import com.example.app.models.MedicalQR;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MedicalQRRepository {

    private final DatabaseReference medicalQrReference;

    public MedicalQRRepository() {
        medicalQrReference = FirebaseDatabase.getInstance().getReference("medicalQR");
    }

    public Task<Void> createQR(String userId, MedicalQR medicalQr) {
        if (userId == null || userId.trim().isEmpty()) {
            return Tasks.forException(new IllegalArgumentException("A signed-in user is required."));
        }
        if (medicalQr == null) {
            return Tasks.forException(new IllegalArgumentException("Medical QR data is required."));
        }
        return medicalQrReference.child(userId).setValue(medicalQr);
    }

    public DatabaseReference getMedicalQR(String userId) {
        return medicalQrReference.child(userId);
    }
}
