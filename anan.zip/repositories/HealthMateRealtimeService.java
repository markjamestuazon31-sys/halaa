package com.example.app.repositories;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.app.HealthMateApplication;
import com.example.app.R;
import com.example.app.MainActivity;
import com.example.app.activities.CallActivity;
import com.example.app.activities.ChatActivity;
import com.example.app.activities.NotificationActivity;
import com.example.app.activities.RelationshipRequestsActivity;
import com.example.app.receivers.CallActionReceiver;
import com.example.app.services.LocationSharingService;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashSet;
import java.util.Set;

public class HealthMateRealtimeService extends Service {
    private static final int ACTIVE_NOTIFICATION_ID=7401;
    private final Set<String> delivered=new HashSet<>();
    private final PresenceRepository presenceRepository=new PresenceRepository();
    private DatabaseReference conversationsRef,requestsRef,callsRef,notificationsRef,relationshipsRef,ownPresenceRef;
    private ChildEventListener conversationListener,requestListener,callListener,notificationListener,relationshipListener;
    private ValueEventListener ownPresenceListener;
    private String uid,activeConversationId="";

    public static void start(Context context){if(FirebaseAuth.getInstance().getUid()!=null)ContextCompat.startForegroundService(context,new Intent(context,HealthMateRealtimeService.class));}
    public static void stop(Context context){context.stopService(new Intent(context,HealthMateRealtimeService.class));}

    @Override public void onCreate(){super.onCreate();startForeground(ACTIVE_NOTIFICATION_ID,activeNotification());}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String current=FirebaseAuth.getInstance().getUid(); if(current==null){stopSelf();return START_NOT_STICKY;}
        if(current.equals(uid)&&conversationListener!=null)return START_STICKY;
        stopListeners();uid=current;presenceRepository.connect(uid);listen();return START_STICKY;
    }

    private Notification activeNotification(){
        Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());
        if(launch==null) launch=new Intent(this,MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(this,7401,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this,HealthMateApplication.ACTIVE_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_home_shield_check).setContentTitle("HealthMate active")
                .setContentText("Monitoring messages, calls, location sharing, and emergency alerts.")
                .setPriority(NotificationCompat.PRIORITY_LOW).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(content).build();
    }

    private void listen(){
        DatabaseReference root=FirebaseDatabase.getInstance().getReference();
        ownPresenceRef=root.child("userPresence").child(uid);
        ownPresenceListener=ownPresenceRef.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot snapshot){activeConversationId=string(snapshot,"activeConversationId");}
            @Override public void onCancelled(@NonNull DatabaseError error){activeConversationId="";}
        });
        conversationsRef=root.child("userConversations").child(uid);
        conversationListener=new BaseChildListener(){@Override public void handle(DataSnapshot snapshot){
            String conversationId=snapshot.getKey();String sender=string(snapshot,"lastMessageSenderUid");String other=string(snapshot,"otherParticipantUid");Long at=snapshot.child("lastMessageAt").getValue(Long.class);Long unread=snapshot.child("unreadCount").getValue(Long.class);
            boolean muted=Boolean.TRUE.equals(snapshot.child("muted").getValue(Boolean.class));
            if(blank(conversationId)||uid.equals(sender)||muted||conversationId.equals(activeConversationId)||at==null||unread==null||unread<=0)return;
            notifyMessage(conversationId,other,string(snapshot,"lastMessageText"),at);
        }};conversationsRef.addChildEventListener(conversationListener);
        relationshipsRef=root.child("relationships").child(uid);
        relationshipListener=new BaseChildListener(){@Override public void handle(DataSnapshot snapshot){
            LocationSharingService.refresh(HealthMateRealtimeService.this);}};
        relationshipsRef.addChildEventListener(relationshipListener);
        requestsRef=root.child("relationshipRequests").child(uid);
        requestListener=new BaseChildListener(){@Override public void handle(DataSnapshot snapshot){String status=string(snapshot,"status");Long at=snapshot.child("updatedAt").getValue(Long.class);if(!"PENDING".equals(status)||at==null)return;notifyRequest(snapshot.getKey(),string(snapshot,"relationshipType"),at);}};requestsRef.addChildEventListener(requestListener);
        callsRef=root.child("incomingCalls").child(uid);
        callListener=new BaseChildListener(){@Override public void handle(DataSnapshot snapshot){String callId=snapshot.getKey();String status=string(snapshot,"status");if(!"RINGING".equals(status)){if(!blank(callId)){NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.cancel(callId.hashCode());delivered.remove("c:"+callId);}return;}Long expires=snapshot.child("expiresAt").getValue(Long.class);if(expires!=null&&expires<System.currentTimeMillis()){if(!blank(callId))new CallRepository().updateStatus(callId,"missed");return;}notifyCall(snapshot);}};callsRef.addChildEventListener(callListener);
        notificationsRef=root.child("notifications").child(uid);
        notificationListener=new BaseChildListener(){@Override public void handle(DataSnapshot snapshot){Long at=snapshot.child("createdAt").getValue(Long.class);if(at==null||Boolean.TRUE.equals(snapshot.child("read").getValue(Boolean.class)))return;String type=string(snapshot,"type");if("chat_message".equals(type)||"incoming_call".equals(type)||"contact_request".equals(type))return;notifyGeneral(snapshot.getKey(),string(snapshot,"title"),string(snapshot,"message"));}};notificationsRef.addChildEventListener(notificationListener);
    }

    private void notifyMessage(String conversationId,String otherUid,String text,long at){String key="m:"+conversationId+":"+at;if(!delivered.add(key))return;
        Intent intent=new Intent(this,ChatActivity.class).putExtra("conversationId",conversationId).putExtra("receiverId",otherUid).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending=PendingIntent.getActivity(this,key.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        post(key.hashCode(),new NotificationCompat.Builder(this,HealthMateApplication.MESSAGE_CHANNEL_ID).setSmallIcon(R.drawable.ic_home_chat).setContentTitle("New HealthMate message").setContentText(blank(text)?"Open the conversation to read the message.":text).setAutoCancel(true).setContentIntent(pending).setPriority(NotificationCompat.PRIORITY_HIGH).build());}
    private void notifyRequest(String requestId,String type,long at){String key="r:"+requestId+":"+at;if(!delivered.add(key))return;Intent intent=new Intent(this,RelationshipRequestsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pending=PendingIntent.getActivity(this,key.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);post(key.hashCode(),new NotificationCompat.Builder(this,HealthMateApplication.MESSAGE_CHANNEL_ID).setSmallIcon(R.drawable.ic_home_contacts).setContentTitle("New "+("FAMILY".equals(type)?"family":"friend")+" request").setContentText("Open HealthMate to accept or reject the relationship request.").setContentIntent(pending).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build());}
    private void notifyCall(DataSnapshot snapshot) {
        String callId = snapshot.getKey();
        if (blank(callId) || !delivered.add("c:" + callId)) return;

        String type = string(snapshot, "callType");
        Long expiresAt = snapshot.child("expiresAt").getValue(Long.class);
        long remainingMs = expiresAt == null
                ? 45_000L
                : Math.max(1_000L, expiresAt - System.currentTimeMillis());

        Intent answer = new Intent(this, CallActivity.class)
                .putExtra("callId", callId)
                .putExtra("callType", "VIDEO".equals(type) ? "video" : "audio")
                .putExtra("incoming", true)
                .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                );
        PendingIntent answerPi = PendingIntent.getActivity(
                this,
                callId.hashCode(),
                answer,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent decline = new Intent(this, CallActionReceiver.class)
                .setAction(CallActionReceiver.ACTION_DECLINE)
                .putExtra("callId", callId);
        PendingIntent declinePi = PendingIntent.getBroadcast(
                this,
                callId.hashCode() + 1,
                decline,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification notification = new NotificationCompat.Builder(
                this,
                HealthMateApplication.CALL_CHANNEL_ID
        )
                .setSmallIcon(
                        "VIDEO".equals(type)
                                ? R.drawable.ic_video
                                : R.drawable.ic_call
                )
                .setContentTitle("Incoming HealthMate call")
                .setContentText("An accepted contact is calling you.")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setTimeoutAfter(remainingMs)
                .setContentIntent(answerPi)
                .setFullScreenIntent(answerPi, true)
                .addAction(R.drawable.ic_call, "Answer", answerPi)
                .addAction(
                        android.R.drawable.ic_menu_close_clear_cancel,
                        "Decline",
                        declinePi
                )
                .build();

        post(callId.hashCode(), notification);
    }
    private void notifyGeneral(String id,String title,String message){String key="n:"+id;if(!delivered.add(key))return;Intent intent=new Intent(this,NotificationActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pending=PendingIntent.getActivity(this,key.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);post(key.hashCode(),new NotificationCompat.Builder(this,HealthMateApplication.GENERAL_CHANNEL_ID).setSmallIcon(R.drawable.ic_home_bell).setContentTitle(blank(title)?"HealthMate update":title).setContentText(blank(message)?"Open HealthMate for details.":message).setContentIntent(pending).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build());}
    private void post(int id,Notification notification){NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.notify(id,notification);}

    private void stopListeners(){if(conversationsRef!=null&&conversationListener!=null)conversationsRef.removeEventListener(conversationListener);if(requestsRef!=null&&requestListener!=null)requestsRef.removeEventListener(requestListener);if(callsRef!=null&&callListener!=null)callsRef.removeEventListener(callListener);if(notificationsRef!=null&&notificationListener!=null)notificationsRef.removeEventListener(notificationListener);if(relationshipsRef!=null&&relationshipListener!=null)relationshipsRef.removeEventListener(relationshipListener);if(ownPresenceRef!=null&&ownPresenceListener!=null)ownPresenceRef.removeEventListener(ownPresenceListener);conversationsRef=requestsRef=callsRef=notificationsRef=relationshipsRef=ownPresenceRef=null;conversationListener=requestListener=callListener=notificationListener=relationshipListener=null;ownPresenceListener=null;activeConversationId="";delivered.clear();}
    @Override public void onDestroy(){stopListeners();if(uid!=null)presenceRepository.disconnect(uid);super.onDestroy();}
    @Nullable @Override public IBinder onBind(Intent intent){return null;}
    private String string(DataSnapshot snapshot,String child){String value=snapshot.child(child).getValue(String.class);return value==null?"":value.trim();}
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
    private abstract static class BaseChildListener implements ChildEventListener{abstract void handle(DataSnapshot snapshot);@Override public void onChildAdded(@NonNull DataSnapshot snapshot,String previousChildName){handle(snapshot);}@Override public void onChildChanged(@NonNull DataSnapshot snapshot,String previousChildName){handle(snapshot);}@Override public void onChildRemoved(@NonNull DataSnapshot snapshot){}@Override public void onChildMoved(@NonNull DataSnapshot snapshot,String previousChildName){}@Override public void onCancelled(@NonNull DatabaseError error){}}
}
