package com.example.app.repositories;


import androidx.annotation.NonNull;


import com.example.app.firebase.FirebaseDatabaseManager;
import com.example.app.models.User;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;



public class UserRepository {


    private final DatabaseReference database;


    private final FirebaseAuth auth;



    public UserRepository(){


        database =
                FirebaseDatabaseManager
                        .getInstance()
                        .getDatabase();



        auth =
                FirebaseAuth.getInstance();


    }





    public void getCurrentUser(
            UserCallback callback
    ){


        if(auth.getCurrentUser()==null){

            callback.onError(
                    "No active user"
            );

            return;

        }



        String uid =
                auth.getCurrentUser()
                        .getUid();



        database
                .child("users")
                .child(uid)
                .addListenerForSingleValueEvent(

                        new ValueEventListener(){


                            @Override
                            public void onDataChange(
                                    @NonNull DataSnapshot snapshot
                            ){


                                User user =
                                        snapshot.getValue(
                                                User.class
                                        );



                                if(user != null){

                                    callback.onSuccess(user);

                                }
                                else{

                                    callback.onError(
                                            "User profile not found"
                                    );

                                }


                            }



                            @Override
                            public void onCancelled(
                                    @NonNull DatabaseError error
                            ){


                                callback.onError(
                                        error.getMessage()
                                );


                            }


                        });


    }





    public void updateUser(
            User user,
            UserCallback callback
    ){


        database
                .child("users")
                .child(user.getUid())
                .setValue(user)
                .addOnCompleteListener(task->{



                    if(task.isSuccessful()){


                        callback.onSuccess(user);


                    }
                    else{


                        callback.onError(
                                task.getException()
                                        .getMessage()
                        );


                    }



                });



    }





    public interface UserCallback{


        void onSuccess(User user);


        void onError(String message);


    }


}