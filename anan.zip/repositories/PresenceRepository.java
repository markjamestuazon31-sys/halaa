package com.example.app.repositories;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class PresenceRepository {
    private final DatabaseReference root=FirebaseDatabase.getInstance().getReference();
    public void connect(String uid){
        if(blank(uid))return; DatabaseReference ref=root.child("userPresence").child(uid); long now=System.currentTimeMillis();
        Map<String,Object> online=new HashMap<>();online.put("state","ONLINE");online.put("lastSeenAt",now);online.put("activeConversationId","");ref.updateChildren(online);
        Map<String,Object> offline=new HashMap<>();offline.put("state","OFFLINE");offline.put("lastSeenAt",com.google.firebase.database.ServerValue.TIMESTAMP);offline.put("activeConversationId","");ref.onDisconnect().setValue(offline);
    }
    public void setActiveConversation(String uid,String conversationId){if(!blank(uid))root.child("userPresence").child(uid).child("activeConversationId").setValue(conversationId==null?"":conversationId);}
    public void disconnect(String uid){if(blank(uid))return;Map<String,Object> value=new HashMap<>();value.put("state","OFFLINE");value.put("lastSeenAt",System.currentTimeMillis());value.put("activeConversationId","");root.child("userPresence").child(uid).updateChildren(value);}
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
}
