package com.example.app.repositories;

import com.example.app.models.Message;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MessageRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

    public void sendText(String conversationId,String senderUid,String receiverUid,String text,String replyToMessageId,MessageCallback callback){
        String clean=text==null?"":text.trim();
        if(blank(conversationId)||blank(senderUid)||blank(receiverUid)||senderUid.equals(receiverUid)||clean.isEmpty()){callback.onError("Enter a message for a valid contact.");return;}
        if(clean.length()>4000){callback.onError("Messages are limited to 4,000 characters.");return;}
        String messageId=root.child("conversationMessages").child(conversationId).push().getKey();
        if(messageId==null){callback.onError("Unable to allocate the message.");return;}
        long now=System.currentTimeMillis(); Message message=Message.text(senderUid,receiverUid,clean,replyToMessageId,now); message.setMessageId(messageId); message.setStatus("SENT");
        Map<String,Object> updates=new HashMap<>();
        updates.put("conversationMessages/"+conversationId+"/"+messageId,message);
        updates.put("conversations/"+conversationId+"/lastMessageId",messageId);
        updates.put("conversations/"+conversationId+"/lastMessageText",preview(clean));
        updates.put("conversations/"+conversationId+"/lastMessageType","TEXT");
        updates.put("conversations/"+conversationId+"/lastMessageSenderUid",senderUid);
        updates.put("conversations/"+conversationId+"/lastMessageAt",now);
        updates.put("conversations/"+conversationId+"/updatedAt",now);
        queueSummary(updates,senderUid,conversationId,receiverUid,clean,senderUid,now,false);
        queueSummary(updates,receiverUid,conversationId,senderUid,clean,senderUid,now,true);
        root.updateChildren(updates,(error,reference)->{if(error==null)callback.onSuccess();else callback.onError(message(error.getMessage(),"Unable to send the message."));});
    }

    private void queueSummary(Map<String,Object> updates,String ownerUid,String conversationId,String otherUid,String text,String senderUid,long now,boolean incrementUnread){
        String base="userConversations/"+ownerUid+"/"+conversationId+"/";
        updates.put(base+"conversationId",conversationId); updates.put(base+"otherParticipantUid",otherUid);
        updates.put(base+"lastMessageText",preview(text)); updates.put(base+"lastMessageType","TEXT"); updates.put(base+"lastMessageSenderUid",senderUid); updates.put(base+"lastMessageAt",now); updates.put(base+"archived",false);
        if(incrementUnread)updates.put(base+"unreadCount",ServerValue.increment(1));
    }

    public Query messageQuery(String conversationId){return root.child("conversationMessages").child(conversationId).orderByChild("sentAt").limitToLast(200);}
    public void listenMessages(String conversationId,ValueEventListener listener){messageQuery(conversationId).addValueEventListener(listener);}
    public void stopListening(String conversationId,ValueEventListener listener){if(!blank(conversationId)&&listener!=null)root.child("conversationMessages").child(conversationId).removeEventListener(listener);}

    public void markDeliveredAndSeen(String conversationId,Message message,String currentUid,boolean seen){
        if(message==null||blank(message.getMessageId())||!currentUid.equals(message.getReceiverUid()))return;
        long now=System.currentTimeMillis(); Map<String,Object> updates=new HashMap<>(); String base="conversationMessages/"+conversationId+"/"+message.getMessageId()+"/";
        if(message.getDeliveredAt()<=0)updates.put(base+"deliveredAt",now);
        if(seen&&message.getSeenAt()<=0){updates.put(base+"seenAt",now);updates.put(base+"seen",true);updates.put(base+"status","SEEN");}
        else if(message.getDeliveredAt()<=0)updates.put(base+"status","DELIVERED");
        if(!updates.isEmpty())root.updateChildren(updates);
    }
    private String preview(String text){String value=text==null?"":text.trim();return value.length()<=100?value:value.substring(0,97)+"…";}
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
    private String message(String value,String fallback){return blank(value)?fallback:value;}
    public interface MessageCallback{void onSuccess();void onError(String message);}
}
