package com.example.app.repositories;


import androidx.annotation.NonNull;


import com.example.app.models.LiveLocation;


import com.google.firebase.database.*;


public class LocationRepository {



    private DatabaseReference database;



    public LocationRepository(){


        database =
                FirebaseDatabase
                        .getInstance()
                        .getReference()
                        .child("liveLocations");


    }




    public void updateLocation(

            String uid,

            LiveLocation location

    ){


        database
                .child(uid)
                .setValue(location);


    }





    public void listenLocation(

            String uid,

            ValueEventListener listener

    ){


        database
                .child(uid)
                .addValueEventListener(
                        listener
                );


    }



}