package com.example.app.repositories;

import android.content.Context;

import androidx.annotation.NonNull;

import com.example.app.auth.AccountAccess;
import com.example.app.auth.AccountCache;
import com.example.app.auth.AccountPolicy;
import com.example.app.auth.EmailKeyEncoder;
import com.example.app.models.ResponderProfile;
import com.example.app.models.RespondentInvitation;
import com.example.app.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;

public class AccountAccessRepository {
    private final FirebaseAuth auth = FirebaseAuth.getInstance();
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private final AccountCache cache;

    public AccountAccessRepository(Context context) {
        cache = new AccountCache(context);
    }

    public void resolveCurrent(boolean allowOffline, Callback callback) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            callback.onRejected("No active HealthMate session was found.");
            return;
        }

        /*
         * Do not reject an account before its database role is known.
         * Normal users may use HealthMate without email verification.
         * Respondent verification is enforced after the role is resolved.
         */
        user.reload()
                .addOnSuccessListener(unused -> {
                    FirebaseUser refreshed = auth.getCurrentUser();
                    if (refreshed == null) {
                        reject("The Firebase session is no longer available.", callback);
                        return;
                    }
                    loadProfile(refreshed, false, callback);
                })
                .addOnFailureListener(error -> {
                    if (allowOffline && isTransient(error)) {
                        User cached = cache.read(user.getUid(), user.getEmail());
                        if (cached != null) {
                            if (AccountPolicy.requiresEmailVerificationForRole(cached.getRole())
                                    && !user.isEmailVerified()) {
                                reject(
                                        "This respondent account must verify its administrator-authorized email before using HealthMate.",
                                        callback
                                );
                                return;
                            }
                            callback.onResolved(new AccountAccess(cached, true));
                            return;
                        }
                        callback.onTemporaryFailure(
                                "You are offline and this account has no previously validated local profile."
                        );
                        return;
                    }
                    reject(message(error, "Unable to refresh this account."), callback);
                });
    }

    private void loadProfile(FirebaseUser firebaseUser, boolean offline, Callback callback) {
        root.child("users")
                .child(firebaseUser.getUid())
                .get()
                .addOnSuccessListener(snapshot -> {
                    User profile = snapshot.getValue(User.class);
                    if (profile == null) {
                        reject("The HealthMate profile for this account was not found.", callback);
                        return;
                    }

                    profile.setUid(firebaseUser.getUid());
                    String role = AccountPolicy.normalizeValue(profile.getRole());

                    if (AccountPolicy.ROLE_USER.equals(role)) {
                        if (!AccountPolicy.isAuthorizedUser(
                                firebaseUser.getEmail(),
                                profile.getRole(),
                                profile.getEmail(),
                                effectiveStatus(profile)
                        )) {
                            reject(
                                    "This user account is inactive or its email profile does not match.",
                                    callback
                            );
                            return;
                        }

                        cache.save(profile);
                        callback.onResolved(new AccountAccess(profile, offline));
                        return;
                    }

                    if (!AccountPolicy.ROLE_RESPONDER.equals(role)) {
                        reject(
                                "This account does not have an authorized HealthMate mobile role.",
                                callback
                        );
                        return;
                    }

                    if (!firebaseUser.isEmailVerified()) {
                        reject(
                                "This respondent account must verify its administrator-authorized email before using HealthMate.",
                                callback
                        );
                        return;
                    }

                    validateRespondent(firebaseUser, profile, offline, callback);
                })
                .addOnFailureListener(error -> {
                    if (offline || isTransient(error)) {
                        User cached = cache.read(firebaseUser.getUid(), firebaseUser.getEmail());
                        if (cached != null) {
                            if (AccountPolicy.requiresEmailVerificationForRole(cached.getRole())
                                    && !firebaseUser.isEmailVerified()) {
                                reject(
                                        "This respondent account must verify its administrator-authorized email before using HealthMate.",
                                        callback
                                );
                                return;
                            }
                            callback.onResolved(new AccountAccess(cached, true));
                            return;
                        }
                    }
                    reject(message(error, "Unable to verify the HealthMate profile."), callback);
                });
    }

    private void validateRespondent(
            FirebaseUser firebaseUser,
            User profile,
            boolean offline,
            Callback callback
    ) {
        String key = profile.getRespondentInvitationKey();
        if (key == null || key.trim().isEmpty()) {
            key = EmailKeyEncoder.encode(firebaseUser.getEmail());
        }
        final String invitationKey = key;

        root.child("respondents")
                .child(firebaseUser.getUid())
                .get()
                .addOnSuccessListener(responderSnapshot -> {
                    ResponderProfile responder = responderSnapshot.getValue(ResponderProfile.class);
                    if (responder == null) {
                        reject("The respondent authorization profile was not found.", callback);
                        return;
                    }

                    root.child("respondentInvitations")
                            .child(invitationKey)
                            .get()
                            .addOnSuccessListener(invitationSnapshot -> {
                                RespondentInvitation invitation =
                                        invitationSnapshot.getValue(RespondentInvitation.class);

                                if (invitation == null) {
                                    reject(
                                            "The respondent invitation is missing or was revoked.",
                                            callback
                                    );
                                    return;
                                }

                                boolean valid = AccountPolicy.isAuthorizedRespondent(
                                        firebaseUser.getUid(),
                                        firebaseUser.getEmail(),
                                        profile.getRole(),
                                        profile.getEmail(),
                                        effectiveStatus(profile),
                                        responder.getAuthUid(),
                                        responder.getEmail(),
                                        responder.getAccountStatus(),
                                        invitation.getNormalizedEmail(),
                                        invitation.getStatus(),
                                        invitation.getRegisteredUid()
                                );

                                if (!valid) {
                                    reject(
                                            "This respondent account is suspended, revoked, or no longer authorized.",
                                            callback
                                    );
                                    return;
                                }

                                new ResponderPresenceRepository().ensurePresence(
                                        firebaseUser.getUid(),
                                        responder.getAvailability(),
                                        new ResponderPresenceRepository.Callback() {
                                            @Override
                                            public void onSuccess() {
                                                cache.save(profile);
                                                callback.onResolved(
                                                        new AccountAccess(profile, offline)
                                                );
                                            }

                                            @Override
                                            public void onError(String message) {
                                                cache.save(profile);
                                                callback.onResolved(
                                                        new AccountAccess(profile, true)
                                                );
                                            }
                                        }
                                );
                            })
                            .addOnFailureListener(error ->
                                    handleReadFailure(firebaseUser, error, callback)
                            );
                })
                .addOnFailureListener(error ->
                        handleReadFailure(firebaseUser, error, callback)
                );
    }

    private void handleReadFailure(FirebaseUser user, Exception error, Callback callback) {
        if (isTransient(error)) {
            User cached = cache.read(user.getUid(), user.getEmail());
            if (cached != null) {
                if (AccountPolicy.requiresEmailVerificationForRole(cached.getRole())
                        && !user.isEmailVerified()) {
                    reject(
                            "This respondent account must verify its administrator-authorized email before using HealthMate.",
                            callback
                    );
                    return;
                }
                callback.onResolved(new AccountAccess(cached, true));
                return;
            }
        }
        reject(message(error, "Unable to verify respondent authorization."), callback);
    }

    private String effectiveStatus(User profile) {
        String status = AccountPolicy.normalizeValue(profile.getAccountStatus());
        return status.isEmpty() ? profile.getStatus() : status;
    }

    private void reject(String message, Callback callback) {
        cache.clear();
        auth.signOut();
        callback.onRejected(message);
    }

    private boolean isTransient(Exception error) {
        String value = error == null || error.getMessage() == null
                ? ""
                : error.getMessage().toLowerCase(Locale.US);
        return value.contains("network")
                || value.contains("offline")
                || value.contains("disconnected")
                || value.contains("unavailable")
                || value.contains("timeout");
    }

    private String message(Exception error, String fallback) {
        return error != null
                && error.getMessage() != null
                && !error.getMessage().trim().isEmpty()
                ? error.getMessage()
                : fallback;
    }

    public interface Callback {
        void onResolved(@NonNull AccountAccess access);
        void onRejected(String message);
        default void onTemporaryFailure(String message) { onRejected(message); }
    }
}
