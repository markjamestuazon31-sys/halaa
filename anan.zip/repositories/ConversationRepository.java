package com.example.app.repositories;

import androidx.annotation.NonNull;

import com.example.app.contacts.ConversationIdPolicy;
import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.Relationship;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConversationRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

    public void ensureConversation(String currentUid, String otherUid, Callback callback) {
        if (blank(currentUid) || blank(otherUid) || currentUid.equals(otherUid)) {
            callback.onError("Two different contacts are required.");
            return;
        }

        root.child("relationships").child(currentUid).child(otherUid).get()
                .addOnSuccessListener(snapshot -> {
                    Relationship relationship = snapshot.getValue(Relationship.class);
                    if (relationship == null
                            || !RelationshipPolicy.canMessage(
                                    relationship.getStatus(),
                                    relationship.isCanMessage()
                            )) {
                        callback.onError(
                                "Messaging is available only for accepted HealthMate contacts."
                        );
                        return;
                    }

                    String conversationId = ConversationIdPolicy.between(
                            currentUid,
                            otherUid
                    );

                    createConversationIfMissing(
                            conversationId,
                            currentUid,
                            otherUid,
                            callback
                    );
                })
                .addOnFailureListener(error -> callback.onError(
                        message(
                                error.getMessage(),
                                "Unable to verify this contact relationship."
                        )
                ));
    }

    private void createConversationIfMissing(
            String conversationId,
            String currentUid,
            String otherUid,
            Callback callback
    ) {
        DatabaseReference conversationReference =
                root.child("conversations").child(conversationId);

        conversationReference.runTransaction(new Transaction.Handler() {
            @NonNull
            @Override
            public Transaction.Result doTransaction(
                    @NonNull MutableData currentData
            ) {
                if (currentData.getValue() != null) {
                    Boolean currentParticipant = currentData
                            .child("participantUids")
                            .child(currentUid)
                            .getValue(Boolean.class);

                    Boolean otherParticipant = currentData
                            .child("participantUids")
                            .child(otherUid)
                            .getValue(Boolean.class);

                    if (!Boolean.TRUE.equals(currentParticipant)
                            || !Boolean.TRUE.equals(otherParticipant)) {
                        return Transaction.abort();
                    }

                    currentData.child("updatedAt")
                            .setValue(System.currentTimeMillis());
                    return Transaction.success(currentData);
                }

                long now = System.currentTimeMillis();
                String participantA = currentUid.compareTo(otherUid) < 0
                        ? currentUid
                        : otherUid;
                String participantB = currentUid.compareTo(otherUid) < 0
                        ? otherUid
                        : currentUid;

                currentData.child("participantUids")
                        .child(currentUid)
                        .setValue(true);
                currentData.child("participantUids")
                        .child(otherUid)
                        .setValue(true);
                currentData.child("participantA").setValue(participantA);
                currentData.child("participantB").setValue(participantB);
                currentData.child("createdAt").setValue(now);
                currentData.child("updatedAt").setValue(now);
                return Transaction.success(currentData);
            }

            @Override
            public void onComplete(
                    DatabaseError error,
                    boolean committed,
                    DataSnapshot currentData
            ) {
                if (error != null) {
                    callback.onError(message(
                            error.getMessage(),
                            "Unable to create the conversation."
                    ));
                    return;
                }

                if (!committed) {
                    callback.onError(
                            "This conversation no longer matches the accepted contact relationship."
                    );
                    return;
                }

                ensureConversationIndexes(
                        conversationId,
                        currentUid,
                        otherUid,
                        callback
                );
            }
        }, false);
    }

    private void ensureConversationIndexes(
            String conversationId,
            String currentUid,
            String otherUid,
            Callback callback
    ) {
        Tasks.whenAllSuccess(
                root.child("userConversations")
                        .child(currentUid)
                        .child(conversationId)
                        .get(),
                root.child("userConversations")
                        .child(otherUid)
                        .child(conversationId)
                        .get()
        ).addOnSuccessListener(results -> {
            @SuppressWarnings("unchecked")
            List<DataSnapshot> snapshots = (List<DataSnapshot>) (List<?>) results;

            Map<String, Object> updates = new HashMap<>();
            addMissingSummary(
                    updates,
                    snapshots.get(0),
                    currentUid,
                    conversationId,
                    otherUid
            );
            addMissingSummary(
                    updates,
                    snapshots.get(1),
                    otherUid,
                    conversationId,
                    currentUid
            );

            if (updates.isEmpty()) {
                callback.onReady(conversationId);
                return;
            }

            root.updateChildren(updates, (error, reference) -> {
                if (error == null) {
                    callback.onReady(conversationId);
                } else {
                    callback.onError(message(
                            error.getMessage(),
                            "Unable to prepare the conversation inbox."
                    ));
                }
            });
        }).addOnFailureListener(error -> callback.onError(message(
                error.getMessage(),
                "Unable to prepare the conversation inbox."
        )));
    }

    private void addMissingSummary(
            Map<String, Object> updates,
            DataSnapshot snapshot,
            String ownerUid,
            String conversationId,
            String otherUid
    ) {
        if (snapshot.exists()) return;

        String base = "userConversations/"
                + ownerUid
                + "/"
                + conversationId
                + "/";

        updates.put(base + "conversationId", conversationId);
        updates.put(base + "otherParticipantUid", otherUid);
        updates.put(base + "unreadCount", 0L);
        updates.put(base + "muted", false);
        updates.put(base + "archived", false);
    }

    public void listenInbox(String uid, ValueEventListener listener) {
        root.child("userConversations")
                .child(uid)
                .orderByChild("lastMessageAt")
                .addValueEventListener(listener);
    }

    public void stopInbox(String uid, ValueEventListener listener) {
        if (!blank(uid) && listener != null) {
            root.child("userConversations")
                    .child(uid)
                    .removeEventListener(listener);
        }
    }

    public void markRead(String uid, String conversationId) {
        if (blank(uid) || blank(conversationId)) return;

        Map<String, Object> updates = new HashMap<>();
        updates.put("unreadCount", 0L);
        updates.put("lastOpenedAt", ServerValue.TIMESTAMP);

        root.child("userConversations")
                .child(uid)
                .child(conversationId)
                .updateChildren(updates);
    }

    public void setMuted(String uid, String conversationId, boolean muted) {
        if (!blank(uid) && !blank(conversationId)) {
            root.child("userConversations")
                    .child(uid)
                    .child(conversationId)
                    .child("muted")
                    .setValue(muted);
        }
    }

    public void setArchived(
            String uid,
            String conversationId,
            boolean archived
    ) {
        if (!blank(uid) && !blank(conversationId)) {
            root.child("userConversations")
                    .child(uid)
                    .child(conversationId)
                    .child("archived")
                    .setValue(archived);
        }
    }

    public void loadPublicProfile(String uid, ProfileCallback callback) {
        root.child("publicProfiles")
                .child(uid)
                .get()
                .addOnSuccessListener(callback::onLoaded)
                .addOnFailureListener(error -> callback.onError(
                        error.getMessage()
                ));
    }

    public void loadPresence(String uid, ProfileCallback callback) {
        root.child("userPresence")
                .child(uid)
                .get()
                .addOnSuccessListener(callback::onLoaded)
                .addOnFailureListener(error -> callback.onError(
                        error.getMessage()
                ));
    }

    private boolean blank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String message(String value, String fallback) {
        return blank(value) ? fallback : value;
    }

    public interface Callback {
        void onReady(String conversationId);
        void onError(String message);
    }

    public interface ProfileCallback {
        void onLoaded(DataSnapshot snapshot);
        void onError(String message);
    }
}
