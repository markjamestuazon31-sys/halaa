package com.example.app.repositories;

import com.example.app.firebase.FirebaseDatabaseManager;
import com.example.app.models.Friend;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class FriendRepository {

    private final DatabaseReference database = FirebaseDatabaseManager.getInstance().getDatabase();
    private final FirebaseAuth auth = FirebaseAuth.getInstance();

    public void sendRequest(String receiverId, CompletionCallback callback) {
        String senderId = auth.getUid();
        if (senderId == null || receiverId == null || receiverId.trim().isEmpty() || senderId.equals(receiverId)) {
            callback.onError("A valid contact is required.");
            return;
        }
        long now = System.currentTimeMillis();
        Friend request = new Friend(senderId, "pending", now);
        database.child("friendRequests").child(receiverId).child(senderId).setValue(request)
                .addOnSuccessListener(unused -> queueRequestNotification(senderId, receiverId, now, callback))
                .addOnFailureListener(error -> callback.onError(safe(error.getMessage(), "Unable to send the contact request.")));
    }

    public void sendRequest(String receiverId) {
        sendRequest(receiverId, new CompletionCallback() {
            @Override public void onSuccess() { }
            @Override public void onError(String message) { }
        });
    }

    private void queueRequestNotification(String senderId, String receiverId, long now, CompletionCallback callback) {
        String requestId = database.child("notificationRequests").push().getKey();
        if (requestId == null) {
            callback.onSuccess();
            return;
        }
        Map<String, Object> notification = new HashMap<>();
        notification.put("targetUserId", receiverId);
        notification.put("title", "New HealthMate contact request");
        notification.put("message", "A HealthMate user scanned your contact QR code.");
        notification.put("type", "contact_request");
        notification.put("createdBy", senderId);
        notification.put("status", "queued");
        notification.put("createdAt", now);
        database.child("notificationRequests").child(requestId).setValue(notification)
                .addOnCompleteListener(unused -> callback.onSuccess());
    }

    public void acceptFriend(String friendId, CompletionCallback callback) {
        String currentId = auth.getUid();
        if (currentId == null || friendId == null || friendId.trim().isEmpty()) {
            callback.onError("A valid contact request is required.");
            return;
        }
        long now = System.currentTimeMillis();
        Map<String, Object> updates = new HashMap<>();
        updates.put("friends/" + currentId + "/" + friendId, new Friend(friendId, "accepted", now));
        updates.put("friends/" + friendId + "/" + currentId, new Friend(currentId, "accepted", now));
        updates.put("friendRequests/" + currentId + "/" + friendId, null);
        database.updateChildren(updates, (error, reference) -> {
            if (error != null) {
                callback.onError(safe(error.getMessage(), "Unable to accept the contact request."));
                return;
            }
            queueAcceptedNotification(currentId, friendId, now);
            callback.onSuccess();
        });
    }

    public void rejectFriend(String friendId, CompletionCallback callback) {
        String currentId = auth.getUid();
        if (currentId == null || friendId == null || friendId.trim().isEmpty()) {
            callback.onError("A valid contact request is required.");
            return;
        }
        database.child("friendRequests").child(currentId).child(friendId).removeValue()
                .addOnSuccessListener(unused -> callback.onSuccess())
                .addOnFailureListener(error -> callback.onError(safe(error.getMessage(), "Unable to reject the request.")));
    }

    private void queueAcceptedNotification(String currentId, String friendId, long now) {
        String requestId = database.child("notificationRequests").push().getKey();
        if (requestId == null) return;
        Map<String, Object> notification = new HashMap<>();
        notification.put("targetUserId", friendId);
        notification.put("title", "Contact request accepted");
        notification.put("message", "You can now message and call this HealthMate contact.");
        notification.put("type", "contact_accepted");
        notification.put("createdBy", currentId);
        notification.put("status", "queued");
        notification.put("createdAt", now);
        database.child("notificationRequests").child(requestId).setValue(notification);
    }

    public void listenRequests(String userId, ValueEventListener listener) {
        database.child("friendRequests").child(userId).addValueEventListener(listener);
    }

    public void listenFriends(String userId, ValueEventListener listener) {
        database.child("friends").child(userId).addValueEventListener(listener);
    }

    public void stopRequests(String userId, ValueEventListener listener) {
        if (userId != null && listener != null) database.child("friendRequests").child(userId).removeEventListener(listener);
    }

    public void stopFriends(String userId, ValueEventListener listener) {
        if (userId != null && listener != null) database.child("friends").child(userId).removeEventListener(listener);
    }

    private String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    public interface CompletionCallback {
        void onSuccess();
        void onError(String message);
    }
}
