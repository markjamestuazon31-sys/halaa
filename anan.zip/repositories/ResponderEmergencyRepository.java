package com.example.app.repositories;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.app.emergency.ResponderSosPolicy;
import com.example.app.models.EmergencyAlert;
import com.example.app.models.ResponderEmergencyItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public class ResponderEmergencyRepository {

    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference emergenciesReference;
    private ValueEventListener emergenciesListener;

    public void listenActiveEmergencies(String responderId, Listener listener) {
        stopListening();
        emergenciesReference = root.child("emergencies");
        emergenciesListener = emergenciesReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<ResponderEmergencyItem> items = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    EmergencyAlert alert = child.getValue(EmergencyAlert.class);
                    if (alert == null || !ResponderSosPolicy.isActive(alert.getStatus())) {
                        continue;
                    }

                    alert.setId(child.getKey());
                    boolean accepted = responderId != null
                            && !responderId.trim().isEmpty()
                            && child.child("responders").child(responderId).exists();
                    items.add(new ResponderEmergencyItem(alert, accepted));
                }

                items.sort(Comparator.comparingLong(
                        (ResponderEmergencyItem item) -> item.getEmergency().getCreatedAt()
                ).reversed());
                listener.onChanged(items);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.onError(error.getMessage());
            }
        });
    }

    public void acceptEmergency(
            EmergencyAlert emergency,
            String responderId,
            String responderName,
            ActionCallback callback
    ) {
        if (emergency == null || emergency.getId() == null || emergency.getId().trim().isEmpty()) {
            callback.onError("The emergency record is invalid.");
            return;
        }
        if (responderId == null || responderId.trim().isEmpty()) {
            callback.onError("The responder session has expired.");
            return;
        }

        String emergencyId = emergency.getId().trim();
        String normalizedResponderId = responderId.trim();
        long acceptedAt = System.currentTimeMillis();
        AtomicReference<String> rejection =
                new AtomicReference<>("This SOS can no longer be accepted.");
        DatabaseReference emergencyReference =
                root.child("emergencies").child(emergencyId);

        emergencyReference.runTransaction(new Transaction.Handler() {
            @NonNull
            @Override
            public Transaction.Result doTransaction(@NonNull MutableData currentData) {
                /*
                 * MutableData has no exists() method. A transaction can initially
                 * receive null before the server value is available, so return the
                 * unchanged value and verify the final DataSnapshot in onComplete().
                 */
                if (currentData.getValue() == null) {
                    rejection.set("The SOS record no longer exists.");
                    return Transaction.success(currentData);
                }

                String status = currentData.child("status").getValue(String.class);
                boolean alreadyAccepted = currentData
                        .child("responders")
                        .hasChild(normalizedResponderId);

                if (!ResponderSosPolicy.canAccept(status, alreadyAccepted)) {
                    rejection.set(alreadyAccepted
                            ? "You already accepted this SOS."
                            : "This SOS is already closed.");
                    return Transaction.abort();
                }

                Map<String, Object> response = new HashMap<>();
                response.put("responderId", normalizedResponderId);
                response.put("responderName", safeName(responderName));
                response.put("status", "Accepted");
                response.put("acceptedAt", acceptedAt);
                response.put("updatedAt", acceptedAt);

                currentData
                        .child("responders")
                        .child(normalizedResponderId)
                        .setValue(response);

                if (status == null
                        || status.trim().isEmpty()
                        || "Received".equalsIgnoreCase(status.trim())) {
                    currentData.child("status").setValue("Responder Assigned");
                }

                currentData.child("updatedAt").setValue(acceptedAt);
                return Transaction.success(currentData);
            }

            @Override
            public void onComplete(
                    @Nullable DatabaseError error,
                    boolean committed,
                    @Nullable DataSnapshot currentData
            ) {
                if (error != null) {
                    callback.onError(error.getMessage());
                    return;
                }

                if (!committed || currentData == null || !currentData.exists()) {
                    callback.onError(rejection.get());
                    return;
                }

                boolean responderWasSaved = currentData
                        .child("responders")
                        .child(normalizedResponderId)
                        .exists();
                if (!responderWasSaved) {
                    callback.onError(rejection.get());
                    return;
                }

                Map<String, Object> updates = new HashMap<>();
                Map<String, Object> indexEntry = new HashMap<>();
                indexEntry.put("emergencyId", emergencyId);
                indexEntry.put("status", "Accepted");
                indexEntry.put("acceptedAt", acceptedAt);
                indexEntry.put("updatedAt", acceptedAt);

                updates.put(
                        "responderEmergencyIndex/"
                                + normalizedResponderId
                                + "/"
                                + emergencyId,
                        indexEntry
                );
                updates.put(
                        "responders/" + normalizedResponderId + "/status",
                        "Assigned"
                );
                updates.put(
                        "responders/" + normalizedResponderId + "/updatedAt",
                        acceptedAt
                );

                root.updateChildren(updates, (updateError, reference) -> {
                    if (updateError == null) {
                        callback.onSuccess();
                    } else {
                        callback.onError(updateError.getMessage());
                    }
                });
            }
        }, false);
    }

    public void stopListening() {
        if (emergenciesReference != null && emergenciesListener != null) {
            emergenciesReference.removeEventListener(emergenciesListener);
        }
        emergenciesReference = null;
        emergenciesListener = null;
    }

    private String safeName(String value) {
        return value == null || value.trim().isEmpty()
                ? "HealthMate responder"
                : value.trim();
    }

    public interface Listener {
        void onChanged(List<ResponderEmergencyItem> emergencies);
        void onError(String message);
    }

    public interface ActionCallback {
        void onSuccess();
        void onError(String message);
    }
}
