package com.example.app.repositories;

import android.content.Context;

import androidx.annotation.NonNull;

import com.example.app.HealthMateApplication;
import com.example.app.auth.AccountAccess;
import com.example.app.auth.AccountCache;
import com.example.app.auth.AccountPolicy;
import com.example.app.firebase.FirebaseDatabaseManager;
import com.example.app.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

public class AuthRepository {

    private final FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    private final DatabaseReference root = FirebaseDatabaseManager.getInstance().getDatabase();
    private final Context context;

    public AuthRepository() {
        Context applicationContext = HealthMateApplication.getInstance();
        if (applicationContext == null) {
            throw new IllegalStateException("HealthMateApplication is not initialized.");
        }
        context = applicationContext.getApplicationContext();
    }

    /** Registers either a normal user or an exact administrator-invited respondent. */
    public void registerUser(User user, String password, AuthCallback callback) {
        if (user == null) {
            callback.onError("Registration details are required.");
            return;
        }

        String email = AccountPolicy.normalizeEmail(user.getEmail());
        user.setEmail(email);

        if (AccountPolicy.isReservedResponderEmail(email)) {
            registerInvitedRespondent(user, password, callback);
        } else {
            registerNormalUser(user, password, callback);
        }
    }

    /**
     * Normal accounts are activated immediately. They are not sent a Firebase
     * verification email and the persisted Firebase session remains signed in.
     */
    private void registerNormalUser(User user, String password, AuthCallback callback) {
        if (!AccountPolicy.canRegisterAsNormalUser(user.getEmail())) {
            callback.onError("Enter a valid non-respondent email address.");
            return;
        }

        long now = System.currentTimeMillis();
        user.setRole(AccountPolicy.ROLE_USER);
        user.setStatus(AccountPolicy.ACCOUNT_ACTIVE);
        user.setAccountStatus(AccountPolicy.ACCOUNT_ACTIVE);
        user.setCreatedAt(now);
        user.setUpdatedAt(now);

        firebaseAuth.createUserWithEmailAndPassword(user.getEmail(), password)
                .addOnSuccessListener(result -> {
                    FirebaseUser firebaseUser = result.getUser();
                    if (firebaseUser == null) {
                        firebaseAuth.signOut();
                        callback.onError("Firebase did not return the created account.");
                        return;
                    }

                    user.setUid(firebaseUser.getUid());
                    root.child("users")
                            .child(firebaseUser.getUid())
                            .setValue(user)
                            .addOnSuccessListener(unused -> callback.onSuccess())
                            .addOnFailureListener(error -> deleteIncompleteAccount(
                                    firebaseUser,
                                    () -> callback.onError(
                                            message(error, "Unable to save the user profile.")
                                    )
                            ));
                })
                .addOnFailureListener(error -> callback.onError(readableAuthError(error)));
    }

    private void registerInvitedRespondent(User user, String password, AuthCallback callback) {
        RespondentInvitationRepository invitationRepository =
                new RespondentInvitationRepository();

        invitationRepository.preflight(
                user.getEmail(),
                new RespondentInvitationRepository.PreflightCallback() {
                    @Override
                    public void onResult(boolean eligible, String invitationKey) {
                        if (!eligible || invitationKey == null) {
                            callback.onError(
                                    "This @respondent.com email was not pre-authorized by an administrator."
                            );
                            return;
                        }

                        firebaseAuth.createUserWithEmailAndPassword(
                                        user.getEmail(),
                                        password
                                )
                                .addOnSuccessListener(result -> {
                                    FirebaseUser firebaseUser = result.getUser();
                                    if (firebaseUser == null) {
                                        firebaseAuth.signOut();
                                        callback.onError(
                                                "Firebase did not return the created respondent account."
                                        );
                                        return;
                                    }

                                    invitationRepository.claim(
                                            firebaseUser,
                                            user,
                                            invitationKey,
                                            new RespondentInvitationRepository.ClaimCallback() {
                                                @Override
                                                public void onClaimed(User profile) {
                                                    sendVerificationForRespondent(
                                                            firebaseUser,
                                                            invitationKey,
                                                            invitationRepository,
                                                            callback
                                                    );
                                                }

                                                @Override
                                                public void onError(String message) {
                                                    deleteIncompleteAccount(
                                                            firebaseUser,
                                                            () -> callback.onError(message)
                                                    );
                                                }
                                            }
                                    );
                                })
                                .addOnFailureListener(error ->
                                        callback.onError(readableAuthError(error))
                                );
                    }

                    @Override
                    public void onError(String message) {
                        callback.onError(message);
                    }
                }
        );
    }

    private void sendVerificationForRespondent(
            FirebaseUser firebaseUser,
            String invitationKey,
            RespondentInvitationRepository invitationRepository,
            AuthCallback callback
    ) {
        firebaseUser.sendEmailVerification().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                firebaseAuth.signOut();
                callback.onSuccess();
                return;
            }

            invitationRepository.rollbackClaim(
                    firebaseUser,
                    invitationKey,
                    new RespondentInvitationRepository.ClaimCallback() {
                        @Override
                        public void onClaimed(User profile) {
                            deleteIncompleteAccount(
                                    firebaseUser,
                                    () -> callback.onError(message(
                                            task.getException(),
                                            "Unable to send the respondent verification email. The invitation was restored."
                                    ))
                            );
                        }

                        @Override
                        public void onError(String rollbackError) {
                            firebaseAuth.signOut();
                            callback.onError(
                                    "Respondent verification failed and the invitation rollback also failed. "
                                            + "Contact the administrator. "
                                            + rollbackError
                            );
                        }
                    }
            );
        });
    }

    public void loginUser(String email, String password, AuthCallback callback) {
        loginUserWithAccess(email, password, new AccessCallback() {
            @Override
            public void onSuccess(@NonNull AccountAccess access) {
                callback.onSuccess();
            }

            @Override
            public void onError(String message) {
                callback.onError(message);
            }

            @Override
            public void onTemporaryError(String message) {
                callback.onTemporaryError(message);
            }
        });
    }

    public void loginUserWithAccess(String email, String password, AccessCallback callback) {
        String normalizedEmail = AccountPolicy.normalizeEmail(email);

        firebaseAuth.signInWithEmailAndPassword(normalizedEmail, password)
                .addOnSuccessListener(result -> {
                    FirebaseUser user = result.getUser();
                    if (user == null) {
                        firebaseAuth.signOut();
                        callback.onError("Firebase did not return a signed-in account.");
                        return;
                    }

                    /*
                     * Resolve the profile before checking email verification.
                     * AccountAccessRepository allows active users immediately and
                     * enforces verification only for respondent accounts.
                     */
                    new AccountAccessRepository(context)
                            .resolveCurrent(false, new AccessAdapter(callback));
                })
                .addOnFailureListener(error -> callback.onError(readableAuthError(error)));
    }

    public void validateCurrentSession(AuthCallback callback) {
        validateCurrentSessionWithAccess(new AccessCallback() {
            @Override
            public void onSuccess(@NonNull AccountAccess access) {
                callback.onSuccess();
            }

            @Override
            public void onError(String message) {
                callback.onError(message);
            }

            @Override
            public void onTemporaryError(String message) {
                callback.onTemporaryError(message);
            }
        });
    }

    public void validateCurrentSessionWithAccess(AccessCallback callback) {
        new AccountAccessRepository(context)
                .resolveCurrent(true, new AccessAdapter(callback));
    }

    public void logout() {
        new AccountCache(context).clear();
        firebaseAuth.signOut();
    }

    private void deleteIncompleteAccount(FirebaseUser user, Runnable after) {
        user.delete().addOnCompleteListener(ignored -> {
            firebaseAuth.signOut();
            after.run();
        });
    }

    private String readableAuthError(Exception error) {
        String value = error == null || error.getMessage() == null
                ? ""
                : error.getMessage();

        if (value.contains("ERROR_EMAIL_ALREADY_IN_USE")
                || value.contains("email address is already in use")) {
            return "That email already has a HealthMate account.";
        }
        if (value.contains("ERROR_INVALID_EMAIL") || value.contains("badly formatted")) {
            return "Enter a valid email address.";
        }
        if (value.contains("ERROR_WRONG_PASSWORD")
                || value.contains("INVALID_LOGIN_CREDENTIALS")
                || value.contains("credential is incorrect")) {
            return "The email or password is incorrect.";
        }
        if (value.contains("ERROR_TOO_MANY_REQUESTS")
                || value.contains("blocked all requests")) {
            return "Too many attempts. Try again later.";
        }
        if (value.toLowerCase().contains("network")) {
            return "A network connection is required for this action.";
        }
        return value.trim().isEmpty()
                ? "The authentication request failed."
                : value;
    }

    private String message(Exception error, String fallback) {
        return error != null
                && error.getMessage() != null
                && !error.getMessage().trim().isEmpty()
                ? error.getMessage()
                : fallback;
    }

    private static final class AccessAdapter implements AccountAccessRepository.Callback {
        private final AccessCallback callback;

        private AccessAdapter(AccessCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onResolved(@NonNull AccountAccess access) {
            callback.onSuccess(access);
        }

        @Override
        public void onRejected(String message) {
            callback.onError(message);
        }

        @Override
        public void onTemporaryFailure(String message) {
            callback.onTemporaryError(message);
        }
    }

    public interface AuthCallback {
        void onSuccess();
        void onError(String message);
        default void onTemporaryError(String message) { onError(message); }
    }

    public interface AccessCallback {
        void onSuccess(@NonNull AccountAccess access);
        void onError(String message);
        default void onTemporaryError(String message) { onError(message); }
    }
}
