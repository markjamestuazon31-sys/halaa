package com.example.app.repositories;

import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.Relationship;
import com.example.app.models.RelationshipRequest;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class RelationshipRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private final FirebaseAuth auth = FirebaseAuth.getInstance();

    public void sendRequest(String targetUid, String relationshipType, Callback callback) {
        String requesterUid = auth.getUid();
        String type = RelationshipPolicy.normalize(relationshipType);
        if (blank(requesterUid) || blank(targetUid) || requesterUid.equals(targetUid) || !RelationshipPolicy.validType(type)) {
            callback.onError("Choose a valid HealthMate contact and relationship type."); return;
        }
        root.child("relationships").child(requesterUid).child(targetUid).get().addOnSuccessListener(existing -> {
            Relationship relationship = existing.getValue(Relationship.class);
            if (relationship != null && RelationshipPolicy.ACCEPTED.equals(RelationshipPolicy.normalize(relationship.getStatus()))) {
                callback.onError("This user is already an accepted HealthMate contact.");
                return;
            }

            String requestId = requesterUid;
            root.child("relationshipRequests").child(targetUid).child(requestId).get()
                    .addOnSuccessListener(requestSnapshot -> {
                        RelationshipRequest existingRequest = requestSnapshot.getValue(RelationshipRequest.class);
                        if (existingRequest != null) {
                            String existingStatus = RelationshipPolicy.normalize(existingRequest.getStatus());
                            if (RelationshipPolicy.PENDING.equals(existingStatus)) {
                                callback.onError("A relationship request is already waiting for this user.");
                            } else if (RelationshipPolicy.ACCEPTED.equals(existingStatus)) {
                                callback.onError("This relationship was already accepted. Refresh your contacts.");
                            } else {
                                callback.onError("The previous relationship request is closed. Ask the other user to scan your QR if a new connection is needed.");
                            }
                            return;
                        }

                        long now = System.currentTimeMillis();
                        RelationshipRequest request = new RelationshipRequest(
                                requestId,
                                requesterUid,
                                targetUid,
                                type,
                                RelationshipPolicy.PENDING,
                                now,
                                now
                        );

                        root.child("relationshipRequests").child(targetUid).child(requestId).setValue(request)
                                .addOnSuccessListener(unused -> callback.onSuccess())
                                .addOnFailureListener(error -> callback.onError(message(error.getMessage(), "Unable to send the relationship request.")));
                    })
                    .addOnFailureListener(error -> callback.onError(message(error.getMessage(), "Unable to check the previous request.")));
        }).addOnFailureListener(error -> callback.onError(message(error.getMessage(), "Unable to check the existing relationship.")));
    }

    public void acceptRequest(RelationshipRequest request, Callback callback) {
        String currentUid = auth.getUid();
        if (request == null || blank(currentUid) || !currentUid.equals(request.getTargetUid()) || !RelationshipPolicy.canAccept(request.getStatus())) {
            callback.onError("This relationship request cannot be accepted."); return;
        }
        long now = System.currentTimeMillis();
        Relationship targetCopy = new Relationship(request.getRequestId(), request.getRequesterUid(), request.getRelationshipType(), RelationshipPolicy.ACCEPTED, true, true, false, request.getCreatedAt(), now);
        Relationship requesterCopy = new Relationship(request.getRequestId(), currentUid, request.getRelationshipType(), RelationshipPolicy.ACCEPTED, true, true, false, request.getCreatedAt(), now);
        Map<String, Object> updates = new HashMap<>();
        updates.put("relationships/" + currentUid + "/" + request.getRequesterUid(), targetCopy);
        updates.put("relationships/" + request.getRequesterUid() + "/" + currentUid, requesterCopy);
        updates.put("relationshipRequests/" + currentUid + "/" + request.getRequestId() + "/status", RelationshipPolicy.ACCEPTED);
        updates.put("relationshipRequests/" + currentUid + "/" + request.getRequestId() + "/updatedAt", now);
        root.updateChildren(updates, (error, reference) -> {
            if (error == null) callback.onSuccess(); else callback.onError(message(error.getMessage(), "Unable to accept the relationship request."));
        });
    }

    public void rejectRequest(RelationshipRequest request, Callback callback) {
        String currentUid = auth.getUid();
        if (request == null || blank(currentUid) || !currentUid.equals(request.getTargetUid())) { callback.onError("This request cannot be rejected."); return; }
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", RelationshipPolicy.REJECTED); updates.put("updatedAt", System.currentTimeMillis());
        root.child("relationshipRequests").child(currentUid).child(request.getRequestId()).updateChildren(updates, (error, reference) -> {
            if (error == null) callback.onSuccess(); else callback.onError(message(error.getMessage(), "Unable to reject the request."));
        });
    }

    public void remove(String contactUid, Callback callback) {
        String uid = auth.getUid();
        if (blank(uid) || blank(contactUid)) { callback.onError("A valid contact is required."); return; }
        long now=System.currentTimeMillis(); Map<String,Object> updates=new HashMap<>();
        updates.put("relationships/"+uid+"/"+contactUid+"/status", RelationshipPolicy.REMOVED);
        updates.put("relationships/"+uid+"/"+contactUid+"/updatedAt", now);
        updates.put("relationships/"+contactUid+"/"+uid+"/status", RelationshipPolicy.REMOVED);
        updates.put("relationships/"+contactUid+"/"+uid+"/updatedAt", now);
        updates.put("contactLocationPermissions/"+uid+"/"+contactUid, null);
        updates.put("contactLocationPermissions/"+contactUid+"/"+uid, null);
        root.updateChildren(updates,(error,reference)->{if(error==null)callback.onSuccess();else callback.onError(message(error.getMessage(),"Unable to remove the contact."));});
    }

    public void listenIncoming(String uid, ValueEventListener listener) { root.child("relationshipRequests").child(uid).addValueEventListener(listener); }
    public void stopIncoming(String uid, ValueEventListener listener) { if (!blank(uid)&&listener!=null) root.child("relationshipRequests").child(uid).removeEventListener(listener); }
    public void listenRelationships(String uid, ValueEventListener listener) { root.child("relationships").child(uid).addValueEventListener(listener); }
    public void stopRelationships(String uid, ValueEventListener listener) { if (!blank(uid)&&listener!=null) root.child("relationships").child(uid).removeEventListener(listener); }
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
    private String message(String value,String fallback){return blank(value)?fallback:value;}
    public interface Callback { void onSuccess(); void onError(String message); }
}
