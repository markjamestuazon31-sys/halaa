package com.example.app.repositories;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.Relationship;

import java.util.HashMap;
import java.util.Map;

public class LocationSharingRepository {
    private final DatabaseReference root=FirebaseDatabase.getInstance().getReference();

    public void setFamilySharing(boolean enabled, Callback callback){
        String uid=FirebaseAuth.getInstance().getUid(); if(blank(uid)){callback.onError("Please sign in again.");return;}
        Map<String,Object> updates=new HashMap<>(); updates.put("familySharingEnabled",enabled); updates.put("updatedAt",System.currentTimeMillis());
        root.child("locationSharingPreferences").child(uid).updateChildren(updates,(error,reference)->{if(error==null)callback.onSuccess();else callback.onError(error.getMessage());});
    }

    public void setSosActive(String uid, boolean active){
        if(blank(uid))return; Map<String,Object> updates=new HashMap<>(); updates.put("sosActive",active); updates.put("updatedAt",System.currentTimeMillis());
        root.child("locationSharingPreferences").child(uid).updateChildren(updates);
    }

    public void setFriendGrant(String contactUid, boolean granted, Callback callback){
        String uid=FirebaseAuth.getInstance().getUid(); if(blank(uid)||blank(contactUid)){callback.onError("A valid friend is required.");return;}
        root.child("relationships").child(uid).child(contactUid).get().addOnSuccessListener(snapshot->{
            Relationship relationship=snapshot.getValue(Relationship.class);
            if(relationship==null||!RelationshipPolicy.ACCEPTED.equals(RelationshipPolicy.normalize(relationship.getStatus()))||!RelationshipPolicy.FRIEND.equals(RelationshipPolicy.normalize(relationship.getRelationshipType()))){callback.onError("Only an accepted friend can receive an individual location grant.");return;}
            long now=System.currentTimeMillis(); Map<String,Object> updates=new HashMap<>();
            updates.put("contactLocationPermissions/"+uid+"/"+contactUid+"/granted",granted);
            updates.put("contactLocationPermissions/"+uid+"/"+contactUid+"/grantedAt",granted?now:0L);
            updates.put("contactLocationPermissions/"+uid+"/"+contactUid+"/updatedAt",now);
            updates.put("relationships/"+uid+"/"+contactUid+"/explicitLocationGrant",granted);
            updates.put("relationships/"+uid+"/"+contactUid+"/updatedAt",now);
            root.updateChildren(updates,(error,reference)->{if(error==null)callback.onSuccess();else callback.onError(error.getMessage());});
        }).addOnFailureListener(error->callback.onError(error.getMessage()));
    }

    public void listenPreferences(String uid, ValueEventListener listener){root.child("locationSharingPreferences").child(uid).addValueEventListener(listener);}
    public void stopPreferences(String uid,ValueEventListener listener){if(!blank(uid)&&listener!=null)root.child("locationSharingPreferences").child(uid).removeEventListener(listener);}

    public void publishingRequired(String uid, PublishingCallback callback){
        if(blank(uid)){callback.onResult(false,false);return;}
        Tasks.whenAllSuccess(
                root.child("locationSharingPreferences").child(uid).get(),
                root.child("contactLocationPermissions").child(uid).get()
        ).addOnSuccessListener(results->{
            DataSnapshot prefs=(DataSnapshot)results.get(0), grants=(DataSnapshot)results.get(1);
            boolean sos=Boolean.TRUE.equals(prefs.child("sosActive").getValue(Boolean.class));
            boolean familyEnabled=Boolean.TRUE.equals(prefs.child("familySharingEnabled").getValue(Boolean.class));
            boolean friendGrant=false;
            for(DataSnapshot child:grants.getChildren())if(Boolean.TRUE.equals(child.child("granted").getValue(Boolean.class))){friendGrant=true;break;}
            // Keep the location component ready whenever the user has explicitly
            // enabled family sharing, even before the first family request is accepted.
            // This avoids an Android background foreground-service start when the
            // relationship is accepted while HealthMate is minimized.
            callback.onResult(sos||familyEnabled||friendGrant,sos);
        }).addOnFailureListener(error->callback.onError(error.getMessage()));
    }
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
    public interface Callback{void onSuccess();void onError(String message);}
    public interface PublishingCallback{void onResult(boolean required,boolean sosActive);default void onError(String message){onResult(false,false);}}
}
