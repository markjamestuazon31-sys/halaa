package com.example.app.repositories;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.example.app.HealthMateApplication;
import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.activities.CallActivity;
import com.example.app.activities.FamilyTrackingMapActivity;
import com.example.app.receivers.CallActionReceiver;
import com.example.app.services.FcmTokenRegistrar;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class EmergencyNotificationService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        FcmTokenRegistrar.saveToken(token);
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        String title = valueOrDefault(
                data.get("title"),
                remoteMessage.getNotification() == null ? null : remoteMessage.getNotification().getTitle(),
                "HealthMate notification"
        );
        String body = valueOrDefault(
                data.get("message"),
                remoteMessage.getNotification() == null ? null : remoteMessage.getNotification().getBody(),
                "You have a new HealthMate update."
        );
        String type = valueOrDefault(data.get("type"), null, "general");
        String userId = data.get("userId");
        String emergencyId = data.get("emergencyId");
        String callId = data.get("callId");
        String createdBy = data.get("createdBy");
        String callType = data.get("callType");
        showNotification(
                title,
                body,
                type,
                userId,
                emergencyId,
                callId,
                createdBy,
                callType
        );
    }

    private void showNotification(
            String title,
            String body,
            String type,
            String userId,
            String emergencyId,
            String callId,
            String createdBy,
            String callType
    ) {
        boolean incomingCall = "incoming_call".equals(type)
                && callId != null
                && !callId.trim().isEmpty();
        boolean emergency = type.startsWith("emergency")
                || "sos".equalsIgnoreCase(type);

        Intent intent;
        if (incomingCall) {
            intent = new Intent(this, CallActivity.class);
            intent.putExtra("callId", callId);
            intent.putExtra("incoming", true);
            intent.putExtra(
                    "callType",
                    "VIDEO".equalsIgnoreCase(callType)
                            || "video".equalsIgnoreCase(callType)
                            ? "video"
                            : "audio"
            );
        } else if ("contact_request".equals(type)
                || "contact_accepted".equals(type)) {
            intent = new Intent(
                    this,
                    com.example.app.activities.EmergencyContactsActivity.class
            );
        } else if ("chat_message".equals(type)
                && createdBy != null
                && !createdBy.trim().isEmpty()) {
            intent = new Intent(
                    this,
                    com.example.app.activities.ChatActivity.class
            );
            intent.putExtra("receiverId", createdBy);
        } else if (emergency) {
            intent = new Intent(this, FamilyTrackingMapActivity.class);
            String emergencyUserId = createdBy != null
                    && !createdBy.trim().isEmpty()
                    ? createdBy
                    : userId;
            intent.putExtra("userId", emergencyUserId);
        } else {
            intent = new Intent(this, MainActivity.class);
        }

        if (!intent.hasExtra("userId")) {
            intent.putExtra("userId", userId);
        }
        intent.putExtra("emergencyId", emergencyId);
        intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
        );

        int requestCode = incomingCall
                ? callId.hashCode()
                : (int) (System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String channelId = incomingCall
                ? HealthMateApplication.CALL_CHANNEL_ID
                : emergency
                ? HealthMateApplication.EMERGENCY_CHANNEL_ID
                : HealthMateApplication.GENERAL_CHANNEL_ID;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                this,
                channelId
        )
                .setSmallIcon(
                        incomingCall
                                ? R.drawable.ic_call
                                : emergency
                                ? R.drawable.ic_warning
                                : R.drawable.ic_notifications
                )
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(
                        incomingCall || emergency
                                ? NotificationCompat.PRIORITY_MAX
                                : NotificationCompat.PRIORITY_DEFAULT
                )
                .setCategory(
                        incomingCall
                                ? NotificationCompat.CATEGORY_CALL
                                : emergency
                                ? NotificationCompat.CATEGORY_ALARM
                                : NotificationCompat.CATEGORY_MESSAGE
                )
                .setVisibility(
                        incomingCall || emergency
                                ? NotificationCompat.VISIBILITY_PUBLIC
                                : NotificationCompat.VISIBILITY_PRIVATE
                )
                .setContentIntent(pendingIntent);

        if (incomingCall) {
            Intent declineIntent = new Intent(this, CallActionReceiver.class)
                    .setAction(CallActionReceiver.ACTION_DECLINE)
                    .putExtra("callId", callId);
            PendingIntent declinePendingIntent = PendingIntent.getBroadcast(
                    this,
                    callId.hashCode() + 1,
                    declineIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT
                            | PendingIntent.FLAG_IMMUTABLE
            );

            builder
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setOnlyAlertOnce(true)
                    .setTimeoutAfter(45_000L)
                    .setFullScreenIntent(pendingIntent, true)
                    .addAction(R.drawable.ic_call, "Answer", pendingIntent)
                    .addAction(
                            android.R.drawable.ic_menu_close_clear_cancel,
                            "Decline",
                            declinePendingIntent
                    );
        } else {
            builder.setAutoCancel(true);
        }

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            int notificationId = incomingCall
                    ? callId.hashCode()
                    : (int) (System.currentTimeMillis() & 0x7fffffff);
            manager.notify(notificationId, builder.build());
        }
    }

    private String valueOrDefault(String first, String second, String fallback) {
        if (first != null && !first.trim().isEmpty()) return first.trim();
        if (second != null && !second.trim().isEmpty()) return second.trim();
        return fallback;
    }
}
