package com.example.app.repositories;

import com.example.app.emergency.ResponderAvailability;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

/** Maintains respondent availability and the sanitized SOS dispatch directory. */
public class ResponderPresenceRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

    public void ensurePresence(String uid, String fallbackAvailability, Callback callback) {
        final String availability = normalizeAvailability(fallbackAvailability);
        root.child("respondentPresence").child(uid).get().addOnSuccessListener(snapshot -> {
            String current = snapshot.child("availability").getValue(String.class);
            String effective = snapshot.exists() ? normalizeAvailability(current) : availability;
            writeAvailability(uid, effective, false, callback);
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }

    public void setAvailability(String uid, ResponderAvailability availability, Callback callback) {
        if (uid == null || uid.trim().isEmpty() || availability == null) {
            callback.onError("A valid respondent and availability are required.");
            return;
        }
        writeAvailability(uid.trim(), availability.name(), true, callback);
    }

    private void writeAvailability(String uid, String availability, boolean updateProfile, Callback callback) {
        long now = System.currentTimeMillis();
        Map<String, Object> updates = new HashMap<>();
        updates.put("respondentPresence/" + uid + "/availability", availability);
        updates.put("respondentPresence/" + uid + "/updatedAt", now);
        updates.put("emergencyDispatchRecipients/responders/" + uid + "/active", true);
        updates.put("emergencyDispatchRecipients/responders/" + uid + "/availability", availability);
        updates.put("emergencyDispatchRecipients/responders/" + uid + "/updatedAt", now);
        if (updateProfile) {
            updates.put("respondents/" + uid + "/availability", availability);
            updates.put("respondents/" + uid + "/updatedAt", now);
        }
        root.updateChildren(updates, (error, reference) -> {
            if (error == null) callback.onSuccess();
            else callback.onError(error.getMessage());
        });
    }

    private String normalizeAvailability(String value) {
        try {
            return ResponderAvailability.valueOf(value == null ? "OFF_DUTY" : value.trim().toUpperCase()).name();
        } catch (IllegalArgumentException error) {
            return ResponderAvailability.OFF_DUTY.name();
        }
    }

    public interface Callback {
        void onSuccess();
        void onError(String message);
    }
}
