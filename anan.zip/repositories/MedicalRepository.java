package com.example.app.repositories;

import com.example.app.models.MedicalProfile;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MedicalRepository {

    private final DatabaseReference profilesReference;

    public MedicalRepository() {
        profilesReference = FirebaseDatabase.getInstance()
                .getReference("medicalProfiles");
    }

    public Task<Void> saveProfile(String userId, MedicalProfile profile) {
        if (userId == null || userId.trim().isEmpty()) {
            return Tasks.forException(new IllegalArgumentException("A signed-in user is required."));
        }
        if (profile == null) {
            return Tasks.forException(new IllegalArgumentException("Medical profile is required."));
        }
        return profilesReference.child(userId).setValue(profile);
    }

    public DatabaseReference getProfile(String userId) {
        return profilesReference.child(userId);
    }
}
