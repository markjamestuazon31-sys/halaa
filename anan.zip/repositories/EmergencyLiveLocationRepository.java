package com.example.app.repositories;

import androidx.annotation.NonNull;
import com.example.app.models.EmergencyLocationPoint;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.LinkedHashMap;
import java.util.Map;

public class EmergencyLiveLocationRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    public void publishPatient(String incidentId, EmergencyLocationPoint point, Callback callback) { write("emergencyLocations/" + incidentId + "/patient", point, callback); }
    public void publishRespondent(String incidentId, String uid, EmergencyLocationPoint point, Callback callback) { write("emergencyLocations/" + incidentId + "/responders/" + uid, point, callback); }
    private void write(String path, EmergencyLocationPoint point, Callback callback) { root.child(path).setValue(point, (error, reference) -> { if (error == null) callback.onSuccess(); else callback.onError(error.getMessage()); }); }
    public ValueEventListener listen(String incidentId, Listener listener) {
        DatabaseReference reference = root.child("emergencyLocations").child(incidentId);
        ValueEventListener valueListener = reference.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                EmergencyLocationPoint patient = snapshot.child("patient").getValue(EmergencyLocationPoint.class);
                Map<String, EmergencyLocationPoint> respondents = new LinkedHashMap<>();
                for (DataSnapshot child : snapshot.child("responders").getChildren()) { EmergencyLocationPoint point = child.getValue(EmergencyLocationPoint.class); if (point != null && child.getKey() != null) respondents.put(child.getKey(), point); }
                listener.onChanged(patient, respondents);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { listener.onError(error.getMessage()); }
        });
        return valueListener;
    }
    public void stopRespondentSharing(String incidentId, String uid, Callback callback) { root.child("emergencyLocations").child(incidentId).child("responders").child(uid).removeValue((error, reference) -> { if (error == null) callback.onSuccess(); else callback.onError(error.getMessage()); }); }
    public interface Callback { void onSuccess(); void onError(String message); }
    public interface Listener { void onChanged(EmergencyLocationPoint patient, Map<String, EmergencyLocationPoint> respondents); void onError(String message); }
}
