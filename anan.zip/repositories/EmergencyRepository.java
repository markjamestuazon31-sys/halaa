package com.example.app.repositories;

import com.example.app.models.EmergencyAlert;

public class EmergencyRepository {

    private final EmergencyAlertRepository repository = new EmergencyAlertRepository();

    public void sendEmergency(EmergencyAlert alert) {
        repository.createAlert(alert);
    }

    public void sendEmergency(EmergencyAlert alert, EmergencyAlertRepository.AlertCallback callback) {
        repository.createAlert(alert, callback);
    }

    public void cancelEmergency(String alertId) {
        repository.updateStatus(alertId, "Cancelled", new EmergencyAlertRepository.AlertCallback() {
            @Override public void onSuccess(String id) { }
            @Override public void onError(String message) { }
        });
    }
}
