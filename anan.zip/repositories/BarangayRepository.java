package com.example.app.repositories;

import androidx.annotation.NonNull;
import com.example.app.models.Barangay;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BarangayRepository {
    private final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("barangays");
    public void listenActive(Listener listener) {
        reference.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Barangay> items = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) { Barangay item = child.getValue(Barangay.class); if (item != null && item.isActive()) { item.setId(child.getKey()); items.add(item); } }
                items.sort(Comparator.comparing(Barangay::getName, String.CASE_INSENSITIVE_ORDER)); listener.onChanged(items);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { listener.onError(error.getMessage()); }
        });
    }
    public interface Listener { void onChanged(List<Barangay> items); void onError(String message); }
}
