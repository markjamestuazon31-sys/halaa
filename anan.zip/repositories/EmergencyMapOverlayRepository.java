package com.example.app.repositories;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.app.emergency.EmergencyOverlayPolicy;
import com.example.app.models.EmergencyIncident;
import com.example.app.models.EmergencyLocationPoint;
import com.example.app.models.EmergencyMapOverlay;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Observes only incidents present in the signed-in viewer's emergency recipient index.
 * Firebase rules remain the final authorization boundary for incident details and coordinates.
 */
public final class EmergencyMapOverlayRepository {

    private final DatabaseReference root =
            FirebaseDatabase.getInstance().getReference();

    private final Map<String, DatabaseReference> incidentReferences =
            new HashMap<>();
    private final Map<String, ValueEventListener> incidentListeners =
            new HashMap<>();
    private final Map<String, DatabaseReference> locationReferences =
            new HashMap<>();
    private final Map<String, ValueEventListener> locationListeners =
            new HashMap<>();
    private final Map<String, EmergencyIncident> incidents =
            new HashMap<>();
    private final Map<String, EmergencyLocationPoint> locations =
            new HashMap<>();

    private DatabaseReference indexReference;
    private ValueEventListener indexListener;
    private Listener listener;

    public void listen(
            @NonNull String viewerUid,
            @NonNull Listener listener
    ) {
        stop();
        this.listener = listener;

        String normalizedUid = viewerUid.trim();
        if (normalizedUid.isEmpty()) {
            listener.onError("A signed-in user is required to load SOS incidents.");
            return;
        }

        indexReference = root.child("emergencyRecipientIndex")
                .child(normalizedUid);
        indexListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Set<String> authorizedIds = new HashSet<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String incidentId = safe(child.getKey());
                    if (!incidentId.isEmpty()) {
                        authorizedIds.add(incidentId);
                    }
                }
                synchronizeIncidentListeners(authorizedIds);
                emit();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Listener current = EmergencyMapOverlayRepository.this.listener;
                if (current != null) {
                    current.onError(nonBlank(
                            error.getMessage(),
                            "Unable to load authorized emergency incidents."
                    ));
                }
            }
        };
        indexReference.addValueEventListener(indexListener);
    }

    private void synchronizeIncidentListeners(Set<String> authorizedIds) {
        Set<String> currentlyObserved =
                new HashSet<>(incidentReferences.keySet());

        for (String incidentId : currentlyObserved) {
            if (!authorizedIds.contains(incidentId)) {
                detachIncident(incidentId);
            }
        }

        for (String incidentId : authorizedIds) {
            if (!incidentReferences.containsKey(incidentId)) {
                attachIncident(incidentId);
            }
        }
    }

    private void attachIncident(String incidentId) {
        DatabaseReference incidentReference = root.child("emergencies")
                .child(incidentId);
        ValueEventListener incidentListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                EmergencyIncident incident =
                        snapshot.getValue(EmergencyIncident.class);
                if (incident == null) {
                    incidents.remove(incidentId);
                } else {
                    incident.setId(incidentId);
                    incidents.put(incidentId, incident);
                }
                emit();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                incidents.remove(incidentId);
                emit();
            }
        };
        incidentReference.addValueEventListener(incidentListener);
        incidentReferences.put(incidentId, incidentReference);
        incidentListeners.put(incidentId, incidentListener);

        DatabaseReference locationReference = root.child("emergencyLocations")
                .child(incidentId)
                .child("patient");
        ValueEventListener locationListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                EmergencyLocationPoint location =
                        snapshot.getValue(EmergencyLocationPoint.class);
                if (location == null) {
                    locations.remove(incidentId);
                } else {
                    locations.put(incidentId, location);
                }
                emit();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                locations.remove(incidentId);
                emit();
            }
        };
        locationReference.addValueEventListener(locationListener);
        locationReferences.put(incidentId, locationReference);
        locationListeners.put(incidentId, locationListener);
    }

    private void detachIncident(String incidentId) {
        DatabaseReference incidentReference =
                incidentReferences.remove(incidentId);
        ValueEventListener incidentListener =
                incidentListeners.remove(incidentId);
        if (incidentReference != null && incidentListener != null) {
            incidentReference.removeEventListener(incidentListener);
        }

        DatabaseReference locationReference =
                locationReferences.remove(incidentId);
        ValueEventListener locationListener =
                locationListeners.remove(incidentId);
        if (locationReference != null && locationListener != null) {
            locationReference.removeEventListener(locationListener);
        }

        incidents.remove(incidentId);
        locations.remove(incidentId);
    }

    private void emit() {
        Listener current = listener;
        if (current == null) {
            return;
        }

        List<EmergencyMapOverlay> overlays = new ArrayList<>();
        for (Map.Entry<String, EmergencyIncident> entry : incidents.entrySet()) {
            EmergencyIncident incident = entry.getValue();
            if (incident == null
                    || !EmergencyOverlayPolicy.isActiveStatus(
                            incident.getStatus()
                    )) {
                continue;
            }

            EmergencyMapOverlay overlay = new EmergencyMapOverlay();
            overlay.setIncidentId(entry.getKey());
            overlay.setPatientUid(safe(incident.getPatientUid()));
            overlay.setPatientName(nonBlank(
                    incident.getPatientName(),
                    "HealthMate contact"
            ));
            overlay.setStatus(nonBlank(incident.getStatus(), "PENDING"));
            overlay.setSeverity(nonBlank(incident.getSeverity(), "HIGH"));
            overlay.setPriority(nonBlank(incident.getPriority(), "HIGH"));
            overlay.setCreatedAt(incident.getCreatedAt());
            overlay.setUpdatedAt(incident.getUpdatedAt());
            overlay.setPatientLocation(locations.get(entry.getKey()));
            overlays.add(overlay);
        }

        overlays.sort(Comparator.comparingLong(
                EmergencyMapOverlay::getCreatedAt
        ).reversed());
        current.onChanged(Collections.unmodifiableList(overlays));
    }

    public void stop() {
        if (indexReference != null && indexListener != null) {
            indexReference.removeEventListener(indexListener);
        }
        indexReference = null;
        indexListener = null;

        for (String incidentId : new ArrayList<>(incidentReferences.keySet())) {
            detachIncident(incidentId);
        }
        incidents.clear();
        locations.clear();
        listener = null;
    }

    private static String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }

    private static String nonBlank(
            @Nullable String value,
            @NonNull String fallback
    ) {
        String normalized = safe(value);
        return normalized.isEmpty() ? fallback : normalized;
    }

    public interface Listener {
        void onChanged(@NonNull List<EmergencyMapOverlay> emergencies);
        void onError(@NonNull String message);
    }
}
