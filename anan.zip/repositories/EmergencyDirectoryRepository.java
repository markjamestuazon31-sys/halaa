package com.example.app.repositories;

import androidx.annotation.Nullable;
import com.example.app.emergency.DirectoryMerger;
import com.example.app.models.EmergencyDirectoryContact;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmergencyDirectoryRepository {
    private final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    public void loadForIncident(String incidentId, Listener callback) {
        root.child("emergencies").child(incidentId).get().addOnSuccessListener(incident -> {
            String barangayId = string(incident, "assignedBarangayId");
            Task<DataSnapshot> local = root.child("barangays").child(barangayId).child("emergencyContacts").get();
            Task<DataSnapshot> global = root.child("globalEmergencyContacts").get();
            Tasks.whenAllComplete(local, global).addOnCompleteListener(ignored -> {
                List<EmergencyDirectoryContact> localItems = parse(local.isSuccessful() ? local.getResult() : null);
                List<EmergencyDirectoryContact> globalItems = parse(global.isSuccessful() ? global.getResult() : null);
                callback.onLoaded(DirectoryMerger.merge(localItems, globalItems), localItems.isEmpty(), barangayId);
            });
        }).addOnFailureListener(error -> callback.onError(error.getMessage()));
    }
    public void recordCallAction(String incidentId, EmergencyDirectoryContact contact, String respondentUid, Callback callback) {
        String id = root.child("emergencyAgencyActions").child(incidentId).push().getKey();
        if (id == null) { callback.onError("Unable to allocate the call action record."); return; }
        long now = System.currentTimeMillis(); Map<String, Object> action = new HashMap<>(); action.put("incidentId", incidentId); action.put("contactId", contact.getId()); action.put("agency", contact.getOrganizationName()); action.put("phone", contact.getPhone()); action.put("respondentUid", respondentUid); action.put("action", "DIALER_OPENED"); action.put("timestamp", now);
        root.child("emergencyAgencyActions").child(incidentId).child(id).setValue(action, (error, reference) -> { if (error == null) callback.onSuccess(); else callback.onError(error.getMessage()); });
    }
    private List<EmergencyDirectoryContact> parse(@Nullable DataSnapshot snapshot) { List<EmergencyDirectoryContact> result = new ArrayList<>(); if (snapshot == null) return result; for (DataSnapshot child : snapshot.getChildren()) { EmergencyDirectoryContact item = child.getValue(EmergencyDirectoryContact.class); if (item != null && item.isActive()) { item.setId(child.getKey()); result.add(item); } } return result; }
    private String string(DataSnapshot snapshot, String child) { String value = snapshot.child(child).getValue(String.class); return value == null ? "" : value.trim(); }
    public interface Listener { void onLoaded(List<EmergencyDirectoryContact> contacts, boolean barangayDirectoryMissing, String barangayId); void onError(String message); }
    public interface Callback { void onSuccess(); void onError(String message); }
}
