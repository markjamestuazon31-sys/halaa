package com.example.app.repositories;

import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class AnnouncementRepository {

    public Query getLatestAnnouncements() {
        return FirebaseDatabase.getInstance()
                .getReference("announcements")
                .orderByChild("createdAt")
                .limitToLast(100);
    }
}
