package com.example.app.adapters;

import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.models.EmergencyAlert;
import com.example.app.models.ResponderEmergencyItem;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ResponderEmergencyAdapter
        extends RecyclerView.Adapter<ResponderEmergencyAdapter.ViewHolder> {

    private final List<ResponderEmergencyItem> items = new ArrayList<>();
    private final Listener listener;
    private String busyEmergencyId = "";

    public ResponderEmergencyAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<ResponderEmergencyItem> emergencies) {
        items.clear();
        if (emergencies != null) items.addAll(emergencies);
        notifyDataSetChanged();
    }

    public void setBusyEmergencyId(String emergencyId) {
        busyEmergencyId = emergencyId == null ? "" : emergencyId;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_responder_sos, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ResponderEmergencyItem item = items.get(position);
        EmergencyAlert emergency = item.getEmergency();
        boolean accepted = item.isAcceptedByCurrentResponder();
        boolean busy = emergency.getId() != null && emergency.getId().equals(busyEmergencyId);

        holder.name.setText(safe(emergency.getUserName(), "HealthMate user"));
        holder.type.setText(safe(emergency.getType(), "SOS Alert"));
        holder.description.setText(safe(
                emergency.getDescription(),
                "Emergency assistance requested from the HealthMate mobile app."
        ));
        holder.status.setText(safe(emergency.getStatus(), "Received"));
        holder.time.setText(relativeTime(emergency.getCreatedAt()));
        holder.coordinates.setText(String.format(
                Locale.US,
                "%.5f, %.5f",
                latitude(emergency),
                longitude(emergency)
        ));

        holder.accept.setEnabled(!accepted && !busy);
        holder.accept.setText(accepted
                ? R.string.responder_sos_accepted
                : busy
                ? R.string.responder_sos_accepting
                : R.string.responder_sos_accept);
        holder.accept.setOnClickListener(view -> listener.onAccept(item));
        holder.openMap.setOnClickListener(view -> listener.onOpenMap(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private double latitude(EmergencyAlert emergency) {
        return emergency.getLocation() == null
                ? emergency.getLatitude()
                : emergency.getLocation().getLatitude();
    }

    private double longitude(EmergencyAlert emergency) {
        return emergency.getLocation() == null
                ? emergency.getLongitude()
                : emergency.getLocation().getLongitude();
    }

    private String relativeTime(long createdAt) {
        if (createdAt <= 0L) return "Time unavailable";
        return DateUtils.getRelativeTimeSpanString(
                createdAt,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS,
                DateUtils.FORMAT_ABBREV_RELATIVE
        ).toString();
    }

    private String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    static final class ViewHolder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView type;
        final TextView description;
        final TextView status;
        final TextView time;
        final TextView coordinates;
        final MaterialButton accept;
        final MaterialButton openMap;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.responderSosUserName);
            type = itemView.findViewById(R.id.responderSosType);
            description = itemView.findViewById(R.id.responderSosDescription);
            status = itemView.findViewById(R.id.responderSosStatus);
            time = itemView.findViewById(R.id.responderSosTime);
            coordinates = itemView.findViewById(R.id.responderSosCoordinates);
            accept = itemView.findViewById(R.id.responderSosAcceptButton);
            openMap = itemView.findViewById(R.id.responderSosMapButton);
        }
    }

    public interface Listener {
        void onAccept(ResponderEmergencyItem item);
        void onOpenMap(ResponderEmergencyItem item);
    }
}
