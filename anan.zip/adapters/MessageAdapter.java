package com.example.app.adapters;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app.R;
import com.example.app.models.Message;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder>{
    private final ArrayList<Message> messages;private final String currentUser;private final DateFormat timeFormat=DateFormat.getTimeInstance(DateFormat.SHORT);private final Listener listener;
    public MessageAdapter(ArrayList<Message> messages,String currentUser,Listener listener){this.messages=messages;this.currentUser=currentUser;this.listener=listener;}
    @NonNull @Override public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,int viewType){return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message,parent,false));}
    @Override public void onBindViewHolder(@NonNull ViewHolder h,int position){Message message=messages.get(position);boolean own=currentUser!=null&&currentUser.equals(message.getSenderUid());h.text.setText(message.getText());h.time.setText(timeFormat.format(new Date(message.getSentAt())));h.container.setGravity(own?Gravity.END:Gravity.START);h.content.setGravity(own?Gravity.END:Gravity.START);h.meta.setGravity(own?Gravity.END:Gravity.START);h.reply.setVisibility(blank(message.getReplyToMessageId())?View.GONE:View.VISIBLE);h.reply.setText("Reply to an earlier message");if(own){h.avatar.setVisibility(View.GONE);h.text.setBackgroundResource(R.drawable.bg_chat_message_outgoing);h.text.setTextColor(ContextCompat.getColor(h.itemView.getContext(),R.color.hm_chat_outgoing_text));h.status.setVisibility(View.VISIBLE);h.status.setText(status(message));}else{h.avatar.setVisibility(View.VISIBLE);h.text.setBackgroundResource(R.drawable.bg_chat_message_incoming);h.text.setTextColor(ContextCompat.getColor(h.itemView.getContext(),R.color.hm_chat_incoming_text));h.status.setVisibility(View.GONE);}h.itemView.setOnLongClickListener(v->{if(listener!=null)listener.onReply(message);return true;});}
    private String status(Message message){String value=message.getStatus();if("SEEN".equalsIgnoreCase(value)||message.isSeen())return"✓✓ Seen";if("DELIVERED".equalsIgnoreCase(value)||message.getDeliveredAt()>0)return"✓✓";if("SENDING".equalsIgnoreCase(value))return"Sending…";if("FAILED".equalsIgnoreCase(value))return"Failed";return"✓";}
    @Override public int getItemCount(){return messages.size();}
    private boolean blank(String value){return value==null||value.trim().isEmpty();}
    static class ViewHolder extends RecyclerView.ViewHolder{final LinearLayout container,content,meta;final ImageView avatar;final TextView reply,text,time,status;ViewHolder(View v){super(v);container=v.findViewById(R.id.messageContainer);avatar=v.findViewById(R.id.messageAvatar);content=v.findViewById(R.id.messageContent);reply=v.findViewById(R.id.messageReply);text=v.findViewById(R.id.messageText);meta=v.findViewById(R.id.messageMeta);time=v.findViewById(R.id.messageTime);status=v.findViewById(R.id.messageStatus);}}
    public interface Listener{void onReply(Message message);}
}
