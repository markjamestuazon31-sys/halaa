package com.example.app.adapters;

import android.graphics.Bitmap;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.app.R;
import com.example.app.models.ConversationSummary;
import com.example.app.utils.Base64Manager;
import java.util.ArrayList;
import java.util.List;

public class ConversationAdapter extends RecyclerView.Adapter<ConversationAdapter.Holder>{
    private final List<ConversationSummary> items=new ArrayList<>();private final Listener listener;
    public ConversationAdapter(Listener listener){this.listener=listener;}
    public void submit(List<ConversationSummary> values){items.clear();if(values!=null)items.addAll(values);notifyDataSetChanged();}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int viewType){return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_conversation,parent,false));}
    @Override public void onBindViewHolder(@NonNull Holder h,int position){ConversationSummary item=items.get(position);h.name.setText(safe(item.getDisplayName(),"HealthMate contact"));h.preview.setText(safe(item.getLastMessageText(),"Start a secure conversation"));h.time.setText(item.getLastMessageAt()<=0?"":DateUtils.getRelativeTimeSpanString(item.getLastMessageAt(),System.currentTimeMillis(),DateUtils.MINUTE_IN_MILLIS,DateUtils.FORMAT_ABBREV_RELATIVE));h.badge.setVisibility(item.getUnreadCount()>0?View.VISIBLE:View.GONE);h.badge.setText(item.getUnreadCount()>99?"99+":String.valueOf(item.getUnreadCount()));h.presence.setText("ONLINE".equals(item.getPresenceState())?"Online":item.getLastSeenAt()>0?"Last seen "+DateUtils.getRelativeTimeSpanString(item.getLastSeenAt(),System.currentTimeMillis(),DateUtils.MINUTE_IN_MILLIS,DateUtils.FORMAT_ABBREV_RELATIVE):safe(item.getRelationshipType(),"Contact"));Bitmap bitmap=Base64Manager.base64ToBitmap(item.getProfileImage());if(bitmap!=null){h.avatar.setPadding(0,0,0,0);h.avatar.setImageBitmap(bitmap);h.avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);}else{h.avatar.setImageResource(R.drawable.ic_person);h.avatar.setPadding(13,13,13,13);}h.itemView.setOnClickListener(v->listener.onOpen(item));h.itemView.setOnLongClickListener(v->{listener.onOptions(item,v);return true;});}
    @Override public int getItemCount(){return items.size();}
    private String safe(String value,String fallback){return value==null||value.trim().isEmpty()?fallback:value.trim();}
    static class Holder extends RecyclerView.ViewHolder{ImageView avatar;TextView name,preview,time,badge,presence;Holder(View v){super(v);avatar=v.findViewById(R.id.conversationAvatar);name=v.findViewById(R.id.conversationName);preview=v.findViewById(R.id.conversationPreview);time=v.findViewById(R.id.conversationTime);badge=v.findViewById(R.id.conversationUnread);presence=v.findViewById(R.id.conversationPresence);}}
    public interface Listener{void onOpen(ConversationSummary item);void onOptions(ConversationSummary item,View anchor);}
}
