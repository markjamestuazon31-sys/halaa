package com.example.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.models.Medication;
import com.google.android.material.materialswitch.MaterialSwitch;

import java.util.List;

public class MedicationAdapter
        extends RecyclerView.Adapter<MedicationAdapter.ViewHolder> {

    public interface Listener {
        void onEdit(Medication medication);
        void onDelete(Medication medication);
        void onReminderChanged(Medication medication, boolean enabled);
    }

    private final List<Medication> items;
    private final Listener listener;

    public MedicationAdapter(
            List<Medication> items,
            Listener listener
    ) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view =
                LayoutInflater.from(parent.getContext())
                        .inflate(
                                R.layout.item_medication,
                                parent,
                                false
                        );
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position
    ) {
        Medication medication = items.get(position);
        holder.name.setText(
                safe(medication.getName(), "Medication")
        );
        holder.dosage.setText(
                safe(medication.getDosage(), "No dosage entered")
        );
        holder.schedule.setText(
                safe(
                        medication.getSchedule(),
                        "No reminder time"
                )
                        + " • "
                        + safe(medication.getFrequency(), "Daily")
        );

        holder.reminderSwitch.setOnCheckedChangeListener(null);
        holder.reminderSwitch.setChecked(
                medication.isActive()
                        && medication.isReminderEnabled()
        );
        holder.reminderSwitch.setOnCheckedChangeListener(
                (buttonView, checked) ->
                        listener.onReminderChanged(
                                medication,
                                checked
                        )
        );
        holder.edit.setOnClickListener(
                view -> listener.onEdit(medication)
        );
        holder.delete.setOnClickListener(
                view -> listener.onDelete(medication)
        );
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private static String safe(
            String value,
            String fallback
    ) {
        return value == null || value.trim().isEmpty()
                ? fallback
                : value.trim();
    }

    static final class ViewHolder
            extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView dosage;
        final TextView schedule;
        final MaterialSwitch reminderSwitch;
        final ImageButton edit;
        final ImageButton delete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(
                    R.id.medicationItemName
            );
            dosage = itemView.findViewById(
                    R.id.medicationItemDosage
            );
            schedule = itemView.findViewById(
                    R.id.medicationItemSchedule
            );
            reminderSwitch = itemView.findViewById(
                    R.id.medicationReminderSwitch
            );
            edit = itemView.findViewById(
                    R.id.editMedicationButton
            );
            delete = itemView.findViewById(
                    R.id.deleteMedicationButton
            );
        }
    }
}
