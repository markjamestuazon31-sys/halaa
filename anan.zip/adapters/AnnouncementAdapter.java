package com.example.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.models.Announcement;
import com.example.app.utils.AnnouncementImageLoader;
import com.google.android.material.card.MaterialCardView;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class AnnouncementAdapter extends RecyclerView.Adapter<AnnouncementAdapter.ViewHolder> {

    public interface Listener {
        void onSelected(Announcement announcement);
    }

    private final List<Announcement> items;
    private final Listener listener;
    private final DateFormat dateFormat = DateFormat.getDateTimeInstance(
            DateFormat.MEDIUM,
            DateFormat.SHORT
    );

    public AnnouncementAdapter(List<Announcement> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.item_announcement,
                        parent,
                        false
                )
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Announcement item = items.get(position);
        holder.title.setText(safe(item.getTitle(), "Community announcement"));
        holder.content.setText(safe(item.getContent(), "Open for details."));
        holder.category.setText(safe(item.getCategory(), "Barangay News"));
        holder.time.setText(
                item.getCreatedAt() > 0
                        ? dateFormat.format(new Date(item.getCreatedAt()))
                        : "Recently"
        );
        AnnouncementImageLoader.load(holder.image, item.getImageData());
        holder.card.setOnClickListener(view -> listener.onSelected(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private static String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    static final class ViewHolder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView image;
        final TextView title;
        final TextView content;
        final TextView category;
        final TextView time;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            card = (MaterialCardView) itemView;
            image = itemView.findViewById(R.id.announcementImage);
            title = itemView.findViewById(R.id.announcementTitle);
            content = itemView.findViewById(R.id.announcementContent);
            category = itemView.findViewById(R.id.announcementCategory);
            time = itemView.findViewById(R.id.announcementTime);
        }
    }
}
