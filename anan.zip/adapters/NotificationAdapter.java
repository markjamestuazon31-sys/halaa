package com.example.app.adapters;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.models.NotificationModel;
import com.example.app.notifications.NotificationCategory;
import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotificationAdapter
        extends ListAdapter<NotificationModel, NotificationAdapter.NotificationHolder> {

    public interface Listener {
        void onNotificationSelected(@NonNull NotificationModel notification);
    }

    private static final DiffUtil.ItemCallback<NotificationModel> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<NotificationModel>() {
                @Override
                public boolean areItemsTheSame(
                        @NonNull NotificationModel oldItem,
                        @NonNull NotificationModel newItem
                ) {
                    String oldId = oldItem.getId();
                    String newId = newItem.getId();
                    if (oldId == null || newId == null) {
                        return oldItem == newItem;
                    }
                    return oldId.equals(newId);
                }

                @Override
                public boolean areContentsTheSame(
                        @NonNull NotificationModel oldItem,
                        @NonNull NotificationModel newItem
                ) {
                    return oldItem.equals(newItem);
                }
            };

    private final Listener listener;
    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault());

    public NotificationAdapter(@NonNull Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
        setHasStableIds(true);
    }

    @Override
    public long getItemId(int position) {
        String id = getItem(position).getId();
        return id == null ? RecyclerView.NO_ID : id.hashCode();
    }

    @NonNull
    @Override
    public NotificationHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notification, parent, false);
        return new NotificationHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull NotificationHolder holder,
            int position
    ) {
        NotificationModel notification = getItem(position);
        holder.bind(notification);
    }

    final class NotificationHolder extends RecyclerView.ViewHolder {

        private final MaterialCardView card;
        private final ImageView icon;
        private final TextView title;
        private final TextView body;
        private final TextView time;
        private final View unreadDot;

        NotificationHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.notificationItemCard);
            icon = itemView.findViewById(R.id.notificationItemIcon);
            title = itemView.findViewById(R.id.notificationItemTitle);
            body = itemView.findViewById(R.id.notificationItemBody);
            time = itemView.findViewById(R.id.notificationItemTime);
            unreadDot = itemView.findViewById(R.id.notificationItemUnreadDot);
        }

        void bind(@NonNull NotificationModel notification) {
            title.setText(notification.getDisplayTitle());
            body.setText(notification.getDisplayMessage());

            long timestamp = notification.getDisplayTimestamp();
            time.setText(
                    timestamp > 0L
                            ? dateFormat.format(new Date(timestamp))
                            : itemView.getContext().getString(R.string.hm_notify_time_unknown)
            );

            unreadDot.setVisibility(notification.isRead() ? View.INVISIBLE : View.VISIBLE);
            card.setStrokeWidth(notification.isRead() ? 0 : dpToPx(1));
            card.setStrokeColor(
                    ContextCompat.getColor(
                            itemView.getContext(),
                            notification.isRead()
                                    ? android.R.color.transparent
                                    : R.color.hm_notify_teal_soft_strong
                    )
            );

            NotificationCategory category =
                    NotificationCategory.fromType(notification.getType());
            int iconResource;
            int iconTint;

            if (category == NotificationCategory.CALLS) {
                iconResource = R.drawable.ic_notify_call_24;
                iconTint = R.color.hm_notify_call;
            } else if (category == NotificationCategory.ACCOUNT) {
                iconResource = R.drawable.ic_notify_person_24;
                iconTint = R.color.hm_notify_account;
            } else if ("announcement".equals(notification.getType())) {
                iconResource = R.drawable.ic_notify_campaign_24;
                iconTint = R.color.hm_notify_teal;
            } else if (notification.getType() != null
                    && notification.getType().startsWith("emergency")) {
                iconResource = R.drawable.ic_notify_warning_24;
                iconTint = R.color.hm_notify_emergency;
            } else if ("chat_message".equals(notification.getType())) {
                iconResource = R.drawable.ic_notify_chat_24;
                iconTint = R.color.hm_notify_chat;
            } else {
                iconResource = R.drawable.ic_notify_bell_24;
                iconTint = R.color.hm_notify_teal;
            }

            icon.setImageResource(iconResource);
            icon.setImageTintList(
                    ColorStateList.valueOf(
                            ContextCompat.getColor(itemView.getContext(), iconTint)
                    )
            );

            itemView.setOnClickListener(view ->
                    listener.onNotificationSelected(notification)
            );
        }

        private int dpToPx(int dp) {
            float density = itemView.getResources().getDisplayMetrics().density;
            return Math.round(dp * density);
        }
    }
}
