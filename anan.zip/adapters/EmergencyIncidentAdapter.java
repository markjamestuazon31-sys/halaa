package com.example.app.adapters;

import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.models.EmergencyIncident;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Limited SOS queue view: exact coordinates are intentionally omitted. */
public class EmergencyIncidentAdapter extends RecyclerView.Adapter<EmergencyIncidentAdapter.Holder> {
    private final List<EmergencyIncident> items = new ArrayList<>();
    private final Set<String> acceptedIncidentIds = new HashSet<>();
    private final Listener listener;
    private String currentUid = "";
    private String busyIncidentId = "";

    public EmergencyIncidentAdapter(Listener listener) { this.listener = listener; }

    public void submit(List<EmergencyIncident> incidents, Set<String> acceptedIds, String uid) {
        items.clear();
        if (incidents != null) items.addAll(incidents);
        acceptedIncidentIds.clear();
        if (acceptedIds != null) acceptedIncidentIds.addAll(acceptedIds);
        currentUid = uid == null ? "" : uid;
        notifyDataSetChanged();
    }

    public void setBusy(String incidentId) {
        busyIncidentId = incidentId == null ? "" : incidentId;
        notifyDataSetChanged();
    }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_emergency_incident, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder holder, int position) {
        EmergencyIncident incident = items.get(position);
        boolean own = currentUid.equals(incident.getPatientUid());
        boolean accepted = acceptedIncidentIds.contains(incident.getId());
        boolean busy = incident.getId() != null && incident.getId().equals(busyIncidentId);
        holder.patient.setText(nonBlank(incident.getPatientName(), "HealthMate patient"));
        holder.type.setText(nonBlank(incident.getType(), "Emergency SOS"));
        holder.status.setText(nonBlank(incident.getStatus(), "PENDING").replace('_', ' '));
        holder.location.setText(locationSummary(incident));
        holder.time.setText(relative(incident.getCreatedAt()));
        holder.accept.setEnabled(!own && !accepted && !busy);
        holder.accept.setText(own ? R.string.respondent_own_sos : accepted ? R.string.responder_sos_accepted : busy ? R.string.responder_sos_accepting : R.string.responder_sos_accept);
        holder.accept.setOnClickListener(v -> listener.onAccept(incident));
        holder.open.setText(accepted ? R.string.respondent_open_case : R.string.respondent_view_summary);
        holder.open.setOnClickListener(v -> listener.onOpen(incident, accepted));
        holder.itemView.setOnClickListener(v -> listener.onOpen(incident, accepted));
    }

    private String locationSummary(EmergencyIncident incident) {
        Map<String, Object> summary = incident.getLocationSummary();
        if (summary == null) return "Location summary unavailable";
        Object name = summary.get("barangayName");
        if (name != null && !String.valueOf(name).trim().isEmpty()) return "Barangay: " + name;
        Object id = summary.get("barangayId");
        return id == null || String.valueOf(id).trim().isEmpty() ? "Barangay not assigned" : "Barangay ID: " + id;
    }

    private String relative(long time) {
        if (time <= 0) return "Time unavailable";
        return String.valueOf(DateUtils.getRelativeTimeSpanString(time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS));
    }
    private String nonBlank(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value.trim(); }

    @Override public int getItemCount() { return items.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView patient, type, status, location, time;
        final MaterialButton accept, open;
        Holder(View itemView) {
            super(itemView);
            patient = itemView.findViewById(R.id.incidentPatient);
            type = itemView.findViewById(R.id.incidentType);
            status = itemView.findViewById(R.id.incidentStatus);
            location = itemView.findViewById(R.id.incidentLocationSummary);
            time = itemView.findViewById(R.id.incidentTime);
            accept = itemView.findViewById(R.id.incidentAccept);
            open = itemView.findViewById(R.id.incidentOpen);
        }
    }

    public interface Listener {
        void onAccept(EmergencyIncident incident);
        void onOpen(EmergencyIncident incident, boolean accepted);
    }
}
