package com.example.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.models.EmergencyDirectoryContact;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class EmergencyDirectoryAdapter extends RecyclerView.Adapter<EmergencyDirectoryAdapter.Holder> {
    private final List<EmergencyDirectoryContact> items = new ArrayList<>();
    private final Listener listener;
    public EmergencyDirectoryAdapter(Listener listener) { this.listener = listener; }
    public void submit(List<EmergencyDirectoryContact> values) { items.clear(); if (values != null) items.addAll(values); notifyDataSetChanged(); }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_emergency_directory_contact, parent, false)); }
    @Override public void onBindViewHolder(@NonNull Holder h, int p) {
        EmergencyDirectoryContact item = items.get(p);
        h.shortName.setText(nonBlank(item.getShortName(), nonBlank(item.getCategory(), "Emergency")));
        h.organization.setText(nonBlank(item.getOrganizationName(), "Emergency contact"));
        h.phone.setText(nonBlank(item.getPhone(), "No phone number"));
        String details = nonBlank(item.getAddress(), "");
        if (item.getAlternatePhone() != null && !item.getAlternatePhone().trim().isEmpty()) details = (details.isEmpty() ? "" : details + "\n") + "Alternate: " + item.getAlternatePhone();
        h.details.setText(details);
        h.details.setVisibility(details.isEmpty() ? View.GONE : View.VISIBLE);
        h.call.setEnabled(item.getPhone() != null && !item.getPhone().trim().isEmpty());
        h.call.setOnClickListener(v -> listener.onCall(item));
    }
    private String nonBlank(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value.trim(); }
    @Override public int getItemCount() { return items.size(); }
    static class Holder extends RecyclerView.ViewHolder {
        final TextView shortName, organization, phone, details; final MaterialButton call;
        Holder(View v) { super(v); shortName=v.findViewById(R.id.directoryShortName); organization=v.findViewById(R.id.directoryOrganization); phone=v.findViewById(R.id.directoryPhone); details=v.findViewById(R.id.directoryDetails); call=v.findViewById(R.id.directoryCall); }
    }
    public interface Listener { void onCall(EmergencyDirectoryContact contact); }
}
