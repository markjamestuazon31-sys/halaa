package com.example.app.emergency;

import androidx.annotation.Nullable;

import java.util.List;
import java.util.Locale;

/** Pure selection rules used by the emergency map overlay. */
public final class EmergencyOverlayPolicy {

    private EmergencyOverlayPolicy() {
        // Utility class.
    }

    public static boolean isActiveStatus(@Nullable String status) {
        String normalized = status == null
                ? "PENDING"
                : status.trim().toUpperCase(Locale.US).replace(' ', '_');
        return !"CANCELLED".equals(normalized)
                && !"CLOSED".equals(normalized)
                && !"RESOLVED".equals(normalized);
    }

    @Nullable
    public static String selectPreferredIncident(
            @Nullable String requestedIncidentId,
            @Nullable List<String> orderedActiveIncidentIds
    ) {
        if (orderedActiveIncidentIds == null
                || orderedActiveIncidentIds.isEmpty()) {
            return null;
        }

        String requested = safe(requestedIncidentId);
        if (!requested.isEmpty()
                && orderedActiveIncidentIds.contains(requested)) {
            return requested;
        }

        return orderedActiveIncidentIds.get(0);
    }

    private static String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }
}
