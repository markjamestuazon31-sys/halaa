package com.example.app.emergency;

import java.util.Locale;

public enum IncidentStatus {
    PENDING, ACCEPTED, RESPONDING, EN_ROUTE, ON_SCENE, AGENCY_CONTACTED,
    RESCUE_IN_PROGRESS, REPORT_SUBMITTED, ADMIN_REVIEWED, CLOSED, CANCELLED;

    public static IncidentStatus from(String value) {
        if (value == null) return PENDING;
        String normalized = value.trim().toUpperCase(Locale.US).replace(' ', '_');
        if ("ACTIVE".equals(normalized) || "RECEIVED".equals(normalized)) return PENDING;
        if ("RESPONDER_ASSIGNED".equals(normalized)) return ACCEPTED;
        if ("RESOLVED".equals(normalized)) return CLOSED;
        try { return IncidentStatus.valueOf(normalized); }
        catch (IllegalArgumentException ignored) { return PENDING; }
    }

    public boolean isTerminal() { return this == CLOSED || this == CANCELLED; }
}
