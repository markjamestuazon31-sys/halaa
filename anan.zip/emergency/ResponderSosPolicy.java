package com.example.app.emergency;

import java.util.Locale;

public final class ResponderSosPolicy {

    private ResponderSosPolicy() { }

    public static boolean isActive(String status) {
        String normalized = status == null ? "" : status.trim().toLowerCase(Locale.US);
        return !"resolved".equals(normalized) && !"cancelled".equals(normalized);
    }

    public static boolean canAccept(String status, boolean alreadyAccepted) {
        return isActive(status) && !alreadyAccepted;
    }
}
