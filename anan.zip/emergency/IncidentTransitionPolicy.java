package com.example.app.emergency;

import java.util.EnumSet;
import java.util.Set;

public final class IncidentTransitionPolicy {
    private IncidentTransitionPolicy() { }

    public static boolean canTransition(String current, String next) {
        IncidentStatus from = IncidentStatus.from(current);
        IncidentStatus to = IncidentStatus.from(next);
        if (from == to) return true;
        return allowedNext(from).contains(to);
    }

    public static Set<IncidentStatus> allowedNext(IncidentStatus status) {
        switch (status) {
            case PENDING: return EnumSet.of(IncidentStatus.ACCEPTED, IncidentStatus.CANCELLED);
            case ACCEPTED: return EnumSet.of(IncidentStatus.RESPONDING, IncidentStatus.CANCELLED);
            case RESPONDING: return EnumSet.of(IncidentStatus.EN_ROUTE, IncidentStatus.ON_SCENE, IncidentStatus.AGENCY_CONTACTED, IncidentStatus.CANCELLED);
            case EN_ROUTE: return EnumSet.of(IncidentStatus.ON_SCENE, IncidentStatus.AGENCY_CONTACTED, IncidentStatus.CANCELLED);
            case ON_SCENE: return EnumSet.of(IncidentStatus.AGENCY_CONTACTED, IncidentStatus.RESCUE_IN_PROGRESS, IncidentStatus.REPORT_SUBMITTED, IncidentStatus.CANCELLED);
            case AGENCY_CONTACTED: return EnumSet.of(IncidentStatus.RESCUE_IN_PROGRESS, IncidentStatus.REPORT_SUBMITTED, IncidentStatus.CANCELLED);
            case RESCUE_IN_PROGRESS: return EnumSet.of(IncidentStatus.REPORT_SUBMITTED, IncidentStatus.CANCELLED);
            case REPORT_SUBMITTED: return EnumSet.of(IncidentStatus.ADMIN_REVIEWED);
            case ADMIN_REVIEWED: return EnumSet.of(IncidentStatus.CLOSED);
            default: return EnumSet.noneOf(IncidentStatus.class);
        }
    }
}
