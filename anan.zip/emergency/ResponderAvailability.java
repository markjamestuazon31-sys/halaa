package com.example.app.emergency;

import java.util.Locale;

public enum ResponderAvailability {
    AVAILABLE, BUSY, OFF_DUTY;
    public static ResponderAvailability from(String value) {
        if (value == null) return OFF_DUTY;
        try { return valueOf(value.trim().toUpperCase(Locale.US).replace(' ', '_')); }
        catch (IllegalArgumentException ignored) { return OFF_DUTY; }
    }
}
