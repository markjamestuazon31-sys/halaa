package com.example.app.emergency;

import java.util.Locale;

/**
 * Validates the state of one respondent inside an incident response team.
 * Incident-wide completion remains controlled by {@link IncidentTransitionPolicy}.
 */
public final class ResponderResponseTransitionPolicy {
    private ResponderResponseTransitionPolicy() { }

    public static boolean isKnownStatus(String value) {
        String status = normalize(value);
        return "ACCEPTED".equals(status)
                || "RESPONDING".equals(status)
                || "EN_ROUTE".equals(status)
                || "ON_SCENE".equals(status)
                || "AGENCY_CONTACTED".equals(status)
                || "RESCUE_IN_PROGRESS".equals(status)
                || "WITHDRAWN".equals(status);
    }

    public static boolean canTransition(String current, String next) {
        String from = normalize(current);
        String to = normalize(next);
        if (!isKnownStatus(from) || !isKnownStatus(to)) return false;
        if (from.equals(to)) return true;
        if ("WITHDRAWN".equals(from)) return false;
        if ("WITHDRAWN".equals(to)) return true;

        switch (from) {
            case "ACCEPTED":
                return "RESPONDING".equals(to);
            case "RESPONDING":
                return "EN_ROUTE".equals(to)
                        || "ON_SCENE".equals(to)
                        || "AGENCY_CONTACTED".equals(to);
            case "EN_ROUTE":
                return "ON_SCENE".equals(to)
                        || "AGENCY_CONTACTED".equals(to);
            case "ON_SCENE":
                return "AGENCY_CONTACTED".equals(to)
                        || "RESCUE_IN_PROGRESS".equals(to);
            case "AGENCY_CONTACTED":
                return "RESCUE_IN_PROGRESS".equals(to);
            default:
                return false;
        }
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US);
    }
}
