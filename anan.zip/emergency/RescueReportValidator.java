package com.example.app.emergency;

import com.example.app.models.RescueReport;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public final class RescueReportValidator {
    private static final Set<String> CLASSIFICATIONS = new HashSet<>(Arrays.asList(
            "FALSE_ALARM", "NON_CRITICAL", "CRITICAL", "RESCUED_ON_SITE", "TRANSPORTED_TO_HOSPITAL",
            "REFERRED_TO_POLICE", "REFERRED_TO_FIRE_DEPARTMENT", "REFERRED_TO_BARANGAY",
            "USER_CANCELLED", "USER_NOT_FOUND"
    ));
    private RescueReportValidator() { }

    public static String validateIndividual(RescueReport report) {
        if (report == null) return "Report is required.";
        if (blank(report.getObservedCondition())) return "Observed condition is required.";
        if (blank(report.getActionsPerformed())) return "Actions performed are required.";
        if (!CLASSIFICATIONS.contains(normalize(report.getClassificationRecommendation()))) return "Select a valid classification recommendation.";
        return null;
    }

    public static String validateFinal(RescueReport report) {
        if (report == null) return "Final report is required.";
        if (blank(report.getSummary())) return "Final report summary is required.";
        if (!CLASSIFICATIONS.contains(normalize(report.getClassification()))) return "Select a valid final classification.";
        return null;
    }

    private static boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    private static String normalize(String value) { return value == null ? "" : value.trim().toUpperCase(); }
}
