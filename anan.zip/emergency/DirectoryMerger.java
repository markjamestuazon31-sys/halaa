package com.example.app.emergency;

import com.example.app.models.EmergencyDirectoryContact;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class DirectoryMerger {
    private DirectoryMerger() { }

    public static List<EmergencyDirectoryContact> merge(
            List<EmergencyDirectoryContact> barangay,
            List<EmergencyDirectoryContact> global
    ) {
        Map<String, EmergencyDirectoryContact> merged = new LinkedHashMap<>();
        addActive(merged, barangay, "barangay");
        addActive(merged, global, "global");
        List<EmergencyDirectoryContact> result = new ArrayList<>(merged.values());
        result.sort(Comparator.comparingInt(EmergencyDirectoryContact::getDisplayOrder));
        return result;
    }

    private static void addActive(Map<String, EmergencyDirectoryContact> target, List<EmergencyDirectoryContact> source, String prefix) {
        if (source == null) return;
        for (EmergencyDirectoryContact contact : source) {
            if (contact == null || !contact.isActive()) continue;
            String key = prefix + ":" + safe(contact.getId(), safe(contact.getPhone(), contact.getShortName()));
            target.put(key, contact);
        }
    }

    private static String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? (fallback == null ? "" : fallback.trim()) : value.trim();
    }
}
