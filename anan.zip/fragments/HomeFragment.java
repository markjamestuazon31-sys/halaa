package com.example.app.fragments;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.app.MainActivity;
import com.example.app.R;
import com.example.app.activities.RelationshipRequestsActivity;
import com.example.app.activities.FamilyTrackingMapActivity;
import com.example.app.activities.MedicalProfileActivity;
import com.example.app.activities.MedicationActivity;
import com.example.app.activities.MedicalQRActivity;
import com.example.app.activities.MedicalScannerActivity;
import com.example.app.activities.NotificationActivity;
import com.example.app.activities.ProfileActivity;
import com.example.app.activities.RespondentCasesActivity;
import com.example.app.activities.SOSActivity;
import com.example.app.auth.AccountPolicy;
import com.example.app.emergency.ResponderAvailability;
import com.example.app.models.EmergencyIncident;
import com.example.app.contacts.RelationshipPolicy;
import com.example.app.models.Relationship;
import com.example.app.models.MedicalProfile;
import com.example.app.models.Medication;
import com.example.app.models.User;
import com.example.app.repositories.EmergencyIncidentRepository;
import com.example.app.repositories.ResponderPresenceRepository;
import com.example.app.utils.HomeMapManager;
import com.example.app.utils.MedicationReminderSummary;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.maplibre.android.maps.MapView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/** Shared professional home with a respondent-only response workspace. */
public class HomeFragment extends Fragment {
    private MapView mapView;
    private HomeMapManager homeMapManager;
    private ImageView profileImage;
    private TextView welcomeName, notificationBadge, mapStatusTitle, mapStatusSubtitle;
    private TextView medicationReminderSubtitle;
    private TextView readinessTitle, readinessSubtitle, familyConnectedValue, safetyStatusValue;
    private View responderSection;
    private TextView activeCount, acceptedCount, recentIncidents;
    private Spinner availability;
    private boolean initializingAvailability = true;
    private String role = AccountPolicy.ROLE_USER;
    private String uid = "";
    private boolean offlineSession;

    private DatabaseReference friendsReference, medicalProfileReference, medicationReference, responsesReference, responderProfileReference;
    private Query notificationsQuery;
    private ValueEventListener friendsListener, notificationsListener, medicalProfileListener, medicationListener, responsesListener, responderProfileListener;
    private EmergencyIncidentRepository incidentRepository;
    private final ResponderPresenceRepository presenceRepository = new ResponderPresenceRepository();

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        View view=inflater.inflate(R.layout.fragment_home,container,false);
        role=AccountPolicy.normalizeValue(getArguments()==null?null:getArguments().getString(MainActivity.EXTRA_ROLE));
        offlineSession=getArguments()!=null&&getArguments().getBoolean(MainActivity.EXTRA_OFFLINE_SESSION,false);
        uid=FirebaseAuth.getInstance().getUid(); if(uid==null)uid="";
        bind(view); configureMap(state); configureActions(view); configureResponderWorkspace(); loadDashboardData(); return view;
    }

    private void bind(View view) {
        mapView=view.findViewById(R.id.homeMap); profileImage=view.findViewById(R.id.homeProfileImage); welcomeName=view.findViewById(R.id.welcomeName); notificationBadge=view.findViewById(R.id.notificationBadge);
        mapStatusTitle=view.findViewById(R.id.homeMapStatusTitle); mapStatusSubtitle=view.findViewById(R.id.homeMapStatusSubtitle); readinessTitle=view.findViewById(R.id.homeReadinessTitle);
        readinessSubtitle=view.findViewById(R.id.homeReadinessSubtitle); familyConnectedValue=view.findViewById(R.id.homeFamilyConnectedValue); safetyStatusValue=view.findViewById(R.id.homeSafetyStatusValue);
        responderSection=view.findViewById(R.id.responderSosSection); activeCount=view.findViewById(R.id.responderSosCount); acceptedCount=view.findViewById(R.id.responderAcceptedCount);
        recentIncidents=view.findViewById(R.id.responderRecentIncidents); availability=view.findViewById(R.id.responderHomeAvailability);
        medicationReminderSubtitle=view.findViewById(R.id.homeMedicationReminderSubtitle);
    }

    private void configureMap(@Nullable Bundle state) {
        mapView.onCreate(state);
        mapView.setClickable(false);
        mapView.setFocusable(false);

        if (uid.isEmpty()) {
            mapStatusTitle.setText("Map unavailable");
            mapStatusSubtitle.setText("Please sign in again.");
            return;
        }

        homeMapManager = new HomeMapManager(
                requireContext(),
                mapView,
                uid
        );

        homeMapManager.start(new HomeMapManager.Listener() {
            @Override
            public void onStateChanged(
                    boolean mapReady,
                    int pairedFamilyCount,
                    int visibleFamilyCount,
                    boolean selfVisible
            ) {
                if (!isAdded()) {
                    return;
                }

                if (!mapReady) {
                    mapStatusTitle.setText("Loading family map");
                    mapStatusSubtitle.setText(
                            "Preparing OpenStreetMap and profile pins…"
                    );
                    return;
                }

                if (pairedFamilyCount == 0) {
                    mapStatusTitle.setText("Connect trusted family");
                    mapStatusSubtitle.setText(
                            selfVisible
                                    ? "Your location is ready. Add family from Profile QR."
                                    : "Add family from your Profile QR to begin sharing."
                    );
                    return;
                }

                if (visibleFamilyCount == 0) {
                    mapStatusTitle.setText(
                            pairedFamilyCount == 1
                                    ? "1 family member connected"
                                    : pairedFamilyCount + " family members connected"
                    );
                    mapStatusSubtitle.setText(
                            "Waiting for an authorized live location."
                    );
                    return;
                }

                mapStatusTitle.setText(
                        visibleFamilyCount == 1
                                ? "1 family member live"
                                : visibleFamilyCount + " family members live"
                );
                mapStatusSubtitle.setText(
                        "Profile-photo pins update in real time."
                );
            }

            @Override
            public void onLoadingFallback() {
                if (!isAdded()) {
                    return;
                }
                mapStatusTitle.setText("Loading backup map");
                mapStatusSubtitle.setText(
                        "MapTiler is unavailable; using OpenStreetMap fallback."
                );
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) {
                    return;
                }
                mapStatusTitle.setText("Map temporarily unavailable");
                mapStatusSubtitle.setText(
                        TextUtils.isEmpty(message)
                                ? "Tap View map to try again."
                                : message
                );
            }
        });
    }

    private void configureActions(View view) {
        View.OnClickListener openProfile =
                ignored -> open(ProfileActivity.class);
        profileImage.setOnClickListener(openProfile);
        view.findViewById(R.id.homeProfileHeader)
                .setOnClickListener(openProfile);

        view.findViewById(R.id.homeNotificationButton)
                .setOnClickListener(
                        ignored -> open(NotificationActivity.class)
                );

        View.OnClickListener openMap =
                ignored -> open(FamilyTrackingMapActivity.class);
        view.findViewById(R.id.homeMapCard)
                .setOnClickListener(openMap);
        view.findViewById(R.id.homeMapAction)
                .setOnClickListener(openMap);

        view.findViewById(R.id.sosButton)
                .setOnClickListener(ignored -> {
                    if (offlineSession) {
                        Toast.makeText(
                                requireContext(),
                                "Reconnect to confirm and send a new SOS incident.",
                                Toast.LENGTH_LONG
                        ).show();
                        return;
                    }
                    open(SOSActivity.class);
                });

        MaterialCardView medicationReminder =
                view.findViewById(R.id.medicationReminder);
        MaterialCardView contacts =
                view.findViewById(R.id.contacts);
        MaterialCardView medicalProfile =
                view.findViewById(R.id.medicalProfile);
        MaterialCardView notifications =
                view.findViewById(R.id.notifications);
        MaterialCardView medicalQr =
                view.findViewById(R.id.medicalQr);
        MaterialCardView scanMedicalQr =
                view.findViewById(R.id.scanMedicalQr);

        medicationReminder.setOnClickListener(
                ignored -> open(MedicationActivity.class)
        );
        contacts.setOnClickListener(
                ignored -> open(RelationshipRequestsActivity.class)
        );
        medicalProfile.setOnClickListener(
                ignored -> open(MedicalProfileActivity.class)
        );
        notifications.setOnClickListener(
                ignored -> open(NotificationActivity.class)
        );
        medicalQr.setOnClickListener(
                ignored -> open(MedicalQRActivity.class)
        );
        scanMedicalQr.setOnClickListener(
                ignored -> open(MedicalScannerActivity.class)
        );

        view.findViewById(R.id.homeReadinessCard)
                .setOnClickListener(
                        ignored -> open(MedicalProfileActivity.class)
                );
        view.findViewById(R.id.responderOpenCases)
                .setOnClickListener(
                        ignored -> open(RespondentCasesActivity.class)
                );
    }

    private void configureResponderWorkspace() {
        boolean responder=AccountPolicy.ROLE_RESPONDER.equals(role);
        responderSection.setVisibility(responder?View.VISIBLE:View.GONE);
        if(!responder||uid.isEmpty())return;
        String[] values={"AVAILABLE","BUSY","OFF_DUTY"};
        availability.setAdapter(new ArrayAdapter<>(requireContext(),android.R.layout.simple_spinner_dropdown_item,values));
        availability.setEnabled(!offlineSession);
        availability.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(initializingAvailability)return;ResponderAvailability value=ResponderAvailability.valueOf(String.valueOf(p.getItemAtPosition(pos)));presenceRepository.setAvailability(uid,value,new ResponderPresenceRepository.Callback(){@Override public void onSuccess(){}@Override public void onError(String m){if(isAdded())Toast.makeText(requireContext(),m,Toast.LENGTH_LONG).show();}});}
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
        responderProfileReference=FirebaseDatabase.getInstance().getReference("respondents").child(uid);
        responderProfileListener=responderProfileReference.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){String value=s.child("availability").getValue(String.class);int pos="BUSY".equals(value)?1:"OFF_DUTY".equals(value)?2:0;initializingAvailability=true;availability.setSelection(pos,false);availability.post(()->initializingAvailability=false);}
            @Override public void onCancelled(@NonNull DatabaseError e){initializingAvailability=false;}
        });
        responsesReference=FirebaseDatabase.getInstance().getReference("respondentResponseIndex").child(uid);
        responsesListener=responsesReference.addValueEventListener(new ValueEventListener(){
            @Override public void onDataChange(@NonNull DataSnapshot s){int count=0;for(DataSnapshot incident:s.getChildren())if(Boolean.TRUE.equals(incident.child("active").getValue(Boolean.class)))count++;acceptedCount.setText(String.valueOf(count));}
            @Override public void onCancelled(@NonNull DatabaseError e){acceptedCount.setText("—");}
        });
        incidentRepository=new EmergencyIncidentRepository();
        incidentRepository.listenActiveIncidents(new EmergencyIncidentRepository.IncidentListener(){
            @Override public void onChanged(List<EmergencyIncident> values){activeCount.setText(String.valueOf(values.size()));List<String> lines=new ArrayList<>();for(int i=0;i<Math.min(3,values.size());i++){EmergencyIncident item=values.get(i);lines.add("• "+safe(item.getPatientName(),"Patient")+" — "+safe(item.getStatus(),"PENDING").replace('_',' '));}recentIncidents.setText(lines.isEmpty()?"No recent active incidents.":TextUtils.join("\n",lines));}
            @Override public void onError(String message){activeCount.setText("—");recentIncidents.setText(message==null?"Incident data is temporarily unavailable.":message);}
        });
    }

    private void loadDashboardData() {
        if (uid.isEmpty()) return;
        loadUser();
        listenForConnectedContacts();
        listenForUnreadNotifications();
        listenForMedicalProfile();
        listenForMedicationReminders();
    }
    private void loadUser(){FirebaseDatabase.getInstance().getReference("users").child(uid).get().addOnSuccessListener(s->{if(!isAdded())return;User u=s.getValue(User.class);if(u==null)return;welcomeName.setText(safe(u.getFullName(),getString(R.string.home_user_fallback)));Bitmap b=decodeProfileImage(u.getProfileImage());if(b!=null)profileImage.setImageBitmap(b);});}
    private void listenForConnectedContacts() {
        friendsReference = FirebaseDatabase.getInstance()
                .getReference("relationships")
                .child(uid);

        friendsListener = friendsReference.addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(
                            @NonNull DataSnapshot snapshot
                    ) {
                        int familyCount = 0;

                        for (DataSnapshot child
                                : snapshot.getChildren()) {
                            Relationship relationship = child.getValue(
                                    Relationship.class
                            );

                            if (relationship == null
                                    || !RelationshipPolicy.ACCEPTED.equals(
                                    RelationshipPolicy.normalize(
                                            relationship.getStatus()
                                    )
                            )
                                    || !RelationshipPolicy.FAMILY.equals(
                                    RelationshipPolicy.normalize(
                                            relationship.getRelationshipType()
                                    )
                            )) {
                                continue;
                            }

                            familyCount++;
                        }

                        renderConnectedContacts(familyCount);
                    }

                    @Override
                    public void onCancelled(
                            @NonNull DatabaseError error
                    ) {
                        familyConnectedValue.setText("—");
                    }
                }
        );
    }

    private void renderConnectedContacts(int count) {
        if (count == 0) {
            familyConnectedValue.setText(
                    R.string.home_no_members
            );
        } else {
            familyConnectedValue.setText(
                    getString(R.string.home_members_count, count)
            );
        }
    }
    private void listenForUnreadNotifications(){notificationsQuery=FirebaseDatabase.getInstance().getReference("notifications").child(uid).orderByChild("createdAt").limitToLast(100);notificationsListener=new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot s){int unread=0;for(DataSnapshot c:s.getChildren())if(!Boolean.TRUE.equals(c.child("read").getValue(Boolean.class)))unread++;renderNotificationBadge(unread);}@Override public void onCancelled(@NonNull DatabaseError e){renderNotificationBadge(0);}};notificationsQuery.addValueEventListener(notificationsListener);}
    private void renderNotificationBadge(int unread){if(unread<=0){notificationBadge.setVisibility(View.GONE);}else{notificationBadge.setVisibility(View.VISIBLE);notificationBadge.setText(unread>99?getString(R.string.home_notification_overflow):String.valueOf(unread));}}
    private void listenForMedicalProfile(){medicalProfileReference=FirebaseDatabase.getInstance().getReference("medicalProfiles").child(uid);medicalProfileListener=medicalProfileReference.addValueEventListener(new ValueEventListener(){@Override public void onDataChange(@NonNull DataSnapshot s){renderMedicalReadiness(s.getValue(MedicalProfile.class));}@Override public void onCancelled(@NonNull DatabaseError e){safetyStatusValue.setText(R.string.home_status_unavailable);}});}
    private void listenForMedicationReminders() {
        medicationReference = FirebaseDatabase.getInstance()
                .getReference("medications")
                .child(uid);
        medicationListener = medicationReference.addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        List<Medication> values = new ArrayList<>();
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Medication medication = child.getValue(Medication.class);
                            if (medication == null) continue;
                            medication.setId(child.getKey());
                            values.add(medication);
                        }
                        renderMedicationReminder(values);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        medicationReminderSubtitle.setText(
                                R.string.home_medication_reminder_subtitle
                        );
                    }
                }
        );
    }

    private void renderMedicationReminder(List<Medication> medications) {
        MedicationReminderSummary.Result next =
                MedicationReminderSummary.findNext(
                        medications,
                        System.currentTimeMillis(),
                        TimeZone.getDefault()
                );
        if (next == null) {
            medicationReminderSubtitle.setText(
                    R.string.home_medication_no_reminders
            );
            return;
        }

        Medication medication = next.getMedication();
        String name = safe(medication.getName(), "Medicine");
        String time = DateFormat.getTimeInstance(DateFormat.SHORT)
                .format(new Date(next.getTriggerAtMillis()));
        medicationReminderSubtitle.setText(
                getString(
                        R.string.home_medication_next_format,
                        name,
                        time
                )
        );
    }
    private void renderMedicalReadiness(@Nullable MedicalProfile profile){if(profile==null){readinessTitle.setText(R.string.home_complete_profile_title);readinessSubtitle.setText(R.string.home_complete_profile_subtitle);safetyStatusValue.setText(R.string.home_status_needs_setup);}else{readinessTitle.setText(R.string.home_profile_saved_title);readinessSubtitle.setText(R.string.home_profile_saved_subtitle);safetyStatusValue.setText(R.string.home_status_ready);}}
    @Nullable private Bitmap decodeProfileImage(@Nullable String raw){if(TextUtils.isEmpty(raw))return null;String value=raw.trim();int comma=value.indexOf(',');if(comma>=0&&comma+1<value.length())value=value.substring(comma+1);try{byte[] bytes=Base64.decode(value,Base64.DEFAULT);return BitmapFactory.decodeByteArray(bytes,0,bytes.length);}catch(IllegalArgumentException e){return null;}}
    private String safe(@Nullable String value,String fallback){return TextUtils.isEmpty(value)?fallback:value.trim();}
    private void open(Class<?> destination){if(isAdded()){Intent intent=new Intent(requireContext(),destination);intent.putExtra(MainActivity.EXTRA_ROLE,role);intent.putExtra(MainActivity.EXTRA_OFFLINE_SESSION,offlineSession);startActivity(intent);}}

    @Override public void onStart(){super.onStart();if(mapView!=null)mapView.onStart();}
    @Override public void onResume(){super.onResume();if(mapView!=null)mapView.onResume();}
    @Override public void onPause(){if(mapView!=null)mapView.onPause();super.onPause();}
    @Override public void onStop(){if(mapView!=null)mapView.onStop();super.onStop();}
    @Override public void onSaveInstanceState(@NonNull Bundle out){super.onSaveInstanceState(out);if(mapView!=null)mapView.onSaveInstanceState(out);}
    @Override public void onLowMemory(){super.onLowMemory();if(mapView!=null)mapView.onLowMemory();}
    @Override public void onDestroyView(){
        if(friendsReference!=null&&friendsListener!=null)friendsReference.removeEventListener(friendsListener);
        if(notificationsQuery!=null&&notificationsListener!=null)notificationsQuery.removeEventListener(notificationsListener);
        if(medicalProfileReference!=null&&medicalProfileListener!=null)medicalProfileReference.removeEventListener(medicalProfileListener);
        if(medicationReference!=null&&medicationListener!=null)medicationReference.removeEventListener(medicationListener);
        if(responsesReference!=null&&responsesListener!=null)responsesReference.removeEventListener(responsesListener);
        if(responderProfileReference!=null&&responderProfileListener!=null)responderProfileReference.removeEventListener(responderProfileListener);
        if (incidentRepository != null) {
            incidentRepository.stopListening();
        }
        if (homeMapManager != null) {
            homeMapManager.stop();
            homeMapManager = null;
        }
        if (mapView != null) {
            mapView.onDestroy();
        }
        super.onDestroyView();
    }
}
