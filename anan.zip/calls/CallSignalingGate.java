package com.example.app.calls;

/**
 * Coordinates asynchronous Firebase signaling with WebRTC peer readiness.
 *
 * Firebase may deliver the offer or answer before camera/microphone permission
 * is granted and before the peer connection exists. This gate preserves that
 * state and prevents duplicate setRemoteDescription operations.
 */
public final class CallSignalingGate {

    private boolean peerReady;
    private boolean remoteDescriptionPending;
    private boolean remoteDescriptionSet;

    public synchronized void markPeerReady() {
        peerReady = true;
    }

    public synchronized boolean shouldStartRemoteDescription(
            boolean remoteDescriptionAvailable
    ) {
        return peerReady
                && remoteDescriptionAvailable
                && !remoteDescriptionPending
                && !remoteDescriptionSet;
    }

    public synchronized void markRemoteDescriptionPending() {
        if (!peerReady || remoteDescriptionSet) {
            return;
        }
        remoteDescriptionPending = true;
    }

    public synchronized void markRemoteDescriptionSet() {
        remoteDescriptionPending = false;
        remoteDescriptionSet = true;
    }

    public synchronized void markRemoteDescriptionFailed() {
        remoteDescriptionPending = false;
    }

    public synchronized boolean canApplyRemoteCandidates() {
        return peerReady && remoteDescriptionSet;
    }

    public synchronized boolean isRemoteDescriptionSet() {
        return remoteDescriptionSet;
    }
}
